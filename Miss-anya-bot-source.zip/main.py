#!/usr/bin/env python3
"""Miss Anya Bot — Telegram group management bot. Needs only Python 3.9+ (standard library). Run: python3 main.py"""
import logging
import sys

import config


def main():
    logging.basicConfig(level=getattr(logging, config.LOG_LEVEL.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if not config.TOKEN:
        sys.exit("BOT_TOKEN is not set. Copy .env.example to .env and put your token from @BotFather in it.")
    import core
    import tg
    core.init(tg.Bot(config.TOKEN))
    import events
    events.setup(core.bot)
    n = len({id(c) for c in core.REGISTRY.values()})
    logging.getLogger("anyabot").info("@%s is up with %d commands. Press Ctrl+C to stop.", core.ME.username, n)
    try:
        events.run_polling(core.bot)
    except KeyboardInterrupt:
        print("bye")


if __name__ == "__main__":
    main()
