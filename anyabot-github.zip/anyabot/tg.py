"""Tiny dependency-free Telegram Bot API client + helpers (standard library only)."""
import heapq
import html
import json
import logging
import threading
import time
import urllib.error
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor

import config

log = logging.getLogger("anyabot.tg")
POOL = ThreadPoolExecutor(max_workers=config.WORKERS, thread_name_prefix="w")


# --------------------------------------------------------------------------
# Attribute-style access to the JSON that Telegram returns
# --------------------------------------------------------------------------
class D(dict):
    """dict with attribute access. Missing keys give None, so msg.reply_to_message.from_user.id style
    chains are safe to write (check the intermediate for None where it matters)."""

    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        if k == "from_user":
            k = "from"
        return wrap(self.get(k))


def wrap(v):
    if isinstance(v, D):
        return v
    if isinstance(v, dict):
        return D(v)
    if isinstance(v, list):
        return [wrap(i) for i in v]
    return v


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""), quote=False)


def mention(uid, name) -> str:
    return f'<a href="tg://user?id={uid}">{esc(name)}</a>'


def full_name(u) -> str:
    if not u:
        return "?"
    n = u.first_name or ""
    if u.last_name:
        n += " " + u.last_name
    return n or (u.title if u.title else str(u.id))


# --------------------------------------------------------------------------
# Entities (Telegram offsets are UTF-16 code units)
# --------------------------------------------------------------------------
def ent_text(text: str, e) -> str:
    b = text.encode("utf-16-le")
    return b[2 * e["offset"]: 2 * (e["offset"] + e["length"])].decode("utf-16-le", "ignore")


_SIMPLE = {"bold": "b", "italic": "i", "underline": "u", "strikethrough": "s", "code": "code",
           "pre": "pre", "blockquote": "blockquote"}
FORMAT_TYPES = set(_SIMPLE) | {"spoiler", "text_link", "text_mention", "custom_emoji"}


def entities_to_html(text: str, entities) -> str:
    """Rebuild Telegram-HTML from plain text + entities."""
    text = text or ""
    ents = [e for e in (entities or []) if e["type"] in FORMAT_TYPES]
    if not ents:
        return esc(text)
    u = text.encode("utf-16-le")
    n = len(u) // 2
    opens, closes, cuts = {}, {}, {0, n}
    for e in sorted(ents, key=lambda e: (e["offset"], -e["length"])):
        t = e["type"]
        if t in _SIMPLE:
            o, c = f"<{_SIMPLE[t]}>", f"</{_SIMPLE[t]}>"
        elif t == "spoiler":
            o, c = "<tg-spoiler>", "</tg-spoiler>"
        elif t == "text_link":
            o, c = f'<a href="{html.escape(e.get("url", ""), quote=True)}">', "</a>"
        elif t == "text_mention":
            o, c = f'<a href="tg://user?id={e["user"]["id"]}">', "</a>"
        else:
            continue
        a, b = e["offset"], min(e["offset"] + e["length"], n)
        opens.setdefault(a, []).append(o)
        closes.setdefault(b, []).append(c)
        cuts.update((a, b))
    pts = sorted(cuts)
    out = []
    for i, p in enumerate(pts):
        out.extend(reversed(closes.get(p, [])))
        out.extend(opens.get(p, []))
        if i + 1 < len(pts):
            out.append(esc(u[2 * p: 2 * pts[i + 1]].decode("utf-16-le", "ignore")))
    return "".join(out)


# --------------------------------------------------------------------------
# Bot API client
# --------------------------------------------------------------------------
class TgError(Exception):
    def __init__(self, code, desc, params=None):
        super().__init__(f"[{code}] {desc}")
        self.code, self.desc, self.params = code, desc or "", params or {}

    def has(self, *needles) -> bool:
        d = self.desc.lower()
        return any(n in d for n in needles)


def _camel(name: str) -> str:
    p = name.split("_")
    return p[0] + "".join(x[:1].upper() + x[1:] for x in p[1:])


def _multipart(params, files):
    b = uuid.uuid4().hex
    out = []
    for k, v in params.items():
        if isinstance(v, bool):
            v = "true" if v else "false"
        elif not isinstance(v, (str, int, float)):
            v = json.dumps(v)
        out.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    for k, (fname, data, ctype) in files.items():
        out.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"; filename="{fname}"\r\n'
                   f'Content-Type: {ctype}\r\n\r\n'.encode() + data + b"\r\n")
    out.append(f"--{b}--\r\n".encode())
    return b"".join(out), f"multipart/form-data; boundary={b}"


class Bot:
    def __init__(self, token: str, base: str = None):
        self.token = token
        self.base = (base or config.API_BASE).rstrip("/")

    def call(self, method, _files=None, _timeout=60, **params):
        params = {k: v for k, v in params.items() if v is not None}
        if _files:
            body, ctype = _multipart(params, _files)
        else:
            body, ctype = json.dumps(params).encode(), "application/json"
        url = f"{self.base}/bot{self.token}/{method}"
        data = None
        for attempt in range(4):
            req = urllib.request.Request(url, data=body, headers={"Content-Type": ctype})
            try:
                with urllib.request.urlopen(req, timeout=_timeout) as resp:
                    data = json.load(resp)
            except urllib.error.HTTPError as e:
                try:
                    data = json.load(e)
                except ValueError:
                    raise TgError(e.code, str(e))
            except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
                if attempt >= 2:
                    raise TgError(0, f"network error: {e}")
                time.sleep(1 + attempt)
                continue
            if not data.get("ok") and data.get("error_code") == 429 and attempt < 3:
                wait = (data.get("parameters") or {}).get("retry_after", 1)
                if wait <= 30:
                    time.sleep(wait + 0.5)
                    continue
            break
        if not data.get("ok"):
            raise TgError(data.get("error_code", 0), data.get("description", ""), data.get("parameters"))
        return wrap(data.get("result"))

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        method = _camel(name)
        return lambda **kw: self.call(method, **kw)


# --------------------------------------------------------------------------
# Scheduler for delayed / periodic jobs
# --------------------------------------------------------------------------
def _safe(fn, args):
    try:
        fn(*args)
    except Exception:  # noqa: BLE001
        log.exception("job %s failed", getattr(fn, "__name__", fn))


class _Sched(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True, name="sched")
        self.h, self.cv, self.n = [], threading.Condition(), 0

    def add(self, when, fn, args=(), interval=None):
        with self.cv:
            self.n += 1
            heapq.heappush(self.h, (when, self.n, fn, args, interval))
            self.cv.notify()

    def run(self):
        while True:
            with self.cv:
                while not self.h or self.h[0][0] > time.time():
                    self.cv.wait(None if not self.h else max(0.0, self.h[0][0] - time.time()))
                _, _, fn, args, interval = heapq.heappop(self.h)
            POOL.submit(_safe, fn, args)
            if interval:
                self.add(time.time() + interval, fn, args, interval)


SCHED = _Sched()
SCHED.start()


def after(delay, fn, *args):
    SCHED.add(time.time() + delay, fn, args)


def every(interval, fn, *args):
    SCHED.add(time.time() + interval, fn, args, interval)
