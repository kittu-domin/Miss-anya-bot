"""SQLite storage. One shared connection guarded by a lock (the bot is I/O bound, this is plenty)."""
import json
import sqlite3
import threading

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv(chat_id INTEGER, k TEXT, v TEXT, PRIMARY KEY(chat_id,k));
CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, username TEXT, name TEXT, seen REAL);
CREATE INDEX IF NOT EXISTS users_un ON users(username);
CREATE TABLE IF NOT EXISTS chats(chat_id INTEGER PRIMARY KEY, title TEXT, type TEXT, username TEXT, seen REAL);
CREATE TABLE IF NOT EXISTS warns(id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, user_id INTEGER, reason TEXT, ts REAL, by INTEGER);
CREATE INDEX IF NOT EXISTS warns_cu ON warns(chat_id,user_id);
CREATE TABLE IF NOT EXISTS notes(chat_id INTEGER, name TEXT, data TEXT, PRIMARY KEY(chat_id,name));
CREATE TABLE IF NOT EXISTS filters(chat_id INTEGER, kw TEXT, data TEXT, PRIMARY KEY(chat_id,kw));
CREATE TABLE IF NOT EXISTS approvals(chat_id INTEGER, user_id INTEGER, PRIMARY KEY(chat_id,user_id));
CREATE TABLE IF NOT EXISTS blocklist(chat_id INTEGER, trigger TEXT, reason TEXT, PRIMARY KEY(chat_id,trigger));
CREATE TABLE IF NOT EXISTS feds(fed_id TEXT PRIMARY KEY, name TEXT, owner_id INTEGER, need_reason INTEGER DEFAULT 1, notif INTEGER DEFAULT 1, log_chat INTEGER);
CREATE TABLE IF NOT EXISTS fed_admins(fed_id TEXT, user_id INTEGER, PRIMARY KEY(fed_id,user_id));
CREATE TABLE IF NOT EXISTS fed_chats(chat_id INTEGER PRIMARY KEY, fed_id TEXT, quiet INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS fed_bans(fed_id TEXT, user_id INTEGER, reason TEXT, ts REAL, by INTEGER, PRIMARY KEY(fed_id,user_id));
CREATE TABLE IF NOT EXISTS fed_subs(fed_id TEXT, sub_id TEXT, PRIMARY KEY(fed_id,sub_id));
CREATE TABLE IF NOT EXISTS gbans(user_id INTEGER PRIMARY KEY, reason TEXT, ts REAL, by INTEGER);
CREATE TABLE IF NOT EXISTS sudo(user_id INTEGER PRIMARY KEY);
CREATE TABLE IF NOT EXISTS afk(user_id INTEGER PRIMARY KEY, reason TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS conns(user_id INTEGER PRIMARY KEY, chat_id INTEGER, last_chat INTEGER);
CREATE TABLE IF NOT EXISTS msgcount(chat_id INTEGER, user_id INTEGER, n INTEGER DEFAULT 0, PRIMARY KEY(chat_id,user_id));
"""


class DB:
    def __init__(self, path: str):
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)

    # --- raw SQL helpers -------------------------------------------------
    def x(self, sql, args=()):
        with self.lock:
            return self.conn.execute(sql, args)

    def all(self, sql, args=()):
        with self.lock:
            return self.conn.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        with self.lock:
            return self.conn.execute(sql, args).fetchone()

    def count(self, sql, args=()):
        row = self.one(sql, args)
        return row[0] if row else 0

    # --- per-chat key/value settings (JSON encoded) ----------------------
    def get(self, cid, k, default=None):
        row = self.one("SELECT v FROM kv WHERE chat_id=? AND k=?", (cid, k))
        if row is None:
            return default
        try:
            return json.loads(row["v"])
        except ValueError:
            return default

    def set(self, cid, k, v):
        self.x("INSERT INTO kv VALUES(?,?,?) ON CONFLICT(chat_id,k) DO UPDATE SET v=excluded.v",
               (cid, k, json.dumps(v)))

    def rm(self, cid, k):
        self.x("DELETE FROM kv WHERE chat_id=? AND k=?", (cid, k))

    def kv_all(self, cid):
        return {r["k"]: json.loads(r["v"]) for r in self.all("SELECT k,v FROM kv WHERE chat_id=?", (cid,))}

    def kv_wipe(self, cid):
        self.x("DELETE FROM kv WHERE chat_id=?", (cid,))


db = DB(config.DB_PATH)
