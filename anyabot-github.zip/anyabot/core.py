"""Core framework: command registry, permission checks, message sending, formatting, punishments."""
import html as _html
import logging
import random
import re
import time
from dataclasses import dataclass, field
from typing import Callable

import config
from db import db
from lang import t
from tg import D, FORMAT_TYPES, TgError, after, entities_to_html, esc, full_name, mention  # noqa: F401

log = logging.getLogger("anyabot")

bot = None          # tg.Bot, set by init()
ME = None           # the bot's own user object
ANON_ID = 1087968824    # "GroupAnonymousBot": sender of anonymous-admin messages
TG_ID = 777000          # "Telegram": sender of auto-forwarded channel posts
START = time.time()

PERM_KEYS = ["can_send_messages", "can_send_audios", "can_send_documents", "can_send_photos", "can_send_videos",
             "can_send_video_notes", "can_send_voice_notes", "can_send_polls", "can_send_other_messages",
             "can_add_web_page_previews", "can_change_info", "can_invite_users", "can_pin_messages",
             "can_manage_topics"]
NO_PERMS = {k: False for k in PERM_KEYS}
ALL_PERMS = {k: True for k in PERM_KEYS}


def init(b):
    global bot, ME
    bot = b
    ME = b.get_me()


# ==========================================================================
# Registry
# ==========================================================================
REGISTRY: dict = {}
MODULES: dict = {}
CALLBACKS: list = []
MODULE_TITLES = {}


@dataclass
class Cmd:
    name: str
    func: Callable
    module: str
    admin: bool = False
    rights: tuple = ()
    owner: bool = False
    sudo: bool = False
    scope: str = "group"        # group | any | pm
    disableable: bool = True
    action: bool = False
    help: str = ""
    aliases: tuple = field(default_factory=tuple)


def command(*names, module="misc", h="", admin=False, rights=(), owner=False, sudo=False, scope=None,
            disableable=None, action=False):
    def deco(fn):
        adm = admin or bool(rights)
        c = Cmd(name=names[0], func=fn, module=module, admin=adm, rights=tuple(rights), owner=owner, sudo=sudo,
                scope=scope or ("group" if adm else "any"),
                disableable=(not (adm or owner or sudo)) if disableable is None else disableable,
                action=action, help=h, aliases=tuple(names[1:]))
        for n in names:
            REGISTRY[n] = c
        MODULES.setdefault(module, [])
        if names[0] not in MODULES[module]:
            MODULES[module].append(names[0])
        return fn
    return deco


def callback(prefix):
    def deco(fn):
        CALLBACKS.append((prefix, fn))
        return fn
    return deco


# ==========================================================================
# Small helpers
# ==========================================================================
_TIME_RE = re.compile(r"^(\d+)\s*([smhdw])$", re.I)
_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def parse_time(s):
    m = _TIME_RE.match((s or "").strip())
    return int(m.group(1)) * _UNITS[m.group(2).lower()] if m else None


def fmt_dur(sec):
    sec = int(sec)
    parts = []
    for n, u in ((604800, "w"), (86400, "d"), (3600, "h"), (60, "m"), (1, "s")):
        if sec >= n:
            parts.append(f"{sec // n}{u}")
            sec %= n
    return " ".join(parts) or "0s"


def on_off(s):
    s = (s or "").lower()
    if s in ("on", "yes", "true", "enable", "enabled", "1"):
        return True
    if s in ("off", "no", "false", "disable", "disabled", "0"):
        return False
    return None


def flag(b):
    return "✅ on" if b else "❌ off"


def strip_tags(s):
    return _html.unescape(re.sub(r"<[^>]+>", "", s or ""))


def kb(rows):
    """rows: list[list[(label, url_or_callback)]]; items starting with 'cb:' are callback buttons."""
    out = []
    for row in rows:
        r = []
        for label, val in row:
            if val.startswith("cb:"):
                r.append({"text": label, "callback_data": val[3:]})
            else:
                r.append({"text": label, "url": val})
        out.append(r)
    return {"inline_keyboard": out}


def delete_msg(chat_id, mid):
    try:
        bot.delete_message(chat_id=chat_id, message_id=mid)
        return True
    except TgError:
        return False


def delete_later(chat_id, mid, delay):
    after(delay, delete_msg, chat_id, mid)


def is_sudo(uid):
    return uid == config.OWNER_ID or db.one("SELECT 1 FROM sudo WHERE user_id=?", (uid,)) is not None


_seen_users = {}


def track(user):
    if not user or user.get("is_bot") and user.id == ANON_ID:
        return
    key = (user.username, full_name(user))
    if _seen_users.get(user.id) == key:
        return
    _seen_users[user.id] = key
    db.x("INSERT INTO users VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,"
         "name=excluded.name,seen=excluded.seen",
         (user.id, (user.username or "").lower() or None, full_name(user), time.time()))


def track_chat(chat):
    if chat and chat.type != "private":
        db.x("INSERT INTO chats VALUES(?,?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title,"
             "type=excluded.type,username=excluded.username,seen=excluded.seen",
             (chat.id, chat.title, chat.type, chat.username, time.time()))


def user_name(uid):
    row = db.one("SELECT name FROM users WHERE user_id=?", (uid,))
    return row["name"] if row else f"User {uid}"


# ==========================================================================
# Admin / permission lookups
# ==========================================================================
_ADMINS = {}


def admins(cid, fresh=False):
    ent = _ADMINS.get(cid)
    if ent and not fresh and time.time() - ent[0] < 300:
        return ent[1]
    try:
        lst = bot.get_chat_administrators(chat_id=cid)
    except TgError:
        return ent[1] if ent else {}
    d = {m.user.id: m for m in lst}
    _ADMINS[cid] = (time.time(), d)
    return d


def clear_admin_cache(cid=None):
    if cid is None:
        _ADMINS.clear()
    else:
        _ADMINS.pop(cid, None)


def member(cid, uid):
    """Return the chat-administrator object (cached) for uid, or None if uid is not an admin."""
    if cid > 0:
        return None
    d = admins(cid)
    if uid in d:
        return d[uid]
    ent = _ADMINS.get(cid)
    if ent and time.time() - ent[0] > 20:       # maybe promoted recently
        d = admins(cid, fresh=True)
        if uid in d:
            return d[uid]
    return None     # not an admin (we deliberately avoid one API call per message)


def is_admin(cid, uid):
    if uid == ANON_ID:
        return True
    m = member(cid, uid)
    return bool(m and m.status in ("creator", "administrator"))


def has_right(m, right):
    if not m:
        return False
    if m.status == "creator":
        return True
    return m.status == "administrator" and bool(m.get(right))


def bot_member(cid):
    m = admins(cid).get(ME.id)
    if not m:
        m = admins(cid, fresh=True).get(ME.id)
    return m


def is_approved(cid, uid):
    return db.one("SELECT 1 FROM approvals WHERE chat_id=? AND user_id=?", (cid, uid)) is not None


def exempt(cid, uid):
    """Users that moderation (locks, blocklist, flood...) must ignore."""
    return uid in (TG_ID, ANON_ID) or is_sudo(uid) or is_admin(cid, uid) or is_approved(cid, uid)


# ==========================================================================
# Sending
# ==========================================================================
def _chunks(text, n=4000):
    if len(text) <= n:
        return [text]
    out, cur = [], ""
    for line in text.split("\n"):
        if len(cur) + len(line) + 1 > n and cur:
            out.append(cur)
            cur = ""
        while len(line) > n:
            out.append(line[:n])
            line = line[n:]
        cur += ("\n" if cur else "") + line
    if cur:
        out.append(cur)
    return out


def _autoclean(chat_id, m, kind):
    if chat_id < 0 and m and kind:
        types = db.get(chat_id, "cleanmsg", [])
        if types and ("all" in types or kind in types):
            delete_later(chat_id, m.message_id, config.CLEANMSG_DELAY)


def send(chat_id, text, markup=None, reply_to=None, thread=None, kind=None, preview=False, notify=True,
         protect=False):
    last = None
    parts = _chunks(text or "​")
    for i, part in enumerate(parts):
        p = dict(chat_id=chat_id, text=part, parse_mode="HTML",
                 link_preview_options={"is_disabled": not preview})
        if markup and i == len(parts) - 1:
            p["reply_markup"] = markup
        if reply_to and i == 0:
            p["reply_parameters"] = {"message_id": reply_to, "allow_sending_without_reply": True}
        if thread:
            p["message_thread_id"] = thread
        if not notify:
            p["disable_notification"] = True
        if protect:
            p["protect_content"] = True
        try:
            last = bot.send_message(**p)
        except TgError as e:
            if e.has("can't parse entities", "unsupported start tag"):
                p["parse_mode"] = None
                p["text"] = strip_tags(part)
                last = bot.send_message(**p)
            elif e.has("thread not found") and thread:
                p.pop("message_thread_id", None)
                last = bot.send_message(**p)
            else:
                raise
        _autoclean(chat_id, last, kind)
    return last


def edit(cq, text, markup=None):
    try:
        bot.edit_message_text(chat_id=cq.message.chat.id, message_id=cq.message.message_id, text=text,
                              parse_mode="HTML", link_preview_options={"is_disabled": True},
                              reply_markup=markup if markup is not None else {"inline_keyboard": []})
    except TgError as e:
        if not e.has("not modified"):
            log.warning("edit failed: %s", e)


def answer(cq, text=None, alert=False):
    try:
        bot.answer_callback_query(callback_query_id=cq.id, text=text, show_alert=alert)
    except TgError:
        pass


# ==========================================================================
# Request object handed to every command handler
# ==========================================================================
class R:
    def __init__(self, msg, cmd, name, raw):
        self.msg, self.cmd, self.name, self.raw = msg, cmd, name, raw
        self.user, self.chat = msg.from_user, msg.chat
        self.cid = msg.chat.id
        self.args = raw.split()
        self.silent = False
        self.thread = msg.message_thread_id if msg.is_topic_message else None

    @property
    def connected(self):
        return self.cid != self.chat.id

    def reply(self, text, markup=None, kind="other", action=False, err=False, **kw):
        if self.silent and not err:
            return None
        if action and kind == "other":
            kind = "action"
        if action and not self.connected:
            topic = db.get(self.cid, "actiontopic")
            if topic:
                return send(self.cid, text, markup, thread=topic, kind=kind, **kw)
        return send(self.chat.id, text, markup, reply_to=self.msg.message_id, thread=self.thread, kind=kind, **kw)

    def error(self, text):
        return self.reply(text, kind="error", err=True)

    def t(self, key, **kw):
        return t(self.cid, key, **kw)

    def content(self, skip=0):
        return get_content(self.msg, skip)


# ==========================================================================
# Target resolution
# ==========================================================================
@dataclass
class Target:
    id: int
    name: str
    username: str = None
    rest: str = ""
    reply: object = None

    @property
    def mention(self):
        return mention(self.id, self.name)


def _lookup_username(un):
    row = db.one("SELECT user_id,name FROM users WHERE username=?", (un.lstrip("@").lower(),))
    if row:
        return row["user_id"], row["name"]
    try:
        c = bot.get_chat(chat_id="@" + un.lstrip("@"))
        if c and c.type == "private":
            return c.id, (c.first_name or un)
    except TgError:
        pass
    return None, None


def get_target(r, err=True):
    msg = r.msg
    rep = msg.reply_to_message
    if rep and not rep.forum_topic_created:
        u = rep.from_user
        if rep.sender_chat and (not u or u.id == ANON_ID):
            c = rep.sender_chat
            return Target(c.id, c.title or str(c.id), c.username, r.raw, rep)
        if u:
            track(u)
            return Target(u.id, full_name(u), u.username, r.raw, rep)
    if r.args:
        tok = r.args[0]
        rest = r.raw[len(tok):].strip()
        for e in (msg.entities or []):
            if e.type == "text_mention" and e.user:
                track(e.user)
                return Target(e.user.id, full_name(e.user), e.user.username, rest, None)
        uid = name = un = None
        if re.fullmatch(r"-?\d{5,}", tok):
            uid = int(tok)
            name = user_name(uid)
        elif tok.startswith("@") and len(tok) > 2:
            uid, name = _lookup_username(tok)
            un = tok.lstrip("@")
        if uid:
            return Target(uid, name, un, rest, None)
    if err:
        r.error(r.t("no_target"))
    return None


def guard_target(r, tg, action="do that to"):
    """Reject self / admin targets. Returns True when the action may proceed."""
    if tg.id == ME.id:
        r.error(r.t("target_self"))
        return False
    if tg.id > 0 and is_admin(r.cid, tg.id):
        r.error(r.t("target_admin"))
        return False
    return True


# ==========================================================================
# Saved content (notes, filters, welcome...), markdown, buttons, fillings
# ==========================================================================
MEDIA_TYPES = ("photo", "video", "document", "audio", "voice", "sticker", "animation", "video_note")
_SEND = {"photo": ("sendPhoto", "photo"), "video": ("sendVideo", "video"), "document": ("sendDocument", "document"),
         "audio": ("sendAudio", "audio"), "voice": ("sendVoice", "voice"), "sticker": ("sendSticker", "sticker"),
         "animation": ("sendAnimation", "animation"), "video_note": ("sendVideoNote", "video_note")}


def msg_html(m):
    if m.text:
        return entities_to_html(m.text, m.entities)
    return entities_to_html(m.caption or "", m.caption_entities)


def msg_media(m):
    for typ in MEDIA_TYPES:
        obj = m.get(typ)
        if obj:
            return typ, (obj[-1]["file_id"] if typ == "photo" else obj["file_id"])
    return None, None


def content_from_message(m):
    typ, fid = msg_media(m)
    return {"type": typ or "text", "file": fid, "text": msg_html(m), "fmt": "html"}


def args_text(msg, skip=0):
    """Text after the command (and `skip` further tokens), keeping any Telegram formatting."""
    text = msg.text or ""
    has_fmt = any(e.type in FORMAT_TYPES for e in (msg.entities or []))
    s = entities_to_html(text, msg.entities) if has_fmt else text
    s = re.sub(r"^[/!]\w+(@\w+)?[ \t]*", "", s, count=1)
    for _ in range(skip):
        s = re.sub(r"^\s*\S+[ \t]*", "", s, count=1)
    return s.strip(), ("html" if has_fmt else "md")


def get_content(msg, skip=0):
    text, fmt = args_text(msg, skip)
    rep = msg.reply_to_message
    if text:
        return {"type": "text", "file": None, "text": text, "fmt": fmt}
    if rep and (rep.text or rep.caption or msg_media(rep)[0]):
        return content_from_message(rep)
    return None


def parse_keys(s):
    s = (s or "").lstrip()
    if s.startswith('"'):
        m = re.match(r'"([^"]+)"\s*(.*)', s, re.S)
        if m:
            return [m.group(1)], m.group(2)
    if s.startswith("("):
        m = re.match(r"\(([^)]*)\)\s*(.*)", s, re.S)
        if m:
            return [k.strip().strip('"') for k in m.group(1).split(",") if k.strip()], m.group(2)
    parts = s.split(None, 1)
    if not parts:
        return [], ""
    return [parts[0]], (parts[1] if len(parts) > 1 else "")


def md_to_html(t_):
    store = []

    def hold(x):
        store.append(x)
        return f"\x00{len(store) - 1}\x00"

    t_ = _html.escape(t_, quote=False)
    t_ = re.sub(r"```(.+?)```", lambda m: hold(f"<pre>{m.group(1).strip(chr(10))}</pre>"), t_, flags=re.S)
    t_ = re.sub(r"`([^`\n]+)`", lambda m: hold(f"<code>{m.group(1)}</code>"), t_)
    t_ = re.sub(r"\[([^\[\]]+)\]\((\S+?)\)",
                lambda m: hold(f'<a href="{m.group(2).replace(chr(34), "%22")}">{m.group(1)}</a>'), t_)
    t_ = re.sub(r"\|\|(.+?)\|\|", r"<tg-spoiler>\1</tg-spoiler>", t_, flags=re.S)
    t_ = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"<b>\1</b>", t_, flags=re.S)
    t_ = re.sub(r"(?<![\w_])_(?!\s)(.+?)(?<!\s)_(?![\w_])", r"<i>\1</i>", t_, flags=re.S)
    t_ = re.sub(r"(?<!\w)~(?!\s)(.+?)(?<!\s)~(?!\w)", r"<s>\1</s>", t_)
    for _ in range(3):
        t_ = re.sub(r"\x00(\d+)\x00", lambda m: store[int(m.group(1))], t_)
    return t_


_BTN_MD = re.compile(r"\[([^\[\]]+?)\]\(buttonurl://([^\s)]+?)(:same)?\)")
_BTN_HTML = re.compile(r'<a href="buttonurl://([^"\s]+?)(:same)?">(.*?)</a>')
_FLAGS = ("{preview}", "{protect}", "{nonotif}", "{mediaspoiler}")


def _norm_url(u):
    u = _html.unescape(u)
    if u.startswith(("t.me", "telegram.me")) or "://" not in u:
        u = "https://" + u
    return u


def extract_buttons(text):
    rows = []

    def add(label, url, same):
        b = {"text": strip_tags(label), "url": _norm_url(url)}
        if same and rows:
            rows[-1].append(b)
        else:
            rows.append([b])
        return ""

    text = _BTN_MD.sub(lambda m: add(m.group(1), m.group(2), m.group(3)), text)
    text = _BTN_HTML.sub(lambda m: add(m.group(3), m.group(1), m.group(2)), text)
    return text.strip(), ({"inline_keyboard": rows} if rows else None)


def fill(text, user, chat, count=None):
    if user:
        first, last = user.first_name or "", user.last_name or ""
        rep = {"{first}": esc(first), "{last}": esc(last), "{fullname}": esc((first + " " + last).strip()),
               "{username}": ("@" + esc(user.username)) if user.username else mention(user.id, first or "user"),
               "{mention}": mention(user.id, first or "user"), "{id}": str(user.id)}
    else:
        rep = {}
    rep["{count}"] = str(count if count is not None else "")
    rep["{chatname}"] = esc(chat.title if chat and chat.title else "")
    for k, v in rep.items():
        text = text.replace(k, v)
    return text


def render(text, fmt, user=None, chat=None, count=None):
    """-> (html, reply_markup, flags)"""
    if "%%%" in text:
        text = random.choice([p.strip() for p in text.split("%%%") if p.strip()] or [text])
    flags = {f.strip("{}"): (f in text) for f in _FLAGS}
    for f in _FLAGS:
        text = text.replace(f, "")
    text, markup = extract_buttons(text)
    if fmt != "html":
        text = md_to_html(text)
    return fill(text, user, chat, count), markup, flags


def send_saved(chat_id, data, user=None, chat=None, reply_to=None, thread=None, noformat=False, count=None,
               kind="note", extra_buttons=None):
    text = data.get("text") or ""
    typ = data.get("type") or "text"
    if noformat:
        body, markup, flags = esc(text), None, {}
    else:
        body, markup, flags = render(text, data.get("fmt", "md"), user, chat, count)
    if extra_buttons:
        markup = markup or {"inline_keyboard": []}
        markup["inline_keyboard"] = markup["inline_keyboard"] + extra_buttons["inline_keyboard"]
    common = {"chat_id": chat_id}
    if reply_to:
        common["reply_parameters"] = {"message_id": reply_to, "allow_sending_without_reply": True}
    if thread:
        common["message_thread_id"] = thread
    if flags.get("nonotif"):
        common["disable_notification"] = True
    if flags.get("protect"):
        common["protect_content"] = True
    if typ == "text" or typ not in _SEND:
        return send(chat_id, body or "​", markup, reply_to=reply_to, thread=thread, kind=kind,
                    preview=bool(flags.get("preview")), notify=not flags.get("nonotif"),
                    protect=bool(flags.get("protect")))
    method, field_ = _SEND[typ]
    p = dict(common)
    p[field_] = data["file"]
    if typ not in ("sticker", "video_note"):
        if body:
            p["caption"] = body[:1024]
            p["parse_mode"] = "HTML"
        if markup:
            p["reply_markup"] = markup
        if typ in ("photo", "video", "animation") and flags.get("mediaspoiler"):
            p["has_spoiler"] = True
        try:
            m = bot.call(method, **p)
        except TgError as e:
            if not e.has("can't parse entities"):
                raise
            p["parse_mode"] = None
            p["caption"] = strip_tags(body)[:1024]
            m = bot.call(method, **p)
    else:
        m = bot.call(method, **p)
        if body or markup:
            send(chat_id, body or "​", markup, thread=thread, kind=kind)
    _autoclean(chat_id, m, kind)
    return m


# ==========================================================================
# Punishments
# ==========================================================================
VERB = {"ban": "banned", "tban": "temporarily banned", "kick": "kicked", "mute": "muted",
        "tmute": "temporarily muted", "warn": "warned"}


def punish(cid, uid, mode, seconds=None):
    until = int(time.time() + seconds) if seconds else None
    if mode in ("ban", "tban"):
        bot.ban_chat_member(chat_id=cid, user_id=uid, until_date=until if mode == "tban" else None)
    elif mode == "kick":
        bot.ban_chat_member(chat_id=cid, user_id=uid)
        bot.unban_chat_member(chat_id=cid, user_id=uid, only_if_banned=True)
    elif mode in ("mute", "tmute"):
        bot.restrict_chat_member(chat_id=cid, user_id=uid, permissions=NO_PERMS,
                                 until_date=until if mode == "tmute" else None)
    else:
        raise ValueError(mode)


def unrestrict(cid, uid):
    try:
        perms = dict(bot.get_chat(chat_id=cid).permissions or ALL_PERMS)
    except TgError:
        perms = ALL_PERMS
    bot.restrict_chat_member(chat_id=cid, user_id=uid, permissions=perms)


def parse_mode_args(args, allow=("ban", "mute", "kick", "tban", "tmute")):
    """['tban','3d'] -> ('tban', 259200, None) ; returns (mode, seconds, error)."""
    if not args:
        return None, None, "No mode given."
    mode = args[0].lower()
    if mode not in allow:
        return None, None, "Unknown mode. Choose one of: " + ", ".join(allow)
    secs = None
    if mode in ("tban", "tmute"):
        secs = parse_time(args[1]) if len(args) > 1 else None
        if not secs:
            return None, None, f"{mode} needs a time, e.g. <code>{mode} 3d</code>."
    return mode, secs, None


def mode_text(mode, secs):
    return mode + (f" {fmt_dur(secs)}" if secs else "")


def log_event(cid, category, text):
    """Send an event to the chat's log channel, if one is set and the category is enabled."""
    ch = db.get(cid, "logchannel")
    if not ch:
        return
    cats = db.get(cid, "logcats", ["settings", "admin", "user", "automated", "reports", "other"])
    if category not in cats:
        return
    title = db.one("SELECT title FROM chats WHERE chat_id=?", (cid,))
    head = f"<b>{esc(title['title'] if title else cid)}</b>\n<b>#{category.upper()}</b>\n"
    try:
        send(ch, head + text)
    except TgError as e:
        log.warning("log channel send failed: %s", e)


# ==========================================================================
# Files
# ==========================================================================
def send_file(chat_id, filename, data, caption=None, ctype="application/octet-stream", thread=None):
    return bot.call("sendDocument", _files={"document": (filename, data, ctype)}, chat_id=chat_id,
                    caption=caption, message_thread_id=thread, parse_mode="HTML" if caption else None)


def download_file(file_id, limit=5_000_000):
    import urllib.request
    f = bot.get_file(file_id=file_id)
    if f.file_size and f.file_size > limit:
        raise TgError(0, "file too large")
    with urllib.request.urlopen(f"{bot.base}/file/bot{bot.token}/{f.file_path}", timeout=60) as resp:
        return resp.read(limit + 1)


def sender_id(msg):
    """Effective sender: the channel for messages posted as a channel, else the user."""
    if msg.sender_chat and msg.sender_chat.id != msg.chat.id and not msg.is_automatic_forward:
        return msg.sender_chat.id
    return msg.from_user.id if msg.from_user else 0
