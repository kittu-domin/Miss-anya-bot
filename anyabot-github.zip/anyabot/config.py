"""Configuration. Values come from environment variables or a local .env file."""
import os
from pathlib import Path

_HERE = Path(__file__).resolve().parent


def _load_env() -> None:
    p = _HERE / ".env"
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env()

TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_ID = int(os.getenv("OWNER_ID", "0") or 0)           # bot owner: full access, can use /gban, /broadcast ...
DB_PATH = os.getenv("DB_PATH", str(_HERE / "anyabot.db"))
API_BASE = os.getenv("TG_API_BASE", "https://api.telegram.org")
WORKERS = int(os.getenv("WORKERS", "16"))
CLEANMSG_DELAY = int(os.getenv("CLEANMSG_DELAY", "300"))  # seconds before /cleanmsg deletes bot messages
SUPPORT_URL = os.getenv("SUPPORT_URL", "")                # optional support chat link shown in /start
DEFAULT_TZ = os.getenv("DEFAULT_TZ", "Asia/Kolkata")      # used by /nightmode and /time
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
