# AnyaBot

**Quality Telegram group management bot** — 213 commands, pure Python 3.9+ standard library.  
No `pip install`. No external dependencies.

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Zero deps](https://img.shields.io/badge/dependencies-none-brightgreen.svg)](#)

---

## Features

### Core
- Basics, connections, rules, admins, pins, approvals, purges, log channel
- Bans / mutes / kicks (`/ban`, `/tban`, `/sban`, `/dban`, `/mute`, `/tmute`, `/kick`, …)
- Warnings, reports, command disabling
- Welcome / goodbye, locks, allowlist
- CAPTCHA (button / math / text)
- Blocklists, antiflood, antiraid
- Federations (`/fban`, subscriptions, import / export)
- Filters, notes, echo, import / export, privacy
- Forum topics, cleaning, silent actions, bot-to-bot

### Extras
- Global bans (`/gban`), bot staff (sudo)
- `/afk`, night mode, `/top`, `/tagall`, `/chatinfo`
- `/setgtitle`, `/setgpic`, `/invitelink`
- `/calc`, `/wiki`, `/time`, `/bio`, `/dice`, `/flip`, `/decide`, `/8ball`, `/slap`, …
- Languages: **en / hi / es / id** (`/setlang`)

`/help` in private chat lists every module and command.

---

## Requirements

- **Python 3.9+** (standard library only)
- A Telegram bot token from [@BotFather](https://t.me/BotFather)
- Your numeric user ID (from [@userinfobot](https://t.me/userinfobot) or this bot’s `/id`)

---

## Setup

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/anyabot.git
cd anyabot

# 2. Config
cp .env.example .env
# Edit .env and set:
#   BOT_TOKEN=123456:ABC-your-token
#   OWNER_ID=your_numeric_telegram_id

# 3. Run
python3 main.py
```

### Bot permissions (important)

1. Add the bot to your group.
2. Promote it to **admin** with at least:
   - Delete messages  
   - Ban users  
   - Pin messages  
   - Invite users  
   - Change info  
   - Manage topics (if you use forums)
3. In [@BotFather](https://t.me/BotFather):  
   `/setprivacy` → select your bot → **Disable**  
   (so the bot can see all group messages — needed for locks, filters, flood, etc.)

---

## Configuration (`.env`)

| Variable         | Required | Description                                      |
|------------------|----------|--------------------------------------------------|
| `BOT_TOKEN`      | Yes      | Token from @BotFather                            |
| `OWNER_ID`       | Yes      | Your Telegram user ID (numeric)                  |
| `SUPPORT_URL`    | No       | Support chat/link shown in `/start`              |
| `DEFAULT_TZ`     | No       | Timezone for `/nightmode` and `/time` (default: `Asia/Kolkata`) |
| `CLEANMSG_DELAY` | No       | Seconds before bot messages are auto-cleaned (default: `300`) |
| `DB_PATH`        | No       | Path to SQLite DB (default: `anyabot.db`)        |
| `LOG_LEVEL`      | No       | `DEBUG` / `INFO` / `WARNING` / `ERROR`           |

---

## Data & backup

- All settings live in **`anyabot.db`** (SQLite).
- Back it up to keep notes, filters, federations, warns, etc.
- CAPTCHA challenges in progress are **in-memory** (lost on restart; users stay muted until an admin unmutes).

---

## Testing

Offline tests (fake Telegram API, no real token needed):

```bash
python3 tests/test_bot.py
```

13 scenarios cover ban/mute/kick, warns, locks, blocklist, notes, filters, welcome, captcha, flood, federation, PM help, calc, disable/cleancommand, export.

---

## Project layout

```
anyabot/
├── main.py          # Entry point
├── config.py        # Env / .env loading
├── core.py          # Command registry, permissions, send helpers
├── db.py            # SQLite storage
├── events.py        # Update router (commands, joins, callbacks…)
├── tg.py            # Minimal Telegram Bot API client
├── lang.py          # i18n (en/hi/es/id)
├── modules/
│   ├── antispam.py  # Locks, flood, raid, captcha, blocklist
│   ├── basics.py    # Start, help, id, rules, admins…
│   ├── extras.py    # Fun, utils, gban, afk, tagall…
│   ├── federations.py
│   ├── greetings.py
│   ├── misc.py      # Echo, import/export, topics, cleaning
│   ├── moderation.py
│   └── notes.py     # Notes & filters
├── tests/
│   └── test_bot.py
├── .env.example
├── .gitignore
└── LICENSE
```

---

## Notes

- Run **one instance per token**.
- Owner-only commands: `/gban`, `/broadcast`, `/addsudo`, …
- Sudo users can use staff commands without being the owner.

---

## License

[MIT](LICENSE) — Copyright (c) 2026 AnyaBot Contributors. Free to use, modify, and distribute.
