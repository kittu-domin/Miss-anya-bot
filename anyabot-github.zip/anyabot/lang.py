"""Tiny translation layer. Core messages exist in a few languages; everything else falls back to English."""
from db import db

LANGS = {"en": "English", "hi": "हिन्दी", "es": "Español", "id": "Bahasa Indonesia"}

T = {
    "en": {
        "start": "Hey <b>{name}</b>! I'm <b>{bot}</b>, a powerful group management bot.\n"
                 "Add me to your group, make me admin, and press /help to see everything I can do.",
        "help_intro": "Hey! I'm a group management bot. Pick a module below to see its commands.",
        "need_admin": "You need to be an admin to use this command.",
        "need_right": "You are missing the following right to use this command: <code>{right}</code>",
        "bot_need_right": "I'm missing the following right to do that: <code>{right}</code>",
        "no_target": "I don't know who you're talking about. Reply to a user, or give me their ID / @username.",
        "target_admin": "I can't do that to an admin.",
        "target_self": "I won't do that to myself.",
        "anon_warn": "You're an anonymous admin, so I can't verify your rights. Enable /anonadmin or use a normal account.",
        "group_only": "This command is made for groups. Use /connect in a group first.",
        "pm_only": "This command only works in a private chat with me.",
        "welcome_default": "Hey {first}, how are you?",
        "lang_set": "Language changed to <b>{lang}</b>.",
    },
    "hi": {
        "start": "नमस्ते <b>{name}</b>! मैं <b>{bot}</b> हूँ — एक शक्तिशाली ग्रुप मैनेजमेंट बॉट।\n"
                 "मुझे अपने ग्रुप में जोड़ें, एडमिन बनाएं और सभी कमांड देखने के लिए /help दबाएं।",
        "help_intro": "नमस्ते! मैं एक ग्रुप मैनेजमेंट बॉट हूँ। कमांड देखने के लिए नीचे से मॉड्यूल चुनें।",
        "need_admin": "यह कमांड इस्तेमाल करने के लिए आपका एडमिन होना ज़रूरी है।",
        "need_right": "इस कमांड के लिए आपके पास यह अधिकार नहीं है: <code>{right}</code>",
        "bot_need_right": "यह करने के लिए मेरे पास यह अधिकार नहीं है: <code>{right}</code>",
        "no_target": "मुझे समझ नहीं आया किसकी बात हो रही है। यूज़र को रिप्लाई करें या उसकी ID / @username दें।",
        "target_admin": "मैं किसी एडमिन पर यह नहीं कर सकता।",
        "target_self": "मैं खुद पर यह नहीं करूँगा।",
        "anon_warn": "आप गुमनाम एडमिन हैं, इसलिए मैं आपके अधिकार जाँच नहीं सकता। /anonadmin चालू करें।",
        "group_only": "यह कमांड ग्रुप के लिए है। पहले ग्रुप में /connect इस्तेमाल करें।",
        "pm_only": "यह कमांड सिर्फ मेरे साथ प्राइवेट चैट में काम करती है।",
        "welcome_default": "नमस्ते {first}, कैसे हैं आप?",
        "lang_set": "भाषा बदलकर <b>{lang}</b> कर दी गई है।",
    },
    "es": {
        "start": "¡Hola <b>{name}</b>! Soy <b>{bot}</b>, un potente bot para administrar grupos.\n"
                 "Añádeme a tu grupo, hazme admin y pulsa /help para ver todo lo que puedo hacer.",
        "help_intro": "¡Hola! Soy un bot de administración de grupos. Elige un módulo para ver sus comandos.",
        "need_admin": "Necesitas ser administrador para usar este comando.",
        "need_right": "Te falta este permiso para usar el comando: <code>{right}</code>",
        "bot_need_right": "Me falta este permiso para hacerlo: <code>{right}</code>",
        "no_target": "No sé de quién hablas. Responde a un usuario o dame su ID / @usuario.",
        "target_admin": "No puedo hacer eso con un administrador.",
        "target_self": "No haré eso conmigo mismo.",
        "anon_warn": "Eres admin anónimo, no puedo verificar tus permisos. Activa /anonadmin.",
        "group_only": "Este comando es para grupos. Usa /connect en un grupo primero.",
        "pm_only": "Este comando solo funciona en chat privado conmigo.",
        "welcome_default": "Hola {first}, ¿cómo estás?",
        "lang_set": "Idioma cambiado a <b>{lang}</b>.",
    },
    "id": {
        "start": "Halo <b>{name}</b>! Saya <b>{bot}</b>, bot manajemen grup yang kuat.\n"
                 "Tambahkan saya ke grup, jadikan admin, lalu tekan /help untuk melihat semua fitur.",
        "help_intro": "Halo! Saya bot manajemen grup. Pilih modul untuk melihat perintahnya.",
        "need_admin": "Kamu harus admin untuk memakai perintah ini.",
        "need_right": "Kamu tidak punya izin ini untuk perintah tersebut: <code>{right}</code>",
        "bot_need_right": "Saya tidak punya izin ini untuk melakukannya: <code>{right}</code>",
        "no_target": "Saya tidak tahu siapa maksudmu. Balas pesan pengguna atau beri ID / @username.",
        "target_admin": "Saya tidak bisa melakukannya pada admin.",
        "target_self": "Saya tidak akan melakukannya pada diri sendiri.",
        "anon_warn": "Kamu admin anonim, saya tidak bisa memeriksa izinmu. Aktifkan /anonadmin.",
        "group_only": "Perintah ini untuk grup. Pakai /connect di grup dulu.",
        "pm_only": "Perintah ini hanya bisa dipakai di chat pribadi dengan saya.",
        "welcome_default": "Halo {first}, apa kabar?",
        "lang_set": "Bahasa diubah ke <b>{lang}</b>.",
    },
}


def t(cid, key, **kw):
    lang = db.get(cid, "lang", "en")
    s = T.get(lang, T["en"]).get(key) or T["en"][key]
    return s.format(**kw) if kw else s
