"""Update router: commands, callbacks, service messages, joins/leaves and the automatic protections."""
import logging
import re
import threading
import time
from collections import defaultdict

import config
import core as C
from core import esc, full_name, mention
from db import db
from modules import (antispam, basics, extras, federations, greetings, misc, moderation, notes)  # noqa: F401
from tg import POOL, D, TgError

log = logging.getLogger("anyabot")
CMD_RE = re.compile(r"^[/!](\w+)(?:@(\w+))?(?:\s+(.*))?$", re.S)
ADMIN_PING = re.compile(r"(?i)(^|\s)@admins?\b")
SERVICE_KEYS = {"new_chat_members", "left_chat_member", "new_chat_title", "new_chat_photo", "delete_chat_photo",
                "group_chat_created", "supergroup_chat_created", "channel_chat_created", "migrate_to_chat_id",
                "migrate_from_chat_id", "pinned_message", "message_auto_delete_timer_changed", "video_chat_started",
                "video_chat_ended", "video_chat_scheduled", "video_chat_participants_invited", "forum_topic_created",
                "forum_topic_edited", "forum_topic_closed", "forum_topic_reopened", "general_forum_topic_hidden",
                "general_forum_topic_unhidden", "boost_added", "chat_background_set", "write_access_allowed"}
ALLOWED_UPDATES = ["message", "edited_message", "channel_post", "callback_query", "my_chat_member"]


# ==========================================================================
# Authorization
# ==========================================================================
def authorize(r):
    cmd, uid, cid = r.cmd, r.user.id, r.cid
    if cmd.owner and uid != config.OWNER_ID:
        r.error("🚫 Only the bot owner can use this command.")
        return False
    if cmd.sudo and not C.is_sudo(uid):
        r.error("🚫 Only bot staff can use this command.")
        return False
    if not (cmd.admin or cmd.rights):
        return True
    anon = uid == C.ANON_ID or (r.msg.sender_chat and r.msg.sender_chat.id == r.chat.id)
    bot_sender = r.user.is_bot and uid != C.ANON_ID
    if C.is_sudo(uid) or (bot_sender and db.get(cid, "b2b_skip", False)):
        pass
    elif anon:
        if not db.get(cid, "anonadmin", False):
            r.error(r.t("anon_warn"))
            return False
    else:
        m = C.member(cid, uid)
        if not m or m.status not in ("creator", "administrator"):
            if db.get(cid, "adminerror", True):
                r.error(r.t("need_admin"))
            return False
        for rt in cmd.rights:
            if not C.has_right(m, rt):
                r.error(r.t("need_right", right=rt))
                return False
    if cmd.rights:
        bm = C.bot_member(cid)
        for rt in cmd.rights:
            if not C.has_right(bm, rt):
                r.error(r.t("bot_need_right", right=rt))
                return False
    return True


# ==========================================================================
# Commands
# ==========================================================================
def _clean_command(msg, cmd):
    types = db.get(msg.chat.id, "cleancmd", [])
    if not types:
        return
    admin_cmd = bool(cmd and (cmd.admin or cmd.rights))
    if "all" in types or (cmd is None and "other" in types) or (cmd and admin_cmd and "admin" in types) \
            or (cmd and not admin_cmd and "user" in types):
        C.delete_msg(msg.chat.id, msg.message_id)


def dispatch_command(msg):
    m = CMD_RE.match(msg.text or "")
    if not m or not msg.from_user:
        return False
    name, tbot, raw = m.group(1).lower(), m.group(2), (m.group(3) or "").strip()
    if tbot and tbot.lower() != C.ME.username.lower():
        if msg.chat.type != "private" and msg.text[0] == "/":
            _clean_command(msg, None)
        return False
    cmd = C.REGISTRY.get(name)
    if not cmd:
        if msg.chat.type != "private" and msg.text[0] == "/":
            _clean_command(msg, None)
        return False
    user, chat = msg.from_user, msg.chat
    if user.is_bot and user.id != C.ANON_ID:
        allowed = db.get(chat.id, "bot2bot", [])
        if "*" not in allowed and (user.username or "").lower() not in allowed:
            return False
    r = C.R(msg, cmd, name, raw)
    if chat.type == "private":
        if cmd.scope == "group":
            row = db.one("SELECT chat_id FROM conns WHERE user_id=?", (user.id,))
            if not (row and row["chat_id"]):
                r.error(r.t("group_only"))
                return True
            r.cid = row["chat_id"]
    elif cmd.scope == "pm":
        r.reply(r.t("pm_only"), C.kb([[("Open PM", f"https://t.me/{C.ME.username}")]]), err=True)
        return True
    if r.cid < 0 and cmd.disableable and cmd.name in db.get(r.cid, "disabled", []):
        if db.get(r.cid, "disableadmin", False) or not C.is_admin(r.cid, user.id):
            if db.get(r.cid, "disabledel", False):
                C.delete_msg(chat.id, msg.message_id)
            return True
    try:
        if authorize(r):
            if cmd.action and db.get(r.cid, "silentactions", False):
                r.silent = True
            cmd.func(r)
    except TgError as e:
        log.info("/%s failed: %s", name, e)
        r.error(f"❌ {esc(e.desc or 'Telegram error')}")
    except Exception:  # noqa: BLE001
        log.exception("/%s crashed", name)
        r.error("😵 Something went wrong while running that command.")
    if r.silent:
        C.delete_msg(chat.id, msg.message_id)
    elif chat.type != "private":
        _clean_command(msg, cmd)
    return True


# ==========================================================================
# Messages
# ==========================================================================
def is_service(msg):
    return any(k in msg for k in SERVICE_KEYS)


def on_message(msg):
    chat, user = msg.chat, msg.from_user
    C.track(user)
    if msg.reply_to_message and msg.reply_to_message.from_user:
        C.track(msg.reply_to_message.from_user)
    if chat.type == "private":
        if msg.text and msg.text[:1] in "/!":
            dispatch_command(msg)
        return
    C.track_chat(chat)
    if is_service(msg):
        return on_service(msg)
    if moderation.handle_forwarded_setlog(msg):
        return
    cid = chat.id
    if msg.is_automatic_forward and db.get(cid, "cleanlinked", False):
        return C.delete_msg(cid, msg.message_id)
    sid = C.sender_id(msg)
    if user and sid == user.id and user.id not in (C.ANON_ID, C.TG_ID) and not user.is_bot:
        extras.count_message(cid, user.id)
        if not C.is_admin(cid, user.id) and federations.enforce(cid, user):
            return C.delete_msg(cid, msg.message_id)
    if not C.exempt(cid, sid) and antispam.check_message(msg):
        return
    is_cmd = bool(msg.text and msg.text[:1] in "/!" and not msg.forward_origin and dispatch_command(msg))
    if msg.text and ADMIN_PING.search(msg.text) and msg.reply_to_message:
        moderation.do_report(msg)
    if is_cmd:
        return
    if msg.text and msg.text.startswith("#"):
        notes.hash_note(msg)
    notes.check_filters(msg)
    extras.afk_check(msg)


def on_edited(msg):
    chat = msg.chat
    if chat.type == "private" or not msg.from_user or C.exempt(chat.id, C.sender_id(msg)):
        return
    if antispam._check_blocklist(msg):
        return
    antispam._check_locks(msg)


def on_channel_post(msg):
    if (msg.text or "").startswith("/setlog"):
        moderation.channel_setlog(msg)


# ==========================================================================
# Service messages: joins, leaves, pins
# ==========================================================================
def on_service(msg):
    cid = msg.chat.id
    if msg.new_chat_members:
        on_join(msg)
    if msg.left_chat_member:
        on_leave(msg)
    if msg.pinned_message and db.get(cid, "antichannelpin", False) and msg.pinned_message.is_automatic_forward:
        try:
            C.bot.unpin_chat_message(chat_id=cid, message_id=msg.pinned_message.message_id)
            last = db.get(cid, "lastpin")
            if last:
                C.bot.pin_chat_message(chat_id=cid, message_id=last, disable_notification=True)
        except TgError:
            pass
    types = db.get(cid, "cleansvc", [])
    if types and ("all" in types or misc.service_kind(msg) in types):
        C.delete_msg(cid, msg.message_id)


def on_join(msg):
    cid, adder, chat = msg.chat.id, msg.from_user, msg.chat
    for u in msg.new_chat_members:
        C.track(u)
        if u.id == C.ME.id:
            C.track_chat(chat)
            C.clear_admin_cache(cid)
            try:
                C.send(cid, "👋 Thanks for adding me! Make me an <b>admin</b> so I can moderate, then use /help.")
            except TgError:
                pass
            continue
        if federations.enforce(cid, u):
            continue
        if not u.is_bot and antispam.raid_on_join(cid, u.id):
            continue
        if u.is_bot and "bot" in db.get(cid, "locks", []) and adder and not C.exempt(cid, adder.id):
            try:
                C.punish(cid, u.id, "kick")
                C.send(cid, f"🤖 Bots can't be added here (locked): {mention(u.id, full_name(u))} was removed.",
                       kind="action")
            except TgError:
                pass
            continue
        if db.get(cid, "captcha", False) and not u.is_bot and antispam.start_captcha(cid, u, chat):
            continue
        greetings.send_welcome(cid, u, chat)
        C.log_event(cid, "user", f"{mention(u.id, full_name(u))} joined")


def on_leave(msg):
    cid, u, chat = msg.chat.id, msg.left_chat_member, msg.chat
    if u.id == C.ME.id:
        return
    st = antispam.PENDING.pop((cid, u.id), None)
    if st:
        C.delete_msg(cid, st["mid"])
    greetings.send_goodbye(cid, u, chat)
    C.log_event(cid, "user", f"{mention(u.id, full_name(u))} left")


def on_my_chat_member(upd):
    new = upd.new_chat_member
    chat = upd.chat
    if chat.type == "private" or not new:
        return
    if new.status in ("left", "kicked"):
        db.x("DELETE FROM chats WHERE chat_id=?", (chat.id,))
    else:
        C.track_chat(chat)
    C.clear_admin_cache(chat.id)


# ==========================================================================
# Callbacks
# ==========================================================================
def on_callback(cq):
    C.track(cq["from"] if isinstance(cq["from"], D) else D(cq["from"]))
    data = cq.data or ""
    for prefix, fn in C.CALLBACKS:
        if data.startswith(prefix):
            try:
                fn(cq, data[len(prefix):])
            except TgError as e:
                log.info("callback %s failed: %s", prefix, e)
                C.answer(cq, (e.desc or "Error")[:150], True)
            except Exception:  # noqa: BLE001
                log.exception("callback %s crashed", prefix)
                C.answer(cq, "Something went wrong.", True)
            return
    C.answer(cq)


# ==========================================================================
# Entry points
# ==========================================================================
def handle_update(raw):
    u = D(raw)
    try:
        if u.message:
            on_message(u.message)
        elif u.edited_message:
            on_edited(u.edited_message)
        elif u.callback_query:
            on_callback(u.callback_query)
        elif u.channel_post:
            on_channel_post(u.channel_post)
        elif u.my_chat_member:
            on_my_chat_member(u.my_chat_member)
    except Exception:  # noqa: BLE001
        log.exception("update %s crashed", raw.get("update_id"))


_locks = defaultdict(threading.RLock)


def _chat_key(raw):
    for k in ("message", "edited_message", "channel_post", "my_chat_member"):
        if k in raw:
            return raw[k]["chat"]["id"]
    if "callback_query" in raw:
        m = raw["callback_query"].get("message")
        return m["chat"]["id"] if m else 0
    return 0


def _run(raw):
    with _locks[_chat_key(raw)]:        # one update at a time per chat keeps flood/captcha state consistent
        handle_update(raw)


def submit(raw):
    return POOL.submit(_run, raw)


def command_menu():
    """Commands shown in Telegram's '/' menu."""
    users = ["start", "help", "rules", "notes", "get", "filters", "warns", "report", "id", "info", "adminlist",
             "connect", "setlang", "afk", "top", "ping", "time", "calc", "wiki", "flip", "dice"]
    admins = users + ["ban", "tban", "mute", "tmute", "kick", "unban", "unmute", "warn", "lock", "unlock", "locks",
                      "purge", "pin", "unpin", "promote", "demote", "save", "filter", "setwelcome", "welcome",
                      "setrules", "addblocklist", "setflood", "captcha", "antiraid", "approve", "newfed", "fban"]
    return users, admins


def setup(bot):
    from tg import every  # noqa: F401
    extras.start_jobs()
    descr = lambda n: (C.REGISTRY[n].help or n)[:250]  # noqa: E731
    users, admins = command_menu()
    try:
        bot.delete_webhook()
        bot.set_my_commands(commands=[{"command": n, "description": descr(n)} for n in users if n in C.REGISTRY])
        bot.set_my_commands(commands=[{"command": n, "description": descr(n)} for n in admins if n in C.REGISTRY],
                            scope={"type": "all_chat_administrators"})
    except TgError as e:
        log.warning("couldn't set command menu: %s", e)


def run_polling(bot, stop=None):
    offset, backoff = None, 1
    stop = stop or threading.Event()
    while not stop.is_set():
        try:
            ups = bot.call("getUpdates", _timeout=70, offset=offset, timeout=50, allowed_updates=ALLOWED_UPDATES)
            backoff = 1
        except TgError as e:
            log.warning("getUpdates failed: %s", e)
            if e.code == 409:
                log.error("Another instance is polling with this token (or a webhook is set).")
            time.sleep(min(backoff, 30))
            backoff *= 2
            continue
        for u in ups:
            offset = u["update_id"] + 1
            submit(u)
