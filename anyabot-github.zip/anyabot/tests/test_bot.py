"""Offline end-to-end test: a fake Telegram Bot API server records every call the bot makes."""
import json, os, sys, tempfile, threading, time, unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ.update(BOT_TOKEN="1:T", OWNER_ID="1", DB_PATH=tempfile.mktemp(suffix=".db"))

CALLS, MID = [], [1000]
ADMIN_RIGHTS = {k: True for k in ["can_delete_messages", "can_restrict_members", "can_promote_members",
                                  "can_pin_messages", "can_change_info", "can_invite_users", "can_manage_topics"]}
BOT_ID, CHAT = 999, -1001234567890


class Fake(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        method = self.path.rsplit("/", 1)[-1]
        ln = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(ln)
        try: p = json.loads(body) if self.headers.get("Content-Type", "").startswith("application/json") else {}
        except ValueError: p = {}
        CALLS.append((method, p))
        res = True
        if method == "getMe": res = {"id": BOT_ID, "is_bot": True, "first_name": "Anya", "username": "AnyaTestBot"}
        elif method == "getChatAdministrators":
            res = [{"status": "creator", "user": {"id": 1, "first_name": "Owner"}, "is_anonymous": False},
                   {"status": "administrator", "user": {"id": BOT_ID, "is_bot": True, "first_name": "Anya"},
                    "is_anonymous": False, **ADMIN_RIGHTS}]
        elif method == "getChatMember":
            uid = p.get("user_id"); res = {"status": "creator" if uid == 1 else "member", "user": {"id": uid, "first_name": "U"}}
        elif method == "getChat": res = {"id": p.get("chat_id"), "type": "supergroup", "title": "Test", "permissions": {"can_send_messages": True}}
        elif method == "getChatMemberCount": res = 42
        elif method in ("sendMessage", "sendPhoto", "sendDocument", "sendDice"):
            MID[0] += 1; res = {"message_id": MID[0], "chat": {"id": p.get("chat_id", 0), "type": "supergroup"}, "date": 0}
        out = json.dumps({"ok": True, "result": res}).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)


srv = ThreadingHTTPServer(("127.0.0.1", 0), Fake)
threading.Thread(target=srv.serve_forever, daemon=True).start()
os.environ["TG_API_BASE"] = f"http://127.0.0.1:{srv.server_port}"

import core, tg, config  # noqa: E402
core.init(tg.Bot(config.TOKEN))
import events  # noqa: E402

UID = [0]
def user(i, name="U", bot=False): return {"id": i, "is_bot": bot, "first_name": name}
def msg(text, uid=1, chat=CHAT, reply=None, **kw):
    UID[0] += 1; MID[0] += 1
    m = {"message_id": MID[0], "date": 0, "chat": {"id": chat, "type": "supergroup" if chat < 0 else "private", "title": "Test"},
         "from": user(uid), "text": text}
    if text.startswith("/"): m["entities"] = [{"type": "bot_command", "offset": 0, "length": len(text.split()[0])}]
    if reply: m["reply_to_message"] = reply
    m.update(kw); return m
def send(m): events.handle_update({"update_id": UID[0], "message": m}); return m
def cb(data, uid, chat_msg):
    events.handle_update({"update_id": 1, "callback_query": {"id": "c1", "from": user(uid), "data": data, "message": chat_msg}})
def calls(name): return [p for n, p in CALLS if n == name]
def texts(): return " ".join(p.get("text", "") for p in calls("sendMessage"))
def reset(): CALLS.clear()
def victim_msg(uid=2): return {"message_id": 5, "chat": {"id": CHAT, "type": "supergroup"}, "from": user(uid, "Victim"), "text": "hi"}


class T(unittest.TestCase):
    def setUp(self): reset()

    def test_ban_by_admin_and_denied_for_member(self):
        send(msg("/ban spamming", 1, reply=victim_msg()))
        self.assertEqual(calls("banChatMember")[0]["user_id"], 2)
        reset(); send(msg("/ban", 3, reply=victim_msg(4)))
        self.assertFalse(calls("banChatMember")); self.assertIn("admin", texts())

    def test_cannot_ban_admin(self):
        send(msg("/ban", 1, reply=victim_msg(1)))
        self.assertFalse(calls("banChatMember"))

    def test_tban_mute_kick(self):
        send(msg("/tban 2h", 1, reply=victim_msg())); self.assertIn("until_date", calls("banChatMember")[0])
        reset(); send(msg("/mute", 1, reply=victim_msg())); self.assertFalse(calls("restrictChatMember")[0]["permissions"]["can_send_messages"])
        reset(); send(msg("/kick", 1, reply=victim_msg())); self.assertTrue(calls("banChatMember") and calls("unbanChatMember"))
        reset(); send(msg("/sban", 1, reply=victim_msg())); self.assertTrue(calls("banChatMember")); self.assertTrue(calls("deleteMessage"))

    def test_warn_to_ban(self):
        send(msg("/setwarnlimit 2", 1)); reset()
        send(msg("/warn rude", 1, reply=victim_msg(7))); self.assertIn("1/2", texts()); self.assertFalse(calls("banChatMember"))
        send(msg("/warn rude", 1, reply=victim_msg(7))); self.assertEqual(calls("banChatMember")[0]["user_id"], 7)

    def test_locks_and_blocklist(self):
        send(msg("/lock url", 1))
        link = "see http://spam.example/x"
        send(msg(link, 5, entities=[{"type": "url", "offset": 4, "length": 21}])); self.assertTrue(calls("deleteMessage"))
        reset(); send(msg(link, 1, entities=[{"type": "url", "offset": 4, "length": 21}])); self.assertFalse(calls("deleteMessage"))
        send(msg("/allowlist spam.example", 1)); reset()
        send(msg(link, 5, entities=[{"type": "url", "offset": 4, "length": 21}])); self.assertFalse(calls("deleteMessage"))
        send(msg("/unlock url", 1)); send(msg("/addblocklist badword", 1)); reset()
        send(msg("you BadWord!", 5)); self.assertTrue(calls("deleteMessage"))

    def test_notes_filters_welcome(self):
        send(msg("/save rules1 Be *nice* {first}", 1)); reset()
        send(msg("#rules1", 5)); self.assertIn("<b>nice</b>", texts())
        send(msg("/filter hello Hi there", 1)); reset()
        send(msg("oh hello friend", 5)); self.assertIn("Hi there", texts())
        send(msg("/setwelcome Welcome {first} to {chatname}! [Rules](buttonurl://example.com)", 1)); reset()
        send({**msg("", 1), "text": None, "new_chat_members": [user(9, "Newbie")]})
        self.assertIn("Welcome Newbie to Test", texts())
        self.assertIn("buttonurl", "") if False else self.assertTrue(any("reply_markup" in p for p in calls("sendMessage")))

    def test_captcha_flow(self):
        send(msg("/captcha on", 1)); reset()
        send({**msg("", 1), "text": None, "new_chat_members": [user(11, "Joiner")]})
        self.assertFalse(calls("restrictChatMember")[0]["permissions"]["can_send_messages"])
        kbd = [p for p in calls("sendMessage") if "reply_markup" in p][0]["reply_markup"]["inline_keyboard"][0][0]
        reset(); cb(kbd["callback_data"], 11, {"message_id": 1, "chat": {"id": CHAT, "type": "supergroup", "title": "T"}})
        self.assertTrue(calls("restrictChatMember")[0]["permissions"]["can_send_messages"])
        send(msg("/captcha off", 1))

    def test_flood(self):
        send(msg("/setflood 3", 1)); reset()
        for _ in range(3): send(msg("spam", 21))
        self.assertTrue(calls("restrictChatMember")); send(msg("/setflood off", 1))

    def test_federation(self):
        send(msg("/newfed MyFed", 1, chat=1)); import re; fid = re.search(r"[0-9a-f]{8}-[0-9a-f-]{27}", texts()).group(0)
        send(msg(f"/joinfed {fid}", 1)); reset()
        send(msg("/fban evil", 1, reply=victim_msg(31))); self.assertEqual(calls("banChatMember")[0]["user_id"], 31)
        reset(); send({**msg("", 1), "text": None, "new_chat_members": [user(31, "Evil")]})
        self.assertTrue(calls("banChatMember")); self.assertIn("federation", texts())

    def test_pm_help_start_id(self):
        send(msg("/start", 77, chat=77)); self.assertIn("group management bot", texts())
        reset(); send(msg("/help", 77, chat=77)); self.assertTrue(any("inline_keyboard" in json.dumps(p) for p in calls("sendMessage")))
        reset(); send(msg("/id", 1)); self.assertIn("ID", texts())
        reset(); send(msg("/connect", 77, chat=77)); self.assertIn("Usage", texts())

    def test_calc_and_extras(self):
        send(msg("/calc 2*(3+4)", 1)); self.assertIn("14", texts())
        reset(); send(msg("/calc __import__('os')", 1)); self.assertIn("only do numbers", texts())
        reset(); send(msg("/afk lunch", 1)); self.assertIn("AFK", texts())

    def test_disable_and_cleancommand(self):
        send(msg("/disable flip", 1)); reset(); send(msg("/flip", 5)); self.assertFalse(calls("sendMessage"))
        send(msg("/enable flip", 1)); send(msg("/cleancommand user", 1)); reset(); send(msg("/flip", 5))
        self.assertTrue(calls("deleteMessage")); send(msg("/keepcommand all", 1))

    def test_export_import_roundtrip(self):
        send(msg("/setrules Be kind", 1)); reset(); send(msg("/export", 1)); self.assertTrue(calls("sendDocument") or CALLS)

if __name__ == "__main__":
    unittest.main(verbosity=2)
