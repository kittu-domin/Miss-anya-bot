"""Moderation: admins, pins, approvals, purges, log channel, bans/mutes/kicks, warns, reports, disabling."""
import time

import core as C
from core import callback, command, esc, full_name, kb, mention
from db import db
from tg import TgError

PROMOTE_RIGHTS = ["can_delete_messages", "can_restrict_members", "can_invite_users", "can_pin_messages",
                  "can_manage_video_chats", "can_manage_topics"]


def me_text(u):
    return mention(u.id, full_name(u))


def msg_link(chat, mid):
    if chat.username:
        return f"https://t.me/{chat.username}/{mid}"
    cid = str(chat.id)
    return f"https://t.me/c/{cid[4:] if cid.startswith('-100') else cid.lstrip('-')}/{mid}"


# ==========================================================================
# Admins
# ==========================================================================
@command("promote", module="admin", rights=("can_promote_members",), action=True,
         h="Promote a user to admin (optional custom title)")
def promote(r):
    tg = C.get_target(r)
    if not tg:
        return
    if tg.id == C.ME.id:
        return r.error(r.t("target_self"))
    if C.is_admin(r.cid, tg.id):
        return r.error("This user is already an admin.")
    bm = C.bot_member(r.cid)
    grant = {k: True for k in PROMOTE_RIGHTS if C.has_right(bm, k)}
    C.bot.promote_chat_member(chat_id=r.cid, user_id=tg.id, **grant)
    title = tg.rest.strip()[:16]
    if title:
        try:
            C.bot.set_chat_administrator_custom_title(chat_id=r.cid, user_id=tg.id, custom_title=title)
        except TgError:
            pass
    C.clear_admin_cache(r.cid)
    r.reply(f"✅ Promoted {tg.mention}" + (f" with title <b>{esc(title)}</b>" if title else "") + ".", action=True)
    C.log_event(r.cid, "admin", f"{me_text(r.user)} promoted {tg.mention}")


@command("demote", module="admin", rights=("can_promote_members",), action=True,
         h="Demote an admin (only works on admins I promoted)")
def demote(r):
    tg = C.get_target(r)
    if not tg:
        return
    m = C.member(r.cid, tg.id)
    if not m or m.status != "administrator":
        return r.error("Only administrators can be demoted (the chat owner can't).")
    try:
        C.bot.promote_chat_member(chat_id=r.cid, user_id=tg.id, **{k: False for k in PROMOTE_RIGHTS + [
            "can_change_info", "can_promote_members", "can_manage_chat", "is_anonymous"]})
    except TgError:
        return r.error("I can't demote this user — they were probably promoted by someone else.")
    C.clear_admin_cache(r.cid)
    r.reply(f"✅ Demoted {tg.mention}.", action=True)
    C.log_event(r.cid, "admin", f"{me_text(r.user)} demoted {tg.mention}")


@command("adminlist", "admins", module="admin", scope="group", h="List the chat's admins")
def adminlist(r):
    d = C.admins(r.cid, fresh=True)
    owner = [m for m in d.values() if m.status == "creator"]
    rest = sorted((m for m in d.values() if m.status != "creator" and not m.user.is_bot),
                  key=lambda m: full_name(m.user).lower())
    lines = ["<b>Admins in this chat:</b>"]
    for m in owner + rest:
        tag = " 👑" if m.status == "creator" else ""
        title = f" — <i>{esc(m.custom_title)}</i>" if m.custom_title else ""
        lines.append(f"• {mention(m.user.id, full_name(m.user))}{tag}{title}")
    r.reply("\n".join(lines))


@command("adminerror", module="admin", admin=True, h="Show an error when non-admins use admin commands: on/off")
def adminerror(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Admin errors: {C.flag(db.get(r.cid, 'adminerror', True))}")
    db.set(r.cid, "adminerror", v)
    r.reply(f"Admin errors {'enabled' if v else 'disabled'}.")


@command("anonadmin", module="admin", admin=True, h="Trust anonymous admins to run admin commands: on/off")
def anonadmin(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Anonymous admin mode: {C.flag(db.get(r.cid, 'anonadmin', False))}\n"
                       "When on, anyone posting as the group (anonymous admin) can use admin commands.")
    db.set(r.cid, "anonadmin", v)
    r.reply(f"Anonymous admin mode {'enabled' if v else 'disabled'}.")


@command("admincache", module="admin", admin=True, h="Refresh my cached admin list")
def admincache(r):
    d = C.admins(r.cid, fresh=True)
    r.reply(f"✅ Admin cache refreshed ({len(d)} admins).")


# ==========================================================================
# Pins
# ==========================================================================
@command("pin", module="pins", rights=("can_pin_messages",), h="Pin the replied message (add 'loud' to notify)")
def pin(r):
    rep = r.msg.reply_to_message
    if not rep:
        return r.error("Reply to a message to pin it.")
    loud = bool(r.args and r.args[0].lower() in ("loud", "notify", "violent"))
    C.bot.pin_chat_message(chat_id=r.cid, message_id=rep.message_id, disable_notification=not loud)
    db.set(r.cid, "lastpin", rep.message_id)
    r.reply("📌 Message pinned.", kb([[("View", msg_link(r.chat, rep.message_id))]]), action=True)


@command("permapin", module="pins", rights=("can_pin_messages",),
         h="Make me send & pin a message (text or reply)")
def permapin(r):
    c = r.content()
    if not c:
        return r.error("Give me some text, or reply to a message, and I'll post and pin it.")
    m = C.send_saved(r.cid, c, r.user, r.chat, thread=r.thread, kind="other")
    C.bot.pin_chat_message(chat_id=r.cid, message_id=m.message_id, disable_notification=True)
    db.set(r.cid, "lastpin", m.message_id)


@command("unpin", module="pins", rights=("can_pin_messages",), h="Unpin the replied (or latest) message")
def unpin(r):
    rep = r.msg.reply_to_message
    C.bot.unpin_chat_message(chat_id=r.cid, message_id=rep.message_id if rep else None)
    r.reply("📍 Message unpinned.", action=True)


@command("unpinall", module="pins", rights=("can_pin_messages",), h="Unpin every message (asks for confirmation)")
def unpinall(r):
    r.reply("Do you really want to unpin <b>all</b> messages in this chat?",
            kb([[("Yes, unpin all", f"cb:unpinall:yes:{r.cid}"), ("Cancel", f"cb:unpinall:no:{r.cid}")]]))


@callback("unpinall:")
def cb_unpinall(cq, data):
    ans, _, cid = data.partition(":")
    cid = int(cid)
    if not C.has_right(C.member(cid, cq["from"]["id"]), "can_pin_messages"):
        return C.answer(cq, "You need the pin-messages right.", True)
    if ans == "yes":
        C.bot.unpin_all_chat_messages(chat_id=cid)
        C.edit(cq, "📍 All messages unpinned.")
    else:
        C.edit(cq, "Cancelled.")
    C.answer(cq)


@command("antichannelpin", module="pins", rights=("can_pin_messages",),
         h="Stop the linked channel from replacing the pinned message: on/off")
def antichannelpin(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Anti-channel-pin: {C.flag(db.get(r.cid, 'antichannelpin', False))}")
    db.set(r.cid, "antichannelpin", v)
    r.reply(f"Anti-channel-pin {'enabled' if v else 'disabled'}.")


@command("cleanlinked", module="pins", rights=("can_delete_messages",),
         h="Delete messages auto-forwarded from the linked channel: on/off")
def cleanlinked(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Clean linked channel posts: {C.flag(db.get(r.cid, 'cleanlinked', False))}")
    db.set(r.cid, "cleanlinked", v)
    r.reply(f"Clean linked {'enabled' if v else 'disabled'}.")


# ==========================================================================
# Approvals
# ==========================================================================
@command("approve", module="approvals", admin=True, h="Approve a user: they ignore locks, blocklist, flood")
def approve(r):
    tg = C.get_target(r)
    if not tg:
        return
    if C.is_admin(r.cid, tg.id):
        return r.error("Admins are always exempt, no need to approve them.")
    db.x("INSERT OR IGNORE INTO approvals VALUES(?,?)", (r.cid, tg.id))
    r.reply(f"✅ {tg.mention} has been approved.")


@command("unapprove", module="approvals", admin=True, h="Remove a user's approval")
def unapprove(r):
    tg = C.get_target(r)
    if not tg:
        return
    db.x("DELETE FROM approvals WHERE chat_id=? AND user_id=?", (r.cid, tg.id))
    r.reply(f"❎ {tg.mention} is no longer approved.")


@command("approval", module="approvals", admin=True, h="Check whether a user is approved")
def approval(r):
    tg = C.get_target(r, err=False) or C.Target(r.user.id, full_name(r.user))
    yes = C.is_approved(r.cid, tg.id)
    r.reply(f"{tg.mention} is {'✅ approved' if yes else '❌ not approved'} in this chat.")


@command("approved", module="approvals", admin=True, h="List approved users")
def approved(r):
    rows = db.all("SELECT user_id FROM approvals WHERE chat_id=?", (r.cid,))
    if not rows:
        return r.reply("No users are approved in this chat.")
    r.reply("<b>Approved users:</b>\n" + "\n".join(f"• {mention(x['user_id'], C.user_name(x['user_id']))}"
                                                  for x in rows))


@command("unapproveall", module="approvals", admin=True, h="Remove all approvals (asks for confirmation)")
def unapproveall(r):
    r.reply("Remove <b>all</b> approved users from this chat?",
            kb([[("Yes", f"cb:unapproveall:yes:{r.cid}"), ("Cancel", f"cb:unapproveall:no:{r.cid}")]]))


@callback("unapproveall:")
def cb_unapproveall(cq, data):
    ans, _, cid = data.partition(":")
    cid = int(cid)
    if not C.is_admin(cid, cq["from"]["id"]):
        return C.answer(cq, "Admins only.", True)
    if ans == "yes":
        db.x("DELETE FROM approvals WHERE chat_id=?", (cid,))
        C.edit(cq, "All approvals removed.")
    else:
        C.edit(cq, "Cancelled.")
    C.answer(cq)


# ==========================================================================
# Purges
# ==========================================================================
def _delete_range(cid, start, end):
    ids = list(range(start, end + 1))
    for i in range(0, len(ids), 100):
        try:
            C.bot.delete_messages(chat_id=cid, message_ids=ids[i:i + 100])
        except TgError:
            for mid in ids[i:i + 100]:
                C.delete_msg(cid, mid)
    return len(ids)


def _purge(r, silent=False):
    if r.connected:
        return r.error("Purges only work inside the group itself.")
    rep = r.msg.reply_to_message
    if not rep:
        return r.error("Reply to the message you want to purge from.")
    if r.msg.message_id - rep.message_id > 2000:
        return r.error("That's too many messages (limit 2000).")
    n = _delete_range(r.cid, rep.message_id, r.msg.message_id)
    if not silent:
        m = C.send(r.cid, f"🧹 Purge complete ({n} messages).", thread=r.thread)
        C.delete_later(r.cid, m.message_id, 5)


@command("purge", module="purges", rights=("can_delete_messages",), h="Delete from the replied message to now")
def purge(r):
    _purge(r)


@command("spurge", module="purges", rights=("can_delete_messages",), h="Silent purge (no confirmation)")
def spurge(r):
    _purge(r, silent=True)


@command("del", module="purges", rights=("can_delete_messages",), h="Delete the replied message")
def del_cmd(r):
    rep = r.msg.reply_to_message
    if not rep:
        return r.error("Reply to the message you want to delete.")
    C.delete_msg(r.cid, rep.message_id)
    C.delete_msg(r.cid, r.msg.message_id)


@command("purgefrom", module="purges", rights=("can_delete_messages",), h="Mark the start of a purge range")
def purgefrom(r):
    rep = r.msg.reply_to_message
    if not rep:
        return r.error("Reply to the first message of the range.")
    db.set(r.cid, "purgefrom", rep.message_id)
    r.reply("Message marked. Now reply to the last message with /purgeto.")


@command("purgeto", module="purges", rights=("can_delete_messages",), h="Delete from the /purgefrom mark to here")
def purgeto(r):
    rep = r.msg.reply_to_message
    start = db.get(r.cid, "purgefrom")
    if not start:
        return r.error("Use /purgefrom first.")
    if not rep:
        return r.error("Reply to the last message of the range.")
    if rep.message_id < start or rep.message_id - start > 2000:
        return r.error("Invalid range (the end must be after the start, max 2000 messages).")
    _delete_range(r.cid, start, rep.message_id)
    db.rm(r.cid, "purgefrom")
    C.delete_msg(r.cid, r.msg.message_id)
    m = C.send(r.cid, "🧹 Purge complete.", thread=r.thread)
    C.delete_later(r.cid, m.message_id, 5)


# ==========================================================================
# Log channel
# ==========================================================================
LOG_CATS = ["settings", "admin", "user", "automated", "reports", "other"]


def set_log_channel(cid, ch_id, by):
    db.set(cid, "logchannel", ch_id)
    try:
        C.send(ch_id, f"✅ This channel is now the log channel for chat <code>{cid}</code>.")
    except TgError:
        pass
    C.log_event(cid, "settings", f"Log channel set by {me_text(by)}")


@command("setlog", module="logging", rights=("can_change_info",),
         h="Set the log channel: /setlog <channel id>, or forward the channel's /setlog post here")
def setlog(r):
    if not r.args or not r.args[0].lstrip("-").isdigit():
        return r.reply("To set a log channel: add me as admin there, post <code>/setlog</code> in the channel, "
                       "then forward that message here. You can also use <code>/setlog &lt;channel id&gt;</code>.")
    ch = int(r.args[0])
    try:
        C.send(ch, "Testing log channel…")
    except TgError:
        return r.error("I can't post in that channel. Make sure I'm an admin there.")
    set_log_channel(r.cid, ch, r.user)
    r.reply("✅ Log channel set.")


def handle_forwarded_setlog(msg):
    """Called for forwarded '/setlog' messages from a channel."""
    fo = msg.forward_origin
    if not fo or fo.type != "channel" or not (msg.text or "").startswith("/setlog"):
        return False
    cid, uid = msg.chat.id, msg.from_user.id
    if not C.has_right(C.member(cid, uid), "can_change_info") and not C.is_sudo(uid):
        return True
    set_log_channel(cid, fo.chat.id, msg.from_user)
    C.send(cid, f"✅ Log channel set to <b>{esc(fo.chat.title)}</b>.", reply_to=msg.message_id)
    return True


def channel_setlog(msg):
    """/setlog posted inside a channel."""
    C.send(msg.chat.id, "Now forward this message to the group you want to log, and I'll link them.")


@command("unsetlog", module="logging", rights=("can_change_info",), h="Remove the log channel")
def unsetlog(r):
    db.rm(r.cid, "logchannel")
    r.reply("Log channel removed.")


@command("logchannel", module="logging", admin=True, h="Show the current log channel")
def logchannel(r):
    ch = db.get(r.cid, "logchannel")
    if not ch:
        return r.reply("No log channel is set.")
    try:
        t = C.bot.get_chat(chat_id=ch).title
    except TgError:
        t = ch
    r.reply(f"Log channel: <b>{esc(t)}</b> (<code>{ch}</code>)")


@command("logcategories", module="logging", admin=True, h="List log categories and their state")
def logcategories(r):
    on = db.get(r.cid, "logcats", LOG_CATS)
    r.reply("<b>Log categories:</b>\n" + "\n".join(f"• <code>{c}</code>: {C.flag(c in on)}" for c in LOG_CATS))


def _set_cats(r, enable):
    on = list(db.get(r.cid, "logcats", LOG_CATS))
    want = LOG_CATS if (r.args and r.args[0].lower() == "all") else [a.lower() for a in r.args]
    bad = [w for w in want if w not in LOG_CATS]
    if not want or bad:
        return r.error("Give me categories: <code>" + " ".join(LOG_CATS) + "</code> or <code>all</code>.")
    for w in want:
        if enable and w not in on:
            on.append(w)
        if not enable and w in on:
            on.remove(w)
    db.set(r.cid, "logcats", on)
    r.reply(f"Log categories now enabled: <code>{' '.join(on) or 'none'}</code>")


@command("log", module="logging", admin=True, h="Enable log categories: /log <categories|all>")
def log_cmd(r):
    _set_cats(r, True)


@command("nolog", module="logging", admin=True, h="Disable log categories: /nolog <categories|all>")
def nolog(r):
    _set_cats(r, False)


# ==========================================================================
# Bans / mutes / kicks
# ==========================================================================
def _restrict(r, kind, temp=False, delete=False, silent=False):
    tg = C.get_target(r)
    if not tg or not C.guard_target(r, tg):
        return
    reason, secs = tg.rest.strip(), None
    mode = ("t" + kind) if temp else kind
    if temp:
        first = reason.split(None, 1)
        secs = C.parse_time(first[0]) if first else None
        if not secs:
            return r.error(f"Give me a time, e.g. <code>/{r.name} @user 3h reason</code> (m, h, d, w).")
        reason = first[1] if len(first) > 1 else ""
    if delete and tg.reply:
        C.delete_msg(r.cid, tg.reply.message_id)
    if silent:
        r.silent = True
    C.punish(r.cid, tg.id, mode, secs)
    dur = f" for {C.fmt_dur(secs)}" if secs else ""
    r.reply(f"✅ {tg.mention} has been <b>{C.VERB[mode]}</b>{dur}." + (f"\nReason: {esc(reason)}" if reason else ""),
            action=True)
    C.log_event(r.cid, "user", f"{me_text(r.user)} {C.VERB[mode]} {tg.mention}{dur}"
                + (f"\nReason: {esc(reason)}" if reason else ""))


def _mk(name, kind, temp=False, delete=False, silent=False, help_=""):
    def f(r):
        _restrict(r, kind, temp, delete, silent)
    f.__name__ = name
    command(name, module="bans", rights=("can_restrict_members",), action=True, h=help_)(f)


for _n, _k, _t, _d, _s, _h in [
    ("ban", "ban", False, False, False, "Ban a user"),
    ("tban", "ban", True, False, False, "Temporarily ban: /tban <user> <time> [reason]"),
    ("dban", "ban", False, True, False, "Ban and delete the replied message"),
    ("sban", "ban", False, False, True, "Silent ban (command is deleted)"),
    ("mute", "mute", False, False, False, "Mute a user"),
    ("tmute", "mute", True, False, False, "Temporarily mute: /tmute <user> <time>"),
    ("dmute", "mute", False, True, False, "Mute and delete the replied message"),
    ("smute", "mute", False, False, True, "Silent mute"),
    ("kick", "kick", False, False, False, "Kick a user (they can rejoin)"),
    ("dkick", "kick", False, True, False, "Kick and delete the replied message"),
    ("skick", "kick", False, False, True, "Silent kick"),
]:
    _mk(_n, _k, _t, _d, _s, _h)


@command("unban", module="bans", rights=("can_restrict_members",), action=True, h="Unban a user")
def unban(r):
    tg = C.get_target(r)
    if not tg:
        return
    C.bot.unban_chat_member(chat_id=r.cid, user_id=tg.id, only_if_banned=True)
    r.reply(f"✅ {tg.mention} has been unbanned.", action=True)
    C.log_event(r.cid, "user", f"{me_text(r.user)} unbanned {tg.mention}")


@command("unmute", module="bans", rights=("can_restrict_members",), action=True, h="Unmute a user")
def unmute(r):
    tg = C.get_target(r)
    if not tg:
        return
    C.unrestrict(r.cid, tg.id)
    r.reply(f"✅ {tg.mention} has been unmuted.", action=True)
    C.log_event(r.cid, "user", f"{me_text(r.user)} unmuted {tg.mention}")


# ==========================================================================
# Warnings
# ==========================================================================
def warn_user(cid, uid, reason="", by=None):
    """Add a warning; punish at the limit. Returns (html_text, markup)."""
    now = time.time()
    exp = db.get(cid, "warntime")
    if exp:
        db.x("DELETE FROM warns WHERE chat_id=? AND user_id=? AND ts<?", (cid, uid, now - exp))
    wid = db.x("INSERT INTO warns(chat_id,user_id,reason,ts,by) VALUES(?,?,?,?,?)",
               (cid, uid, reason, now, by or 0)).lastrowid
    count = db.count("SELECT COUNT(*) FROM warns WHERE chat_id=? AND user_id=?", (cid, uid))
    limit = db.get(cid, "warnlimit", 3)
    who = mention(uid, C.user_name(uid))
    if count >= limit:
        mode, secs = db.get(cid, "warnmode", "ban"), db.get(cid, "warnmodetime")
        try:
            C.punish(cid, uid, mode, secs)
        except TgError as e:
            return f"⚠️ {who} reached {limit} warnings but I couldn't {mode} them: {esc(e.desc)}", None
        db.x("DELETE FROM warns WHERE chat_id=? AND user_id=?", (cid, uid))
        return f"❗ {who} reached <b>{limit}</b> warnings and has been <b>{C.VERB[mode]}</b>.", None
    text = f"⚠️ {who} has been warned (<b>{count}/{limit}</b>)." + (f"\nReason: {esc(reason)}" if reason else "")
    return text, kb([[("🗑 Remove warn (admin only)", f"cb:rmwarn:{wid}")]])


def _warn(r, delete=False, silent=False):
    tg = C.get_target(r)
    if not tg or not C.guard_target(r, tg):
        return
    if delete and tg.reply:
        C.delete_msg(r.cid, tg.reply.message_id)
    if silent:
        r.silent = True
    text, markup = warn_user(r.cid, tg.id, tg.rest.strip(), r.user.id)
    r.reply(text, markup, action=True)
    C.log_event(r.cid, "user", f"{me_text(r.user)} warned {tg.mention}"
                + (f"\nReason: {esc(tg.rest.strip())}" if tg.rest.strip() else ""))


@command("warn", module="warns", rights=("can_restrict_members",), action=True, h="Warn a user")
def warn(r):
    _warn(r)


@command("dwarn", module="warns", rights=("can_restrict_members",), action=True,
         h="Warn and delete the replied message")
def dwarn(r):
    _warn(r, delete=True)


@command("swarn", module="warns", rights=("can_restrict_members",), action=True, h="Silent warn")
def swarn(r):
    _warn(r, silent=True)


@callback("rmwarn:")
def cb_rmwarn(cq, data):
    cid = cq.message.chat.id
    if not C.is_admin(cid, cq["from"]["id"]):
        return C.answer(cq, "Only admins can remove warnings.", True)
    db.x("DELETE FROM warns WHERE id=? AND chat_id=?", (int(data), cid))
    C.edit(cq, f"✅ Warning removed by {mention(cq['from']['id'], cq['from'].get('first_name', 'admin'))}.")
    C.answer(cq)


@command("warns", module="warns", scope="group", h="Show a user's warnings (yours by default)")
def warns(r):
    tg = C.get_target(r, err=False) or C.Target(r.user.id, full_name(r.user))
    rows = db.all("SELECT id,reason,ts FROM warns WHERE chat_id=? AND user_id=? ORDER BY ts", (r.cid, tg.id))
    limit = db.get(r.cid, "warnlimit", 3)
    if not rows:
        return r.reply(f"{tg.mention} has no warnings.")
    lines = [f"{tg.mention} has <b>{len(rows)}/{limit}</b> warnings:"]
    lines += [f"{i}. {esc(w['reason']) if w['reason'] else '<i>no reason</i>'}" for i, w in enumerate(rows, 1)]
    r.reply("\n".join(lines))


@command("rmwarn", module="warns", rights=("can_restrict_members",), h="Remove a user's latest warning")
def rmwarn(r):
    tg = C.get_target(r)
    if not tg:
        return
    row = db.one("SELECT id FROM warns WHERE chat_id=? AND user_id=? ORDER BY ts DESC", (r.cid, tg.id))
    if not row:
        return r.reply(f"{tg.mention} has no warnings.")
    db.x("DELETE FROM warns WHERE id=?", (row["id"],))
    r.reply(f"✅ Removed the latest warning of {tg.mention}.")


@command("resetwarn", module="warns", rights=("can_restrict_members",), h="Remove all warnings of a user")
def resetwarn(r):
    tg = C.get_target(r)
    if not tg:
        return
    db.x("DELETE FROM warns WHERE chat_id=? AND user_id=?", (r.cid, tg.id))
    r.reply(f"✅ All warnings of {tg.mention} were reset.")


@command("warnings", module="warns", admin=True, h="Show the warn settings of this chat")
def warnings(r):
    mode, secs = db.get(r.cid, "warnmode", "ban"), db.get(r.cid, "warnmodetime")
    exp = db.get(r.cid, "warntime")
    r.reply("<b>Warn settings</b>\n"
            f"• Limit: <b>{db.get(r.cid, 'warnlimit', 3)}</b>\n"
            f"• Action at limit: <b>{C.mode_text(mode, secs)}</b>\n"
            f"• Warns expire after: <b>{C.fmt_dur(exp) if exp else 'never'}</b>")


@command("setwarnlimit", module="warns", admin=True, h="Set how many warnings lead to a punishment")
def setwarnlimit(r):
    if not r.args or not r.args[0].isdigit() or not 1 <= int(r.args[0]) <= 100:
        return r.error("Usage: <code>/setwarnlimit 3</code> (1-100)")
    db.set(r.cid, "warnlimit", int(r.args[0]))
    r.reply(f"✅ Warn limit set to <b>{int(r.args[0])}</b>.")


@command("setwarnmode", module="warns", admin=True, h="Action at the warn limit: ban/mute/kick/tban <t>/tmute <t>")
def setwarnmode(r):
    mode, secs, err = C.parse_mode_args(r.args)
    if err:
        return r.error(err)
    db.set(r.cid, "warnmode", mode)
    db.set(r.cid, "warnmodetime", secs)
    r.reply(f"✅ Warn action is now <b>{C.mode_text(mode, secs)}</b>.")


@command("setwarntime", module="warns", admin=True, h="Warnings expire after a time (or 'off')")
def setwarntime(r):
    if r.args and r.args[0].lower() in ("off", "no", "0"):
        db.rm(r.cid, "warntime")
        return r.reply("Warnings no longer expire.")
    secs = C.parse_time(r.args[0]) if r.args else None
    if not secs:
        return r.error("Usage: <code>/setwarntime 1w</code> or <code>/setwarntime off</code>")
    db.set(r.cid, "warntime", secs)
    r.reply(f"✅ Warnings now expire after <b>{C.fmt_dur(secs)}</b>.")


@command("warntime", module="warns", admin=True, h="Show warning expiry time")
def warntime(r):
    exp = db.get(r.cid, "warntime")
    r.reply(f"Warnings expire after <b>{C.fmt_dur(exp)}</b>." if exp else "Warnings never expire.")


# ==========================================================================
# Reports
# ==========================================================================
def do_report(msg):
    """Handles /report and @admin. msg is the reporter's message."""
    cid, rep = msg.chat.id, msg.reply_to_message
    if not db.get(cid, "reports", True) or not rep or not rep.from_user:
        return
    reporter, target = msg.from_user, rep.from_user
    if C.is_admin(cid, reporter.id):
        return C.send(cid, "You're an admin, you can handle this yourself 😉", reply_to=msg.message_id)
    if C.is_admin(cid, target.id) or target.id == C.ME.id:
        return C.send(cid, "Why are you reporting an admin?", reply_to=msg.message_id)
    hidden = "".join(f'<a href="tg://user?id={m.user.id}">​</a>'
                     for m in C.admins(cid).values() if not m.user.is_bot and not m.is_anonymous)
    mid = rep.message_id
    markup = kb([[("⚠️ Kick", f"cb:rep:kick:{target.id}:{mid}"), ("⛔ Ban", f"cb:rep:ban:{target.id}:{mid}")],
                 [("🗑 Delete message", f"cb:rep:del:{target.id}:{mid}"), ("✅ Resolve", f"cb:rep:ok:{target.id}:{mid}")]])
    C.send(cid, f"{mention(reporter.id, full_name(reporter))} reported {mention(target.id, full_name(target))} "
                f"to the admins.{hidden}", markup, reply_to=rep.message_id, kind="report")
    C.log_event(cid, "reports", f"{mention(reporter.id, full_name(reporter))} reported "
                                f"{mention(target.id, full_name(target))}\n<a href=\"{msg_link(msg.chat, mid)}\">Message</a>")


@command("report", module="reports", scope="group", h="Report the replied message to the admins (or write @admin)")
def report(r):
    if r.connected:
        return r.error("Use this inside the group.")
    do_report(r.msg)


@command("reports", module="reports", admin=True, h="Enable/disable reporting: on/off")
def reports(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Reports: {C.flag(db.get(r.cid, 'reports', True))}")
    db.set(r.cid, "reports", v)
    r.reply(f"Reports {'enabled' if v else 'disabled'}.")


@callback("rep:")
def cb_rep(cq, data):
    act, uid, mid = data.split(":")
    uid, mid = int(uid), int(mid)
    cid, admin_id = cq.message.chat.id, cq["from"]["id"]
    m = C.member(cid, admin_id)
    if not m or m.status not in ("creator", "administrator"):
        return C.answer(cq, "Only admins can do that.", True)
    who = mention(admin_id, cq["from"].get("first_name", "admin"))
    try:
        if act == "kick" and C.has_right(m, "can_restrict_members"):
            C.punish(cid, uid, "kick")
            C.edit(cq, f"👢 Reported user kicked by {who}.")
        elif act == "ban" and C.has_right(m, "can_restrict_members"):
            C.punish(cid, uid, "ban")
            C.edit(cq, f"⛔ Reported user banned by {who}.")
        elif act == "del" and C.has_right(m, "can_delete_messages"):
            C.delete_msg(cid, mid)
            C.edit(cq, f"🗑 Reported message deleted by {who}.")
        elif act == "ok":
            C.edit(cq, f"✅ Report resolved by {who}.")
        else:
            return C.answer(cq, "You don't have the right for that.", True)
    except TgError as e:
        return C.answer(cq, e.desc[:150], True)
    C.answer(cq)


# ==========================================================================
# Disabling commands
# ==========================================================================
def _names(r):
    out, bad = [], []
    for a in r.args:
        c = C.REGISTRY.get(a.lstrip("/!").lower())
        (out if c and c.disableable else bad).append(c.name if c else a)
    return out, bad


@command("disable", module="disabling", admin=True, h="Disable commands for normal users")
def disable(r):
    ok, bad = _names(r)
    if not r.args:
        return r.error("Usage: <code>/disable warns notes</code>")
    cur = db.get(r.cid, "disabled", [])
    db.set(r.cid, "disabled", sorted(set(cur) | set(ok)))
    r.reply((f"Disabled: <code>{' '.join(ok)}</code>\n" if ok else "")
            + (f"Can't disable: <code>{' '.join(bad)}</code> (unknown or admin-only)" if bad else ""))


@command("enable", module="disabling", admin=True, h="Re-enable disabled commands")
def enable(r):
    names = [C.REGISTRY[a.lstrip("/!").lower()].name if a.lstrip("/!").lower() in C.REGISTRY else a for a in r.args]
    cur = db.get(r.cid, "disabled", [])
    db.set(r.cid, "disabled", [c for c in cur if c not in names])
    r.reply(f"Enabled: <code>{' '.join(names) or '-'}</code>")


@command("disabled", module="disabling", admin=True, h="List disabled commands")
def disabled(r):
    cur = db.get(r.cid, "disabled", [])
    r.reply("Disabled commands:\n" + "\n".join(f"• /{c}" for c in cur) if cur else "No commands are disabled.")


@command("disableable", module="disabling", admin=True, h="List commands that can be disabled")
def disableable(r):
    names = sorted(c.name for c in {id(c): c for c in C.REGISTRY.values()}.values() if c.disableable)
    r.reply("<b>Disableable commands:</b>\n" + " ".join(f"<code>{n}</code>" for n in names))


@command("disabledel", module="disabling", admin=True, h="Delete disabled commands when used: on/off")
def disabledel(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Delete disabled commands: {C.flag(db.get(r.cid, 'disabledel', False))}")
    db.set(r.cid, "disabledel", v)
    r.reply(f"Deleting disabled commands {'enabled' if v else 'disabled'}.")


@command("disableadmin", module="disabling", admin=True, h="Also block disabled commands for admins: on/off")
def disableadmin(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Disabled commands apply to admins: {C.flag(db.get(r.cid, 'disableadmin', False))}")
    db.set(r.cid, "disableadmin", v)
    r.reply(f"Disabled commands now {'also apply to' if v else 'skip'} admins.")
