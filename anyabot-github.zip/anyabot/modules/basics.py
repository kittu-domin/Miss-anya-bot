"""Basics: /start /help /id /info /setlang, rules, connections."""
import config
import core as C
from core import callback, command, esc, full_name, kb, mention
from db import db
from lang import LANGS
from tg import TgError

ORDER = ["basics", "connections", "rules", "admin", "pins", "approvals", "purges", "logging", "bans", "warns",
         "reports", "disabling", "greetings", "locks", "captcha", "blocklist", "antiflood", "antiraid",
         "federations", "filters", "notes", "echo", "exports", "privacy", "topics", "cleaning", "advanced",
         "gbans", "groupmgmt", "utils", "fun"]
TITLES = {
    "basics": "🏠 Basics", "connections": "🔗 Connections", "rules": "📜 Rules", "admin": "👮 Admins",
    "pins": "📌 Pins", "approvals": "✅ Approvals", "purges": "🧹 Purges", "logging": "🗒 Log channel",
    "bans": "🔨 Bans & Mutes", "warns": "⚠️ Warnings", "reports": "🚨 Reports", "disabling": "🚫 Disabling",
    "greetings": "👋 Greetings", "locks": "🔒 Locks", "captcha": "🤖 CAPTCHA", "blocklist": "⛔ Blocklist",
    "antiflood": "🌊 Antiflood", "antiraid": "🛡 Antiraid", "federations": "🌐 Federations",
    "filters": "🔎 Filters", "notes": "📝 Notes", "echo": "📣 Echo", "exports": "💾 Import/Export",
    "privacy": "🔏 Privacy", "topics": "🧵 Topics", "cleaning": "✨ Cleaning", "advanced": "⚙️ Advanced",
    "gbans": "☠️ Global bans", "groupmgmt": "🏘 Group tools", "utils": "🧰 Utilities", "fun": "🎲 Fun",
}
C.MODULE_TITLES.update(TITLES)


# --------------------------------------------------------------------------
# /start /help
# --------------------------------------------------------------------------
def help_menu():
    rows, row = [], []
    for m in ORDER:
        if m in C.MODULES:
            row.append((TITLES[m], f"cb:help:{m}"))
            if len(row) == 3:
                rows.append(row)
                row = []
    if row:
        rows.append(row)
    return kb(rows)


def module_help(m):
    lines = [f"<b>{TITLES.get(m, m)}</b>\n"]
    for name in C.MODULES.get(m, []):
        c = C.REGISTRY[name]
        al = (" / " + " / ".join("/" + a for a in c.aliases)) if c.aliases else ""
        lines.append(f"• /{name}{al}" + (f" — {esc(c.help)}" if c.help else ""))
    return "\n".join(lines)


@command("start", module="basics", scope="any", h="Start the bot / open deep links")
def start(r):
    me = C.ME
    if r.chat.type != "private":
        return r.reply("I'm alive and well! Use /help for the command list.")
    arg = r.args[0] if r.args else ""
    if arg.startswith("rules_"):
        return _send_rules(int(arg[6:]), r.chat.id, r.user)
    if arg.startswith("notes_"):
        cid, _, name = arg[6:].partition("_")
        from modules import notes
        return notes.send_note(int(cid), name, r.chat.id, r.user)
    if arg.startswith("connect_"):
        return _do_connect(r, int(arg[8:]))
    if arg == "help":
        return r.reply(r.t("help_intro"), help_menu())
    add = (f"https://t.me/{me.username}?startgroup=true&admin=delete_messages+restrict_members+pin_messages"
           "+invite_users+change_info+manage_topics+promote_members")
    rows = [[("➕ Add me to your group", add)], [("📚 Help & commands", "cb:help:main")]]
    if config.SUPPORT_URL:
        rows.append([("💬 Support", config.SUPPORT_URL)])
    r.reply(r.t("start", name=esc(full_name(r.user)), bot=esc(me.first_name)), kb(rows))


@command("help", module="basics", scope="any", h="Show help. /help <command or module>")
def help_cmd(r):
    if r.chat.type != "private":
        return r.reply("Contact me in PM to get the full help.",
                       kb([[("📚 Help", f"https://t.me/{C.ME.username}?start=help")]]))
    if r.args:
        q = r.args[0].lstrip("/!").lower()
        if q in C.REGISTRY:
            c = C.REGISTRY[q]
            return r.reply(f"/{c.name}" + (f" (aliases: {', '.join('/' + a for a in c.aliases)})" if c.aliases else "")
                           + f"\n{esc(c.help) or 'No description.'}\nModule: {TITLES.get(c.module, c.module)}")
        if q in C.MODULES:
            return r.reply(module_help(q), kb([[("⬅️ Back", "cb:help:main")]]))
    r.reply(r.t("help_intro"), help_menu())


@callback("help:")
def cb_help(cq, data):
    cid = cq.message.chat.id
    if data == "main":
        C.edit(cq, C.t(cid, "help_intro"), help_menu())
    elif data in C.MODULES:
        C.edit(cq, module_help(data), kb([[("⬅️ Back", "cb:help:main")]]))
    C.answer(cq)


# --------------------------------------------------------------------------
# /id /info
# --------------------------------------------------------------------------
@command("id", module="basics", h="Get your / a user's / the chat's ID")
def id_cmd(r):
    msg, out = r.msg, []
    rep = msg.reply_to_message
    if rep and rep.from_user:
        out.append(f"{mention(rep.from_user.id, full_name(rep.from_user))}'s ID: <code>{rep.from_user.id}</code>")
        fo = rep.forward_origin
        if fo:
            if fo.sender_user:
                out.append(f"Forwarded from {esc(full_name(fo.sender_user))}: <code>{fo.sender_user.id}</code>")
            elif fo.chat:
                out.append(f"Forwarded from {esc(fo.chat.title)}: <code>{fo.chat.id}</code>")
        if rep.sender_chat:
            out.append(f"Sender chat ID: <code>{rep.sender_chat.id}</code>")
    elif r.args:
        tg = C.get_target(r, err=False)
        if not tg:
            return r.error(r.t("no_target"))
        out.append(f"{tg.mention}'s ID: <code>{tg.id}</code>")
    else:
        out.append(f"Your ID: <code>{r.user.id}</code>")
        if r.chat.type != "private":
            out.append(f"This chat's ID: <code>{r.chat.id}</code>")
    if r.thread:
        out.append(f"Topic ID: <code>{r.thread}</code>")
    r.reply("\n".join(out))


@command("info", module="basics", h="Get information about a user")
def info_cmd(r):
    tg = C.get_target(r, err=False)
    if tg is None:
        u = r.user
        tg = C.Target(u.id, full_name(u), u.username)
    row = db.one("SELECT username,name FROM users WHERE user_id=?", (tg.id,))
    uname = tg.username or (row["username"] if row else None)
    lines = ["<b>User info:</b>", f"ID: <code>{tg.id}</code>", f"Name: {esc(tg.name)}"]
    if uname:
        lines.append(f"Username: @{esc(uname)}")
    lines.append(f"Link: {tg.mention}")
    if r.chat.type != "private":
        try:
            m = C.bot.get_chat_member(chat_id=r.chat.id, user_id=tg.id)
            lines.append(f"Status in chat: <b>{m.status}</b>")
        except TgError:
            pass
        n = db.count("SELECT COUNT(*) FROM warns WHERE chat_id=? AND user_id=?", (r.chat.id, tg.id))
        if n:
            lines.append(f"Warnings here: {n}")
    gb = db.one("SELECT reason FROM gbans WHERE user_id=?", (tg.id,))
    if gb:
        lines.append(f"☠️ <b>Globally banned</b>: {esc(gb['reason'] or 'no reason')}")
    fb = db.count("SELECT COUNT(*) FROM fed_bans WHERE user_id=?", (tg.id,))
    if fb:
        lines.append(f"🌐 Banned in <b>{fb}</b> federation(s)")
    if C.is_sudo(tg.id):
        lines.append("⭐ Bot staff")
    r.reply("\n".join(lines))


# --------------------------------------------------------------------------
# /setlang
# --------------------------------------------------------------------------
@command("setlang", module="basics", scope="any", h="Choose the bot's language for this chat")
def setlang(r):
    if r.chat.type != "private" and not C.is_admin(r.chat.id, r.user.id):
        return r.error(r.t("need_admin"))
    cur = db.get(r.chat.id, "lang", "en")
    rows = [[(("✅ " if code == cur else "") + name, f"cb:lang:{code}")] for code, name in LANGS.items()]
    r.reply(f"Current language: <b>{LANGS.get(cur, cur)}</b>\nChoose a language:", kb(rows))


@callback("lang:")
def cb_lang(cq, data):
    chat = cq.message.chat
    if data not in LANGS:
        return C.answer(cq)
    if chat.type != "private" and not C.is_admin(chat.id, cq["from"]["id"]):
        return C.answer(cq, "Only admins can change the language.", True)
    db.set(chat.id, "lang", data)
    C.edit(cq, C.t(chat.id, "lang_set", lang=LANGS[data]))
    C.answer(cq)


# --------------------------------------------------------------------------
# Rules
# --------------------------------------------------------------------------
def _send_rules(cid, to_chat, user):
    rules = db.get(cid, "rules")
    if not rules:
        return C.send(to_chat, "The group admins haven't set any rules for this chat yet. "
                               "That probably doesn't mean it's lawless though...")
    chat = C.D(id=cid, title=(db.one("SELECT title FROM chats WHERE chat_id=?", (cid,)) or {"title": ""})["title"])
    C.send_saved(to_chat, rules, user, chat, kind="note")


@command("rules", module="rules", scope="group", h="Show this chat's rules")
def rules(r):
    cid = r.cid
    if not db.get(cid, "rules"):
        return r.reply("The group admins haven't set any rules for this chat yet. "
                       "That probably doesn't mean it's lawless though...")
    if db.get(cid, "privaterules", False) and not r.connected and r.chat.type != "private":
        label = db.get(cid, "rulesbtn", "Rules")
        return r.reply("Click the button below to read the rules.",
                       kb([[(label, f"https://t.me/{C.ME.username}?start=rules_{cid}")]]), kind="note")
    _send_rules(cid, r.chat.id, r.user)


@command("setrules", module="rules", admin=True, h="Set the rules (text or reply)")
def setrules(r):
    c = r.content()
    if not c:
        return r.error("Give me the rules text, or reply to a message containing them.")
    db.set(r.cid, "rules", c)
    r.reply("✅ New rules have been set for this chat.")
    C.log_event(r.cid, "settings", f"Rules updated by {mention(r.user.id, full_name(r.user))}")


@command("privaterules", module="rules", admin=True, h="Send rules in PM instead of the group: on/off")
def privaterules(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Private rules: {C.flag(db.get(r.cid, 'privaterules', False))}\nUse <code>/privaterules on|off</code>")
    db.set(r.cid, "privaterules", v)
    r.reply(f"Private rules {'enabled' if v else 'disabled'}.")


@command("resetrules", module="rules", admin=True, h="Clear the rules")
def resetrules(r):
    db.rm(r.cid, "rules")
    r.reply("Rules cleared.")


@command("setrulesbutton", module="rules", admin=True, h="Change the label of the rules button")
def setrulesbutton(r):
    if not r.raw:
        return r.error("Usage: <code>/setrulesbutton Read the rules</code>")
    db.set(r.cid, "rulesbtn", r.raw[:60])
    r.reply(f"Rules button is now <b>{esc(r.raw[:60])}</b>.")


@command("resetrulesbutton", module="rules", admin=True, h="Reset the rules button label")
def resetrulesbutton(r):
    db.rm(r.cid, "rulesbtn")
    r.reply("Rules button reset to <b>Rules</b>.")


# --------------------------------------------------------------------------
# Connections
# --------------------------------------------------------------------------
def _do_connect(r, cid):
    try:
        m = C.bot.get_chat_member(chat_id=cid, user_id=r.user.id)
        ch = C.bot.get_chat(chat_id=cid)
    except TgError:
        return r.error("I can't find that chat, or I'm not in it.")
    if m.status in ("left", "kicked"):
        return r.error("You are not a member of that chat.")
    db.x("INSERT INTO conns VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET chat_id=excluded.chat_id,"
         "last_chat=excluded.last_chat", (r.user.id, cid, cid))
    C.track_chat(ch)
    r.reply(f"✅ Connected to <b>{esc(ch.title)}</b>. You can now manage it from here.")


@command("connect", module="connections", scope="any", h="Connect PM to a group: /connect <chat id|@username>")
def connect(r):
    if r.chat.type != "private":
        return r.reply("Tap the button to connect to this chat in PM.",
                       kb([[("🔗 Connect", f"https://t.me/{C.ME.username}?start=connect_{r.chat.id}")]]))
    if not r.args:
        row = db.one("SELECT chat_id,last_chat FROM conns WHERE user_id=?", (r.user.id,))
        hint = f"\nLast chat: <code>{row['last_chat']}</code> (use /reconnect)" if row and row["last_chat"] else ""
        return r.reply("Usage: <code>/connect &lt;chat id or @username&gt;</code>" + hint)
    tok = r.args[0]
    try:
        cid = int(tok) if tok.lstrip("-").isdigit() else C.bot.get_chat(chat_id=tok).id
    except (TgError, ValueError):
        return r.error("I can't find that chat.")
    _do_connect(r, cid)


@command("disconnect", module="connections", scope="pm", h="Disconnect from the connected chat")
def disconnect(r):
    db.x("UPDATE conns SET chat_id=NULL WHERE user_id=?", (r.user.id,))
    r.reply("Disconnected. Use /reconnect to go back to your last chat.")


@command("reconnect", module="connections", scope="pm", h="Reconnect to your last connected chat")
def reconnect(r):
    row = db.one("SELECT last_chat FROM conns WHERE user_id=?", (r.user.id,))
    if not row or not row["last_chat"]:
        return r.error("You have no previous connection.")
    _do_connect(r, row["last_chat"])


@command("connection", module="connections", scope="pm", h="Show the chat you're connected to")
def connection(r):
    row = db.one("SELECT chat_id FROM conns WHERE user_id=?", (r.user.id,))
    if not row or not row["chat_id"]:
        return r.reply("You aren't connected to any chat. Use /connect.")
    t = db.one("SELECT title FROM chats WHERE chat_id=?", (row["chat_id"],))
    r.reply(f"You are connected to <b>{esc(t['title'] if t else row['chat_id'])}</b> "
            f"(<code>{row['chat_id']}</code>).")
