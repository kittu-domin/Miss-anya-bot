"""Notes and filters."""
import json
import re

import core as C
from core import callback, command, esc, kb
from db import db
from tg import TgError


# ==========================================================================
# Notes
# ==========================================================================
def _name(s):
    return s.lstrip("#").lower()[:64]


def send_note(cid, name, to_chat, user, noformat=False, reply_to=None, thread=None):
    row = db.one("SELECT data FROM notes WHERE chat_id=? AND name=?", (cid, _name(name)))
    if not row:
        return C.send(to_chat, "I couldn't find that note.", reply_to=reply_to, thread=thread, kind="error")
    ch = db.one("SELECT title FROM chats WHERE chat_id=?", (cid,))
    chat = C.D(id=cid, title=ch["title"] if ch else "")
    return C.send_saved(to_chat, json.loads(row["data"]), user, chat, reply_to=reply_to, thread=thread,
                        noformat=noformat, kind="note")


def get_note(r_or_msg, cid, name, noformat=False):
    """Shared by /get and #name. `r_or_msg` is the message."""
    msg = r_or_msg
    if db.get(cid, "privatenotes", False) and msg.chat.type != "private":
        if not db.one("SELECT 1 FROM notes WHERE chat_id=? AND name=?", (cid, _name(name))):
            return C.send(msg.chat.id, "I couldn't find that note.", reply_to=msg.message_id, kind="error")
        return C.send(msg.chat.id, f"Tap the button to get the note <b>{esc(_name(name))}</b> in PM.",
                      kb([[("📝 Get note", f"https://t.me/{C.ME.username}?start=notes_{cid}_{_name(name)}")]]),
                      reply_to=msg.message_id, kind="note")
    thread = msg.message_thread_id if msg.is_topic_message else None
    reply_to = msg.reply_to_message.message_id if msg.reply_to_message else msg.message_id
    return send_note(cid, name, msg.chat.id, msg.from_user, noformat, reply_to, thread)


def hash_note(msg):
    """Messages like '#rules' trigger notes."""
    m = re.match(r"^#(\w+)", msg.text or "")
    if m and db.one("SELECT 1 FROM notes WHERE chat_id=? AND name=?", (msg.chat.id, m.group(1).lower())):
        get_note(msg, msg.chat.id, m.group(1))


@command("save", module="notes", admin=True, h="Save a note: /save <name> <text> (or reply to a message)")
def save(r):
    if not r.args:
        return r.error("Usage: <code>/save name text</code> — or reply to a message with <code>/save name</code>")
    c = r.content(skip=1)
    if not c:
        return r.error("A note needs some content. Give me text or reply to a message.")
    db.x("INSERT INTO notes VALUES(?,?,?) ON CONFLICT(chat_id,name) DO UPDATE SET data=excluded.data",
         (r.cid, _name(r.args[0]), json.dumps(c)))
    r.reply(f"✅ Saved note <b>{esc(_name(r.args[0]))}</b>. Get it with <code>/get {esc(_name(r.args[0]))}</code> "
            f"or <code>#{esc(_name(r.args[0]))}</code>")


@command("get", module="notes", scope="group", h="Get a note: /get <name> [noformat]")
def get(r):
    if not r.args:
        return r.error("Usage: <code>/get name</code>")
    get_note(r.msg, r.cid, r.args[0], noformat=len(r.args) > 1 and r.args[1].lower() == "noformat")


@command("notes", "saved", module="notes", scope="group", h="List all notes in this chat")
def notes(r):
    rows = db.all("SELECT name FROM notes WHERE chat_id=? ORDER BY name", (r.cid,))
    if not rows:
        return r.reply("There are no notes in this chat yet.")
    r.reply("<b>Notes in this chat:</b>\n" + "\n".join(f"• <code>#{esc(x['name'])}</code>" for x in rows)
            + "\n\nGet one with <code>/get name</code> or <code>#name</code>.")


@command("clear", module="notes", admin=True, h="Delete a note")
def clear(r):
    if not r.args:
        return r.error("Usage: <code>/clear name</code>")
    n = db.x("DELETE FROM notes WHERE chat_id=? AND name=?", (r.cid, _name(r.args[0]))).rowcount
    r.reply("✅ Note deleted." if n else "I couldn't find that note.")


@command("clearall", module="notes", admin=True, h="Delete ALL notes (asks for confirmation)")
def clearall(r):
    r.reply("Delete <b>all</b> notes in this chat?",
            kb([[("Yes, delete all", f"cb:clearall:yes:{r.cid}"), ("Cancel", f"cb:clearall:no:{r.cid}")]]))


@callback("clearall:")
def cb_clearall(cq, data):
    ans, _, cid = data.partition(":")
    cid = int(cid)
    if not C.is_admin(cid, cq["from"]["id"]):
        return C.answer(cq, "Admins only.", True)
    if ans == "yes":
        n = db.x("DELETE FROM notes WHERE chat_id=?", (cid,)).rowcount
        C.edit(cq, f"Deleted {n} notes.")
    else:
        C.edit(cq, "Cancelled.")
    C.answer(cq)


@command("privatenotes", module="notes", admin=True, h="Send notes in PM instead of the group: on/off")
def privatenotes(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Private notes: {C.flag(db.get(r.cid, 'privatenotes', False))}")
    db.set(r.cid, "privatenotes", v)
    r.reply(f"Private notes {'enabled' if v else 'disabled'}.")


# ==========================================================================
# Filters
# ==========================================================================
@command("filter", module="filters", admin=True,
         h='Reply to keywords: /filter <word|"two words"|(a, b)> <reply text>')
def filter_cmd(r):
    keys, rest_plain = C.parse_keys(r.raw)
    if not keys:
        return r.error('Usage: <code>/filter hello Hi there!</code> · <code>/filter "good morning" ...</code> · '
                       "<code>/filter (hi, hello) ...</code> — or reply to a message.")
    rest_plain = rest_plain.strip()
    c = None
    if rest_plain:
        if any(e.type in C.FORMAT_TYPES for e in (r.msg.entities or [])):
            full = C.entities_to_html(r.msg.text, r.msg.entities)
            full = re.sub(r"^[/!]\w+(@\w+)?[ \t]*", "", full, count=1)
            idx = full.find(C.esc(rest_plain[:20]))
            c = {"type": "text", "file": None, "text": (full[idx:] if idx >= 0 else rest_plain).strip(),
                 "fmt": "html"}
        else:
            c = {"type": "text", "file": None, "text": rest_plain, "fmt": "md"}
    elif r.msg.reply_to_message:
        rep = r.msg.reply_to_message
        if rep.text or rep.caption or C.msg_media(rep)[0]:
            c = C.content_from_message(rep)
    if not c:
        return r.error("What should I reply with? Add text after the keyword, or reply to a message.")
    for k in keys:
        db.x("INSERT INTO filters VALUES(?,?,?) ON CONFLICT(chat_id,kw) DO UPDATE SET data=excluded.data",
             (r.cid, k.lower(), json.dumps(c)))
    r.reply("✅ Filter saved for: " + ", ".join(f"<code>{esc(k)}</code>" for k in keys))


@command("stop", module="filters", admin=True, h="Remove a filter: /stop <keyword>")
def stop(r):
    keys, _ = C.parse_keys(r.raw)
    if not keys:
        return r.error("Usage: <code>/stop keyword</code>")
    n = sum(db.x("DELETE FROM filters WHERE chat_id=? AND kw=?", (r.cid, k.lower())).rowcount for k in keys)
    r.reply("✅ Filter removed." if n else "I couldn't find that filter.")


@command("stopall", module="filters", admin=True, h="Remove ALL filters (asks for confirmation)")
def stopall(r):
    r.reply("Remove <b>all</b> filters from this chat?",
            kb([[("Yes, remove all", f"cb:stopall:yes:{r.cid}"), ("Cancel", f"cb:stopall:no:{r.cid}")]]))


@callback("stopall:")
def cb_stopall(cq, data):
    ans, _, cid = data.partition(":")
    cid = int(cid)
    if not C.is_admin(cid, cq["from"]["id"]):
        return C.answer(cq, "Admins only.", True)
    if ans == "yes":
        n = db.x("DELETE FROM filters WHERE chat_id=?", (cid,)).rowcount
        C.edit(cq, f"Removed {n} filters.")
    else:
        C.edit(cq, "Cancelled.")
    C.answer(cq)


@command("filters", module="filters", scope="group", h="List the filters in this chat")
def filters_cmd(r):
    rows = db.all("SELECT kw FROM filters WHERE chat_id=? ORDER BY kw", (r.cid,))
    if not rows:
        return r.reply("There are no filters in this chat.")
    r.reply("<b>Filters in this chat:</b>\n" + "\n".join(f"• <code>{esc(x['kw'])}</code>" for x in rows))


def check_filters(msg):
    text = msg.text or msg.caption
    if not text:
        return False
    for row in db.all("SELECT kw,data FROM filters WHERE chat_id=?", (msg.chat.id,)):
        if re.search(r"(?<!\w)" + re.escape(row["kw"]) + r"(?!\w)", text, re.I):
            ch = C.D(id=msg.chat.id, title=msg.chat.title)
            thread = msg.message_thread_id if msg.is_topic_message else None
            try:
                C.send_saved(msg.chat.id, json.loads(row["data"]), msg.from_user, ch, reply_to=msg.message_id,
                             thread=thread, kind="filter")
            except TgError as e:
                C.log.warning("filter send failed: %s", e)
            return True
    return False
