"""Federations: shared ban lists across many chats."""
import csv
import io
import json
import re
import time
import uuid

import core as C
from core import callback, command, esc, full_name, kb, mention
from db import db
from tg import TgError

UUID_RE = re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I)


# --------------------------------------------------------------------------
# Lookups
# --------------------------------------------------------------------------
def fed_row(fid):
    return db.one("SELECT * FROM feds WHERE fed_id=?", (fid,))


def fed_of_chat(cid):
    row = db.one("SELECT fed_id FROM fed_chats WHERE chat_id=?", (cid,))
    return fed_row(row["fed_id"]) if row else None


def is_fed_admin(fid, uid):
    f = fed_row(fid)
    return bool(f) and (f["owner_id"] == uid or
                        db.one("SELECT 1 FROM fed_admins WHERE fed_id=? AND user_id=?", (fid, uid)) is not None)


def user_feds(uid, owner_only=False):
    rows = db.all("SELECT * FROM feds WHERE owner_id=?", (uid,))
    if not owner_only:
        rows += db.all("SELECT f.* FROM feds f JOIN fed_admins a ON a.fed_id=f.fed_id WHERE a.user_id=?", (uid,))
    return rows


def watched_feds(fid):
    """Fed itself plus every fed it subscribes to."""
    return [fid] + [x["sub_id"] for x in db.all("SELECT sub_id FROM fed_subs WHERE fed_id=?", (fid,))]


def fed_chat_ids(fid):
    """Chats of this fed and of feds subscribed to it."""
    ids = {x["fed_id"] for x in db.all("SELECT fed_id FROM fed_subs WHERE sub_id=?", (fid,))} | {fid}
    out = []
    for f in ids:
        out += [x["chat_id"] for x in db.all("SELECT chat_id FROM fed_chats WHERE fed_id=?", (f,))]
    return out


def fban_status(cid, uid):
    """(fed_row_that_banned, reason) if uid is fed-banned for chat cid, else None."""
    f = fed_of_chat(cid)
    if not f:
        return None
    fids = watched_feds(f["fed_id"])
    row = db.one(f"SELECT fed_id,reason FROM fed_bans WHERE user_id=? AND fed_id IN ({','.join('?' * len(fids))})",
                 (uid, *fids))
    return (fed_row(row["fed_id"]), row["reason"]) if row else None


def enforce(cid, user):
    """Called on join / first message. Returns True if the user was removed."""
    uid = user.id
    gb = db.one("SELECT reason FROM gbans WHERE user_id=?", (uid,)) if db.get(cid, "gbanstat", True) else None
    fb = fban_status(cid, uid)
    if not gb and not fb:
        return False
    try:
        C.punish(cid, uid, "ban")
    except TgError:
        return False
    quiet = db.one("SELECT quiet FROM fed_chats WHERE chat_id=?", (cid,))
    if gb:
        C.send(cid, f"☠️ {mention(uid, full_name(user))} is globally banned and was removed.\n"
                    f"Reason: {esc(gb['reason'] or 'none given')}", kind="action")
    elif not (quiet and quiet["quiet"]):
        f, reason = fb
        C.send(cid, f"🌐 {mention(uid, full_name(user))} is banned in federation <b>{esc(f['name'])}</b> and was removed."
                    f"\nReason: {esc(reason or 'none given')}", kind="action")
    return True


# --------------------------------------------------------------------------
# Resolving "which federation do you mean?"
# --------------------------------------------------------------------------
def resolve(r, owner=False, admin=False):
    """Find the federation from a UUID in the args, the chat, or the user's own fed. Strips the UUID from r.raw."""
    m = UUID_RE.search(r.raw)
    if m:
        fed = fed_row(m.group(0).lower())
        r.raw = (r.raw[:m.start()] + r.raw[m.end():]).strip()
        r.args = r.raw.split()
        if not fed:
            r.error("I can't find a federation with that ID.")
            return None
    elif r.chat.type != "private" or r.connected:
        fed = fed_of_chat(r.cid)
        if not fed:
            r.error("This chat isn't part of any federation. Use <code>/joinfed &lt;fedid&gt;</code>.")
            return None
    else:
        mine = user_feds(r.user.id)
        if not mine:
            r.error("You don't have a federation. Create one with /newfed, or give me a federation ID.")
            return None
        fed = mine[0]
    uid = r.user.id
    if owner and fed["owner_id"] != uid and not C.is_sudo(uid):
        r.error("Only the federation owner can do that.")
        return None
    if admin and not is_fed_admin(fed["fed_id"], uid) and not C.is_sudo(uid):
        r.error("You need to be a federation admin to do that.")
        return None
    return fed


# --------------------------------------------------------------------------
# Info
# --------------------------------------------------------------------------
@command("fedinfo", module="federations", scope="any", h="Info about a federation: /fedinfo [fedid]")
def fedinfo(r):
    fed = resolve(r)
    if not fed:
        return
    fid = fed["fed_id"]
    n_admin = db.count("SELECT COUNT(*) FROM fed_admins WHERE fed_id=?", (fid,))
    n_ban = db.count("SELECT COUNT(*) FROM fed_bans WHERE fed_id=?", (fid,))
    n_chat = db.count("SELECT COUNT(*) FROM fed_chats WHERE fed_id=?", (fid,))
    n_sub = db.count("SELECT COUNT(*) FROM fed_subs WHERE fed_id=?", (fid,))
    r.reply(f"<b>Federation info</b>\nName: <b>{esc(fed['name'])}</b>\nID: <code>{fid}</code>\n"
            f"Owner: {mention(fed['owner_id'], C.user_name(fed['owner_id']))}\n"
            f"Admins: {n_admin}\nBanned users: {n_ban}\nChats: {n_chat}\nSubscribed to: {n_sub} federation(s)")


@command("fedadmins", module="federations", scope="any", h="List a federation's admins")
def fedadmins(r):
    fed = resolve(r)
    if not fed:
        return
    rows = db.all("SELECT user_id FROM fed_admins WHERE fed_id=?", (fed["fed_id"],))
    lines = [f"<b>{esc(fed['name'])}</b> admins:", f"👑 {mention(fed['owner_id'], C.user_name(fed['owner_id']))}"]
    lines += [f"• {mention(x['user_id'], C.user_name(x['user_id']))}" for x in rows]
    r.reply("\n".join(lines))


@command("chatfed", module="federations", scope="group", h="Which federation is this chat in?")
def chatfed(r):
    fed = fed_of_chat(r.cid)
    if not fed:
        return r.reply("This chat isn't part of any federation.")
    r.reply(f"This chat is in federation <b>{esc(fed['name'])}</b>\nID: <code>{fed['fed_id']}</code>")


@command("myfeds", module="federations", scope="pm", h="List federations you own or administer")
def myfeds(r):
    rows = user_feds(r.user.id)
    if not rows:
        return r.reply("You don't own or administer any federation.")
    r.reply("<b>Your federations:</b>\n" + "\n".join(
        f"• <b>{esc(f['name'])}</b> — <code>{f['fed_id']}</code>" + (" 👑" if f["owner_id"] == r.user.id else "")
        for f in rows))


# --------------------------------------------------------------------------
# Create / rename / delete
# --------------------------------------------------------------------------
@command("newfed", module="federations", scope="pm", h="Create a federation: /newfed <name>")
def newfed(r):
    if not r.raw:
        return r.error("Usage: <code>/newfed My Federation</code>")
    if user_feds(r.user.id, owner_only=True) and not C.is_sudo(r.user.id):
        return r.error("You already own a federation. Delete it with /delfed first.")
    fid = str(uuid.uuid4())
    db.x("INSERT INTO feds(fed_id,name,owner_id) VALUES(?,?,?)", (fid, r.raw[:60], r.user.id))
    r.reply(f"✅ Federation <b>{esc(r.raw[:60])}</b> created!\nID: <code>{fid}</code>\n"
            "Use <code>/joinfed &lt;id&gt;</code> in your groups to add them.")


@command("renamefed", module="federations", scope="any", h="Rename your federation: /renamefed <new name>")
def renamefed(r):
    fed = resolve(r, owner=True)
    if not fed:
        return
    if not r.raw:
        return r.error("Usage: <code>/renamefed New Name</code>")
    db.x("UPDATE feds SET name=? WHERE fed_id=?", (r.raw[:60], fed["fed_id"]))
    r.reply(f"✅ Federation renamed to <b>{esc(r.raw[:60])}</b>.")


@command("delfed", module="federations", scope="pm", h="Delete your federation (asks for confirmation)")
def delfed(r):
    fed = resolve(r, owner=True)
    if not fed:
        return
    r.reply(f"Delete federation <b>{esc(fed['name'])}</b> with all its bans? This can't be undone.",
            kb([[("Yes, delete", f"cb:delfed:yes:{fed['fed_id']}"), ("Cancel", f"cb:delfed:no:{fed['fed_id']}")]]))


@callback("delfed:")
def cb_delfed(cq, data):
    ans, _, fid = data.partition(":")
    fed = fed_row(fid)
    if not fed or (fed["owner_id"] != cq["from"]["id"] and not C.is_sudo(cq["from"]["id"])):
        return C.answer(cq, "Only the federation owner can do that.", True)
    if ans == "yes":
        for tbl in ("fed_admins", "fed_chats", "fed_bans"):
            db.x(f"DELETE FROM {tbl} WHERE fed_id=?", (fid,))
        db.x("DELETE FROM fed_subs WHERE fed_id=? OR sub_id=?", (fid, fid))
        db.x("DELETE FROM feds WHERE fed_id=?", (fid,))
        C.edit(cq, f"Federation <b>{esc(fed['name'])}</b> deleted.")
    else:
        C.edit(cq, "Cancelled.")
    C.answer(cq)


# --------------------------------------------------------------------------
# Admins and settings
# --------------------------------------------------------------------------
@command("fedpromote", module="federations", scope="any", h="Make a user a federation admin")
def fedpromote(r):
    fed = resolve(r, owner=True)
    if not fed:
        return
    tg = C.get_target(r)
    if not tg:
        return
    db.x("INSERT OR IGNORE INTO fed_admins VALUES(?,?)", (fed["fed_id"], tg.id))
    r.reply(f"✅ {tg.mention} is now an admin of <b>{esc(fed['name'])}</b>.")


@command("feddemote", module="federations", scope="any", h="Remove a federation admin")
def feddemote(r):
    fed = resolve(r, owner=True)
    if not fed:
        return
    tg = C.get_target(r)
    if not tg:
        return
    db.x("DELETE FROM fed_admins WHERE fed_id=? AND user_id=?", (fed["fed_id"], tg.id))
    r.reply(f"✅ {tg.mention} is no longer an admin of <b>{esc(fed['name'])}</b>.")


@command("feddemoteme", module="federations", scope="pm", h="Resign as admin of a federation: /feddemoteme <fedid>")
def feddemoteme(r):
    m = UUID_RE.search(r.raw)
    fed = fed_row(m.group(0).lower()) if m else None
    if not fed:
        return r.error("Give me the federation ID: <code>/feddemoteme &lt;fedid&gt;</code>")
    n = db.x("DELETE FROM fed_admins WHERE fed_id=? AND user_id=?", (fed["fed_id"], r.user.id)).rowcount
    r.reply("✅ You resigned as federation admin." if n else "You aren't an admin of that federation.")


def _toggle(r, col, label):
    fed = resolve(r, owner=True)
    if not fed:
        return
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"{label}: {C.flag(bool(fed[col]))}")
    db.x(f"UPDATE feds SET {col}=? WHERE fed_id=?", (int(v), fed["fed_id"]))
    r.reply(f"{label} {'enabled' if v else 'disabled'}.")


@command("fedreason", module="federations", scope="any", h="Require a reason for fbans: on/off")
def fedreason(r):
    _toggle(r, "need_reason", "Required fban reason")


@command("fednotif", module="federations", scope="any", h="Notify the fed owner of bans/unbans in PM: on/off")
def fednotif(r):
    _toggle(r, "notif", "Federation notifications")


@command("setfedlog", module="federations", scope="any", h="Use this chat as the federation log: /setfedlog <fedid>")
def setfedlog(r):
    m = UUID_RE.search(r.raw)
    fed = fed_row(m.group(0).lower()) if m else None
    if not fed:
        return r.error("Usage: <code>/setfedlog &lt;fedid&gt;</code> (run it in the chat/channel that should get the log)")
    if fed["owner_id"] != r.user.id and not C.is_sudo(r.user.id):
        return r.error("Only the federation owner can do that.")
    db.x("UPDATE feds SET log_chat=? WHERE fed_id=?", (r.chat.id, fed["fed_id"]))
    r.reply(f"✅ This chat is now the log for <b>{esc(fed['name'])}</b>.")


@command("unsetfedlog", module="federations", scope="any", h="Remove the federation log chat")
def unsetfedlog(r):
    fed = resolve(r, owner=True)
    if not fed:
        return
    db.x("UPDATE feds SET log_chat=NULL WHERE fed_id=?", (fed["fed_id"],))
    r.reply("Federation log removed.")


# --------------------------------------------------------------------------
# Joining chats
# --------------------------------------------------------------------------
def _chat_owner_only(r):
    m = C.member(r.cid, r.user.id)
    if (m and m.status == "creator") or C.is_sudo(r.user.id):
        return True
    r.error("Only the chat creator can do that.")
    return False


@command("joinfed", module="federations", scope="group", h="Add this chat to a federation (chat creator)")
def joinfed(r):
    if not _chat_owner_only(r):
        return
    m = UUID_RE.search(r.raw)
    fed = fed_row(m.group(0).lower()) if m else None
    if not fed:
        return r.error("Usage: <code>/joinfed &lt;fedid&gt;</code>")
    if fed_of_chat(r.cid):
        return r.error("This chat is already in a federation. Use /leavefed first.")
    db.x("INSERT INTO fed_chats(chat_id,fed_id) VALUES(?,?)", (r.cid, fed["fed_id"]))
    r.reply(f"✅ This chat joined federation <b>{esc(fed['name'])}</b>.")


@command("leavefed", module="federations", scope="group", h="Remove this chat from its federation")
def leavefed(r):
    if not _chat_owner_only(r):
        return
    n = db.x("DELETE FROM fed_chats WHERE chat_id=?", (r.cid,)).rowcount
    r.reply("✅ This chat left its federation." if n else "This chat isn't in a federation.")


@command("quietfed", module="federations", admin=True, h="Don't announce fed-ban removals in this chat: on/off")
def quietfed(r):
    if not fed_of_chat(r.cid):
        return r.error("This chat isn't in a federation.")
    v = C.on_off(r.args[0]) if r.args else None
    cur = db.one("SELECT quiet FROM fed_chats WHERE chat_id=?", (r.cid,))["quiet"]
    if v is None:
        return r.reply(f"Quiet federation: {C.flag(bool(cur))}")
    db.x("UPDATE fed_chats SET quiet=? WHERE chat_id=?", (int(v), r.cid))
    r.reply(f"Quiet federation {'enabled' if v else 'disabled'}.")


# --------------------------------------------------------------------------
# Subscriptions
# --------------------------------------------------------------------------
@command("subfed", module="federations", scope="any", h="Subscribe your fed to another's bans: /subfed <other fedid>")
def subfed(r):
    ids = UUID_RE.findall(r.raw)
    if not ids:
        return r.error("Usage: <code>/subfed &lt;fedid to subscribe to&gt; [your fedid]</code>")
    target = fed_row(ids[0].lower())
    if not target:
        return r.error("I can't find that federation.")
    r.raw = ids[1] if len(ids) > 1 else ""
    r.args = r.raw.split()
    mine = resolve(r, owner=True)
    if not mine:
        return
    if mine["fed_id"] == target["fed_id"]:
        return r.error("A federation can't subscribe to itself.")
    db.x("INSERT OR IGNORE INTO fed_subs VALUES(?,?)", (mine["fed_id"], target["fed_id"]))
    r.reply(f"✅ <b>{esc(mine['name'])}</b> now follows the bans of <b>{esc(target['name'])}</b>.")


@command("unsubfed", module="federations", scope="any", h="Unsubscribe from a federation: /unsubfed <fedid>")
def unsubfed(r):
    ids = UUID_RE.findall(r.raw)
    if not ids:
        return r.error("Usage: <code>/unsubfed &lt;fedid&gt;</code>")
    r.raw = ids[1] if len(ids) > 1 else ""
    r.args = r.raw.split()
    mine = resolve(r, owner=True)
    if not mine:
        return
    n = db.x("DELETE FROM fed_subs WHERE fed_id=? AND sub_id=?", (mine["fed_id"], ids[0].lower())).rowcount
    r.reply("✅ Unsubscribed." if n else "You weren't subscribed to that federation.")


@command("fedsubs", module="federations", scope="any", h="List federations yours follows / is followed by")
def fedsubs(r):
    fed = resolve(r, admin=True)
    if not fed:
        return
    fid = fed["fed_id"]
    a = db.all("SELECT sub_id FROM fed_subs WHERE fed_id=?", (fid,))
    b = db.all("SELECT fed_id FROM fed_subs WHERE sub_id=?", (fid,))
    nm = lambda x: (fed_row(x) or {"name": "?"})["name"]  # noqa: E731
    r.reply(f"<b>{esc(fed['name'])}</b>\nFollows:\n" + ("\n".join(f"• {esc(nm(x['sub_id']))} <code>{x['sub_id']}</code>" for x in a) or "• none")
            + "\nFollowed by:\n" + ("\n".join(f"• {esc(nm(x['fed_id']))}" for x in b) or "• none"))


# --------------------------------------------------------------------------
# Bans
# --------------------------------------------------------------------------
def _notify(fed, text):
    if fed["log_chat"]:
        try:
            C.send(fed["log_chat"], text)
        except TgError:
            pass
    if fed["notif"]:
        try:
            C.send(fed["owner_id"], text)
        except TgError:
            pass


@command("fban", module="federations", scope="any", h="Ban a user in the whole federation: /fban <user> [reason]")
def fban(r):
    fed = resolve(r, admin=True)
    if not fed:
        return
    tg = C.get_target(r)
    if not tg:
        return
    fid, reason = fed["fed_id"], tg.rest.strip()
    if tg.id == C.ME.id or is_fed_admin(fid, tg.id) or C.is_sudo(tg.id):
        return r.error("I can't fban federation admins, bot staff, or myself.")
    if fed["need_reason"] and not reason:
        return r.error("This federation requires a reason: <code>/fban @user spamming</code>")
    db.x("INSERT INTO fed_bans VALUES(?,?,?,?,?) ON CONFLICT(fed_id,user_id) DO UPDATE SET reason=excluded.reason,"
         "ts=excluded.ts,by=excluded.by", (fid, tg.id, reason, time.time(), r.user.id))
    done = 0
    for cid in fed_chat_ids(fid):
        try:
            C.punish(cid, tg.id, "ban")
            done += 1
        except TgError:
            pass
    r.reply(f"🌐 {tg.mention} was <b>fbanned</b> in <b>{esc(fed['name'])}</b>" + (f"\nReason: {esc(reason)}" if reason else "")
            + f"\nRemoved from {done} chat(s).")
    _notify(fed, f"<b>New FedBan</b>\nFed: {esc(fed['name'])}\nUser: {tg.mention} (<code>{tg.id}</code>)\n"
                 f"By: {mention(r.user.id, full_name(r.user))}\nReason: {esc(reason or 'none')}")


@command("unfban", module="federations", scope="any", h="Remove a federation ban: /unfban <user>")
def unfban(r):
    fed = resolve(r, admin=True)
    if not fed:
        return
    tg = C.get_target(r)
    if not tg:
        return
    n = db.x("DELETE FROM fed_bans WHERE fed_id=? AND user_id=?", (fed["fed_id"], tg.id)).rowcount
    if not n:
        return r.reply(f"{tg.mention} isn't fbanned in <b>{esc(fed['name'])}</b>.")
    for cid in fed_chat_ids(fed["fed_id"]):
        try:
            C.bot.unban_chat_member(chat_id=cid, user_id=tg.id, only_if_banned=True)
        except TgError:
            pass
    r.reply(f"✅ {tg.mention} was un-fbanned in <b>{esc(fed['name'])}</b>.")
    _notify(fed, f"<b>FedBan removed</b>\nFed: {esc(fed['name'])}\nUser: {tg.mention} (<code>{tg.id}</code>)\n"
                 f"By: {mention(r.user.id, full_name(r.user))}")


@command("fedstat", module="federations", scope="any", h="Where is a user fbanned? /fedstat [user]")
def fedstat(r):
    m = UUID_RE.search(r.raw)
    only = m.group(0).lower() if m else None
    if only:
        r.raw = (r.raw[:m.start()] + r.raw[m.end():]).strip()
        r.args = r.raw.split()
    tg = C.get_target(r, err=False) or C.Target(r.user.id, full_name(r.user))
    rows = db.all("SELECT b.fed_id,b.reason,f.name FROM fed_bans b JOIN feds f ON f.fed_id=b.fed_id WHERE b.user_id=?",
                  (tg.id,))
    if only:
        rows = [x for x in rows if x["fed_id"] == only]
    if not rows:
        return r.reply(f"{tg.mention} is not banned in {'that' if only else 'any'} federation.")
    r.reply(f"{tg.mention} is banned in:\n" + "\n".join(
        f"• <b>{esc(x['name'])}</b> — {esc(x['reason'] or 'no reason')}" for x in rows))


@command("fbanstat", module="federations", scope="any", h="Is a user fbanned in this chat's federation?")
def fbanstat(r):
    fed = resolve(r)
    if not fed:
        return
    tg = C.get_target(r, err=False) or C.Target(r.user.id, full_name(r.user))
    row = db.one("SELECT reason,ts FROM fed_bans WHERE fed_id=? AND user_id=?", (fed["fed_id"], tg.id))
    if not row:
        return r.reply(f"{tg.mention} is <b>not</b> banned in <b>{esc(fed['name'])}</b>.")
    r.reply(f"{tg.mention} is <b>banned</b> in <b>{esc(fed['name'])}</b>\nReason: {esc(row['reason'] or 'none')}\n"
            f"Since: {time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime(row['ts']))}")


# --------------------------------------------------------------------------
# Import / export of ban lists
# --------------------------------------------------------------------------
@command("fbanlist", module="federations", scope="any", h="Export the federation's ban list as a CSV file")
def fbanlist(r):
    fed = resolve(r, owner=True)
    if not fed:
        return
    rows = db.all("SELECT user_id,reason,ts FROM fed_bans WHERE fed_id=? ORDER BY ts", (fed["fed_id"],))
    if not rows:
        return r.reply("This federation has no banned users.")
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["user_id", "reason", "timestamp"])
    for x in rows:
        w.writerow([x["user_id"], x["reason"] or "", int(x["ts"] or 0)])
    C.send_file(r.chat.id, f"fbanlist_{fed['fed_id'][:8]}.csv", buf.getvalue().encode(),
                f"{len(rows)} bans in <b>{esc(fed['name'])}</b>", "text/csv", thread=r.thread)


@command("importfbans", module="federations", scope="any",
         h="Import bans: reply to a CSV/JSON file made by /fbanlist")
def importfbans(r):
    fed = resolve(r, owner=True)
    if not fed:
        return
    rep = r.msg.reply_to_message
    if not rep or not rep.document:
        return r.error("Reply to a CSV or JSON file with <code>/importfbans</code>.")
    try:
        raw = C.download_file(rep.document.file_id).decode("utf-8", "ignore")
    except TgError as e:
        return r.error(f"Couldn't download the file: {esc(e.desc)}")
    entries = []
    try:
        if raw.lstrip().startswith(("[", "{")):
            data = json.loads(raw)
            data = data if isinstance(data, list) else data.get("bans", [])
            for x in data:
                entries.append((int(x["user_id"] if isinstance(x, dict) else x), (x.get("reason", "") if isinstance(x, dict) else "")))
        else:
            for row in csv.reader(io.StringIO(raw)):
                if row and row[0].strip().lstrip("-").isdigit():
                    entries.append((int(row[0]), row[1] if len(row) > 1 else ""))
    except (ValueError, KeyError, TypeError):
        return r.error("That file isn't in a format I understand (user_id,reason CSV or a JSON list).")
    if len(entries) > 20000:
        return r.error("That's too many entries (max 20000).")
    now = time.time()
    for uid, reason in entries:
        if uid == fed["owner_id"] or is_fed_admin(fed["fed_id"], uid):
            continue
        db.x("INSERT INTO fed_bans VALUES(?,?,?,?,?) ON CONFLICT(fed_id,user_id) DO UPDATE SET reason=excluded.reason",
             (fed["fed_id"], uid, reason, now, r.user.id))
    r.reply(f"✅ Imported {len(entries)} bans into <b>{esc(fed['name'])}</b>. They are enforced when users join or talk.")
