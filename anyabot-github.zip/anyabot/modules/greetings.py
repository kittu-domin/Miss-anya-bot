"""Welcome and goodbye messages."""
import core as C
from core import command, esc, full_name, mention
from db import db
from tg import TgError


def _default_welcome(cid):
    return {"type": "text", "file": None, "text": C.t(cid, "welcome_default"), "fmt": "md"}


def _count(cid):
    try:
        return C.bot.get_chat_member_count(chat_id=cid)
    except TgError:
        return None


def send_welcome(cid, user, chat):
    if not db.get(cid, "welcome", True):
        return
    if db.get(cid, "cleanwelcome", False):
        prev = db.get(cid, "lastwelcome")
        if prev:
            C.delete_msg(cid, prev)
    data = db.get(cid, "welcometext") or _default_welcome(cid)
    m = C.send_saved(cid, data, user, chat, count=_count(cid), kind="join")
    if m:
        db.set(cid, "lastwelcome", m.message_id)


def send_goodbye(cid, user, chat):
    if not db.get(cid, "goodbye", False):
        return
    data = db.get(cid, "goodbyetext") or {"type": "text", "file": None, "text": "Goodbye {first}!", "fmt": "md"}
    C.send_saved(cid, data, user, chat, count=_count(cid), kind="join")


def _show(r, key, textkey, default, label):
    arg = r.args[0].lower() if r.args else ""
    v = C.on_off(arg)
    if v is not None:
        db.set(r.cid, key, v)
        return r.reply(f"{label} messages {'enabled' if v else 'disabled'}.")
    data = db.get(r.cid, textkey) or default
    noformat = arg == "noformat"
    r.reply(f"<b>{label}</b>: {C.flag(db.get(r.cid, key, key == 'welcome'))}\n"
            f"Below is the current message{' (raw)' if noformat else ''}. Use <code>/{r.name} on|off</code> to toggle.")
    C.send_saved(r.chat.id, data, r.user, r.chat, thread=r.thread, noformat=noformat, count=_count(r.cid), kind="note")


@command("welcome", module="greetings", admin=True, h="Show/toggle the welcome message: on/off/noformat")
def welcome(r):
    _show(r, "welcome", "welcometext", _default_welcome(r.cid), "Welcome")


@command("goodbye", module="greetings", admin=True, h="Show/toggle the goodbye message: on/off/noformat")
def goodbye(r):
    _show(r, "goodbye", "goodbyetext",
          {"type": "text", "file": None, "text": "Goodbye {first}!", "fmt": "md"}, "Goodbye")


def _set(r, key, label):
    c = r.content()
    if not c:
        return r.error("Give me the message text, or reply to a message (media works too). "
                       "Fillings: {first} {last} {fullname} {username} {mention} {id} {count} {chatname}. "
                       "Buttons: <code>[Label](buttonurl://example.com)</code>")
    db.set(r.cid, key, c)
    r.reply(f"✅ {label} message updated.")
    C.log_event(r.cid, "settings", f"{label} message changed by {mention(r.user.id, full_name(r.user))}")


@command("setwelcome", module="greetings", admin=True, h="Set the welcome message (text/media/reply)")
def setwelcome(r):
    _set(r, "welcometext", "Welcome")


@command("setgoodbye", module="greetings", admin=True, h="Set the goodbye message")
def setgoodbye(r):
    _set(r, "goodbyetext", "Goodbye")


@command("resetwelcome", module="greetings", admin=True, h="Restore the default welcome message")
def resetwelcome(r):
    db.rm(r.cid, "welcometext")
    r.reply("Welcome message reset to default.")


@command("resetgoodbye", module="greetings", admin=True, h="Restore the default goodbye message")
def resetgoodbye(r):
    db.rm(r.cid, "goodbyetext")
    r.reply("Goodbye message reset to default.")


@command("cleanwelcome", module="greetings", admin=True, h="Delete the previous welcome when a new one is sent: on/off")
def cleanwelcome(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Clean welcome: {C.flag(db.get(r.cid, 'cleanwelcome', False))}")
    db.set(r.cid, "cleanwelcome", v)
    r.reply(f"Clean welcome {'enabled' if v else 'disabled'}.")
