"""Echo, import/export, privacy, topics, cleaning, advanced settings."""
import json
import time

import core as C
from core import callback, command, esc, full_name, kb, mention
from db import db
from tg import TgError, after


# ==========================================================================
# Echo / say / broadcast
# ==========================================================================
@command("echo", module="echo", admin=True, h="Make me send a formatted message (text, media or reply)")
def echo(r):
    c = r.content()
    if not c:
        return r.error("Give me something to say: <code>/echo Hello *world*</code>")
    rep = r.msg.reply_to_message
    C.send_saved(r.cid, c, r.user, r.chat, reply_to=rep.message_id if rep and not r.connected else None,
                 thread=r.thread if not r.connected else None, kind="other")
    if not r.connected:
        C.delete_msg(r.chat.id, r.msg.message_id)


@command("say", module="echo", admin=True, h="Make me send your text exactly as written (no formatting)")
def say(r):
    if not r.raw:
        return r.error("Give me something to say: <code>/say Hello</code>")
    rep = r.msg.reply_to_message
    C.send(r.cid, C.esc(r.raw), reply_to=rep.message_id if rep and not r.connected else None,
           thread=r.thread if not r.connected else None)
    if not r.connected:
        C.delete_msg(r.chat.id, r.msg.message_id)


@command("broadcast", module="echo", owner=True, scope="any", h="(Owner) announce a message in every chat I'm in")
def broadcast(r):
    c = r.content()
    if not c:
        return r.error("Usage: <code>/broadcast Your announcement</code>")
    rows = db.all("SELECT chat_id FROM chats")
    ok = bad = 0
    for row in rows:
        try:
            C.send_saved(row["chat_id"], c, r.user, C.D(id=row["chat_id"], title=""), kind="other")
            ok += 1
        except TgError:
            bad += 1
        time.sleep(0.07)
    r.reply(f"📣 Broadcast finished: {ok} delivered, {bad} failed.")


# ==========================================================================
# Import / export / reset
# ==========================================================================
_TRANSIENT = {"lastwelcome", "lastpin", "purgefrom", "raid_until", "logchannel"}


def export_chat(cid):
    return {
        "version": 1, "chat_id": cid, "exported_at": int(time.time()),
        "settings": {k: v for k, v in db.kv_all(cid).items() if k not in _TRANSIENT},
        "notes": {x["name"]: json.loads(x["data"]) for x in db.all("SELECT name,data FROM notes WHERE chat_id=?", (cid,))},
        "filters": {x["kw"]: json.loads(x["data"]) for x in db.all("SELECT kw,data FROM filters WHERE chat_id=?", (cid,))},
        "blocklist": [{"trigger": x["trigger"], "reason": x["reason"]}
                      for x in db.all("SELECT trigger,reason FROM blocklist WHERE chat_id=?", (cid,))],
        "approvals": [x["user_id"] for x in db.all("SELECT user_id FROM approvals WHERE chat_id=?", (cid,))],
    }


@command("export", module="exports", admin=True, h="Export this chat's settings, notes and filters as a file")
def export(r):
    data = json.dumps(export_chat(r.cid), indent=1, ensure_ascii=False).encode()
    C.send_file(r.chat.id, f"export_{abs(r.cid)}.json", data, "Settings export. Use /import on a reply to restore.",
                "application/json", thread=r.thread)


@command("import", module="exports", admin=True, h="Import settings: reply to a file made by /export")
def import_cmd(r):
    rep = r.msg.reply_to_message
    if not rep or not rep.document:
        return r.error("Reply to an export file with <code>/import</code>.")
    try:
        data = json.loads(C.download_file(rep.document.file_id).decode("utf-8"))
        assert isinstance(data, dict) and data.get("version") == 1
    except (TgError, ValueError, AssertionError):
        return r.error("That doesn't look like a valid export file.")
    cid = r.cid
    for k, v in (data.get("settings") or {}).items():
        if k not in _TRANSIENT:
            db.set(cid, k, v)
    for n, d in (data.get("notes") or {}).items():
        db.x("INSERT OR REPLACE INTO notes VALUES(?,?,?)", (cid, n, json.dumps(d)))
    for k, d in (data.get("filters") or {}).items():
        db.x("INSERT OR REPLACE INTO filters VALUES(?,?,?)", (cid, k, json.dumps(d)))
    for b in data.get("blocklist") or []:
        db.x("INSERT OR REPLACE INTO blocklist VALUES(?,?,?)", (cid, b["trigger"], b.get("reason")))
    for u in data.get("approvals") or []:
        db.x("INSERT OR IGNORE INTO approvals VALUES(?,?)", (cid, int(u)))
    r.reply(f"✅ Imported {len(data.get('settings') or {})} settings, {len(data.get('notes') or {})} notes, "
            f"{len(data.get('filters') or {})} filters and {len(data.get('blocklist') or [])} blocklist items.")


@command("reset", module="exports", scope="group", h="Reset ALL settings of this chat (chat creator only)")
def reset(r):
    m = C.member(r.cid, r.user.id)
    if not ((m and m.status == "creator") or C.is_sudo(r.user.id)):
        return r.error("Only the chat creator can reset everything.")
    r.reply("⚠️ This deletes <b>all</b> settings, notes, filters, blocklist, approvals and warnings of this chat.",
            kb([[("Yes, reset", f"cb:reset:yes:{r.cid}"), ("Cancel", f"cb:reset:no:{r.cid}")]]))


@callback("reset:")
def cb_reset(cq, data):
    ans, _, cid = data.partition(":")
    cid = int(cid)
    m = C.member(cid, cq["from"]["id"])
    if not ((m and m.status == "creator") or C.is_sudo(cq["from"]["id"])):
        return C.answer(cq, "Only the chat creator can do that.", True)
    if ans == "yes":
        db.kv_wipe(cid)
        for tbl in ("notes", "filters", "blocklist", "approvals", "warns"):
            db.x(f"DELETE FROM {tbl} WHERE chat_id=?", (cid,))
        C.edit(cq, "♻️ Everything was reset.")
    else:
        C.edit(cq, "Cancelled.")
    C.answer(cq)


# ==========================================================================
# Privacy
# ==========================================================================
PRIVACY = ("<b>Privacy</b>\n\nWhat I store:\n"
           "• Your Telegram user ID, name and @username (so I can resolve @mentions in commands)\n"
           "• Per-group settings, notes, filters, warnings and ban records created by group admins\n"
           "• A message counter per group (only a number — never message text)\n"
           "• AFK status / bio if you set them\n\n"
           "I do not store the text of normal chat messages.\n"
           "Use the button below to delete your personal data. Moderation records (warnings, bans) belong to "
           "the groups that created them and are not removed.")


@command("privacy", module="privacy", scope="any", h="What data I store, and how to delete yours")
def privacy(r):
    r.reply(PRIVACY, kb([[("🗑 Delete my data", "cb:privacy:ask")]]) if r.chat.type == "private" else None)


@callback("privacy:")
def cb_privacy(cq, data):
    uid = cq["from"]["id"]
    if data == "ask":
        C.edit(cq, "Delete your stored name, username, AFK status, bio and connections?",
               kb([[("Yes, delete", "cb:privacy:yes"), ("Cancel", "cb:privacy:no")]]))
    elif data == "yes":
        db.x("DELETE FROM users WHERE user_id=?", (uid,))
        db.x("DELETE FROM afk WHERE user_id=?", (uid,))
        db.x("DELETE FROM conns WHERE user_id=?", (uid,))
        db.x("DELETE FROM msgcount WHERE user_id=?", (uid,))
        db.kv_wipe(uid)
        C._seen_users.pop(uid, None)
        C.edit(cq, "✅ Your personal data was deleted.")
    else:
        C.edit(cq, "Cancelled.")
    C.answer(cq)


# ==========================================================================
# Topics (forum groups)
# ==========================================================================
def _thread(r):
    rep = r.msg.reply_to_message
    if rep and rep.is_topic_message and rep.message_thread_id:
        return rep.message_thread_id
    return r.thread


@command("newtopic", module="topics", rights=("can_manage_topics",), h="Create a topic: /newtopic <name>")
def newtopic(r):
    if not r.raw:
        return r.error("Usage: <code>/newtopic Name</code>")
    t = C.bot.create_forum_topic(chat_id=r.cid, name=r.raw[:128])
    r.reply(f"✅ Topic <b>{esc(r.raw[:128])}</b> created (ID <code>{t.message_thread_id if isinstance(t, dict) else '?'}</code>).")


@command("renametopic", module="topics", rights=("can_manage_topics",), h="Rename the current topic")
def renametopic(r):
    th = _thread(r)
    if not th or not r.raw:
        return r.error("Use <code>/renametopic New name</code> inside the topic you want to rename.")
    C.bot.edit_forum_topic(chat_id=r.cid, message_thread_id=th, name=r.raw[:128])
    r.reply("✅ Topic renamed.")


def _topic_action(method, done):
    def f(r):
        th = _thread(r)
        if not th:
            return r.error("Use this command inside a topic (not General).")
        C.bot.call(method, chat_id=r.cid, message_thread_id=th)
        if method != "deleteForumTopic":
            r.reply(done)
    return f


for _n, _m, _d, _h in [("closetopic", "closeForumTopic", "🔒 Topic closed.", "Close the current topic"),
                       ("reopentopic", "reopenForumTopic", "🔓 Topic reopened.", "Reopen the current topic"),
                       ("deletetopic", "deleteForumTopic", "", "Delete the current topic and its messages")]:
    command(_n, module="topics", rights=("can_manage_topics",), h=_h)(_topic_action(_m, _d))


@command("actiontopic", module="topics", admin=True, h="Show which topic receives my action messages")
def actiontopic(r):
    th = db.get(r.cid, "actiontopic")
    r.reply(f"Action messages go to topic <code>{th}</code>." if th else
            "No action topic set. Use /setactiontopic inside the topic you want.")


@command("setactiontopic", module="topics", admin=True,
         h="Send bans/warns/mutes announcements to this topic (/setactiontopic off to disable)")
def setactiontopic(r):
    if r.args and r.args[0].lower() in ("off", "no", "reset"):
        db.rm(r.cid, "actiontopic")
        return r.reply("Action topic cleared. I'll answer where the command was sent.")
    if not r.thread:
        return r.error("Run this command inside the topic you want to use.")
    db.set(r.cid, "actiontopic", r.thread)
    r.reply("✅ Action messages will now be posted in this topic.")


# ==========================================================================
# Cleaning
# ==========================================================================
CMD_TYPES = {"all": "every command", "admin": "admin commands", "user": "normal user commands",
             "other": "commands for other bots / unknown commands"}
MSG_TYPES = {"all": "every message I send", "action": "ban/mute/warn announcements", "filter": "filter replies",
             "note": "notes, rules, welcome previews", "join": "welcome/goodbye/captcha messages",
             "report": "report notices", "error": "error messages", "other": "everything else"}
SVC_TYPES = {"all": "all service messages", "join": "someone joined", "leave": "someone left",
             "pin": "pinned message notices", "title": "chat title changes", "photo": "chat photo changes",
             "videochat": "video chat notices", "other": "other service messages"}


def _clean_set(key, types, doc):
    def add(r):
        want = [a.lower() for a in r.args]
        if not want:
            cur = db.get(r.cid, key, [])
            return r.reply(f"Currently cleaned: <code>{' '.join(cur) or 'nothing'}</code>\n"
                           f"Usage: <code>/{r.name} &lt;types&gt;</code> — see /{r.name}types")
        bad = [w for w in want if w not in types]
        if bad:
            return r.error(f"Unknown type(s): <code>{' '.join(bad)}</code>. Choices: <code>{' '.join(types)}</code>")
        db.set(r.cid, key, sorted(set(db.get(r.cid, key, [])) | set(want)))
        r.reply(f"✅ Now cleaning: <code>{' '.join(db.get(r.cid, key, []))}</code>")
    return add


def _clean_unset(key, types):
    def rm(r):
        want = [a.lower() for a in r.args]
        if not want:
            return r.error("Tell me which types to stop cleaning (or <code>all</code>).")
        cur = db.get(r.cid, key, [])
        cur = [] if "all" in want else [c for c in cur if c not in want]
        db.set(r.cid, key, cur)
        r.reply(f"✅ Now cleaning: <code>{' '.join(cur) or 'nothing'}</code>")
    return rm


def _clean_types(key, types):
    def ls(r):
        cur = db.get(r.cid, key, [])
        r.reply("<b>Types:</b>\n" + "\n".join(f"{'🧹' if k in cur else '▫️'} <code>{k}</code> — {v}"
                                              for k, v in types.items()))
    return ls


command("cleancommand", module="cleaning", admin=True, h="Delete command messages of a type: all/admin/user/other")(
    _clean_set("cleancmd", CMD_TYPES, ""))
command("keepcommand", module="cleaning", admin=True, h="Stop deleting command messages of a type")(
    _clean_unset("cleancmd", CMD_TYPES))
command("cleancommandtypes", module="cleaning", admin=True, h="List command-clean types")(
    _clean_types("cleancmd", CMD_TYPES))
command("cleanmsg", module="cleaning", admin=True,
        h="Auto-delete my messages of a type after a few minutes")(_clean_set("cleanmsg", MSG_TYPES, ""))
command("keepmsg", module="cleaning", admin=True, h="Stop auto-deleting my messages of a type")(
    _clean_unset("cleanmsg", MSG_TYPES))
command("cleanmsgtypes", module="cleaning", admin=True, h="List bot-message clean types")(
    _clean_types("cleanmsg", MSG_TYPES))
command("cleanservice", module="cleaning", rights=("can_delete_messages",),
        h="Delete service messages: join/leave/pin/title/photo/videochat/other/all")(_clean_set("cleansvc", SVC_TYPES, ""))
command("nocleanservice", module="cleaning", admin=True, h="Stop deleting service messages of a type")(
    _clean_unset("cleansvc", SVC_TYPES))
command("cleanservicetypes", module="cleaning", admin=True, h="List service-message clean types")(
    _clean_types("cleansvc", SVC_TYPES))


def service_kind(msg):
    if msg.new_chat_members:
        return "join"
    if msg.left_chat_member:
        return "leave"
    if msg.pinned_message:
        return "pin"
    if msg.new_chat_title:
        return "title"
    if msg.new_chat_photo or msg.delete_chat_photo:
        return "photo"
    if (msg.video_chat_started or msg.video_chat_ended or msg.video_chat_scheduled
            or msg.video_chat_participants_invited):
        return "videochat"
    return "other"


# ==========================================================================
# Advanced
# ==========================================================================
@command("silentactions", module="advanced", admin=True,
         h="Make ban/mute/kick/warn commands silent (command deleted, no reply): on/off")
def silentactions(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Silent actions: {C.flag(db.get(r.cid, 'silentactions', False))}")
    db.set(r.cid, "silentactions", v)
    r.reply(f"Silent actions {'enabled' if v else 'disabled'}.")


@command("bot2bot", module="advanced", admin=True,
         h="Let other bots run my commands: /bot2bot on | off | @bot1 @bot2")
def bot2bot(r):
    cur = db.get(r.cid, "bot2bot", [])
    if not r.args:
        shown = "all bots" if "*" in cur else (", ".join("@" + b for b in cur) or "nobody")
        return r.reply(f"Bots allowed to use my commands: <b>{esc(shown)}</b>\n"
                       "Use <code>/bot2bot on</code>, <code>/bot2bot off</code> or list usernames.\n"
                       "Remember to enable Bot-to-Bot Communication for both bots in @BotFather.")
    a = r.args[0].lower()
    if a in ("off", "no"):
        db.set(r.cid, "bot2bot", [])
        return r.reply("Other bots can no longer run my commands.")
    if a in ("on", "yes", "all"):
        db.set(r.cid, "bot2bot", ["*"])
        return r.reply("⚠️ Every bot can now run my commands (subject to its admin rights).")
    names = sorted({x.lstrip("@").lower() for x in r.args})
    db.set(r.cid, "bot2bot", names)
    r.reply("✅ Allowed bots: " + ", ".join("@" + n for n in names))


@command("bot2botskipreview", module="advanced", admin=True,
         h="Allowed bots skip the admin-rights review (trust them fully): on/off")
def bot2botskipreview(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Skip review for allowed bots: {C.flag(db.get(r.cid, 'b2b_skip', False))}\n"
                       "Off = a bot must itself be a chat admin with the matching right.")
    db.set(r.cid, "b2b_skip", v)
    r.reply(f"Bot review {'skipped' if v else 'required'} for allowed bots.")
