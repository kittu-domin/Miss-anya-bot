"""Extras beyond core: global bans, AFK, night mode, stats, group tools, utilities and fun commands."""
import ast
import json
import operator
import random
import threading
import time
import urllib.parse
import urllib.request
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo

import config
import core as C
from core import command, esc, full_name, kb, mention
from db import db
from tg import TgError, every

# ==========================================================================
# Global bans & bot staff
# ==========================================================================


@command("gban", module="gbans", sudo=True, scope="any", h="(Staff) ban a user in every chat I'm in")
def gban(r):
    tg = C.get_target(r)
    if not tg:
        return
    if tg.id == C.ME.id or C.is_sudo(tg.id):
        return r.error("I can't gban myself or bot staff.")
    reason = tg.rest.strip() or "no reason"
    db.x("INSERT INTO gbans VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET reason=excluded.reason,"
         "ts=excluded.ts,by=excluded.by", (tg.id, reason, time.time(), r.user.id))
    ok = 0
    for row in db.all("SELECT chat_id FROM chats WHERE type!='private'"):
        if db.get(row["chat_id"], "gbanstat", True):
            try:
                C.punish(row["chat_id"], tg.id, "ban")
                ok += 1
            except TgError:
                pass
            time.sleep(0.05)
    r.reply(f"☠️ {tg.mention} was <b>globally banned</b> ({ok} chats).\nReason: {esc(reason)}")


@command("ungban", module="gbans", sudo=True, scope="any", h="(Staff) lift a global ban")
def ungban(r):
    tg = C.get_target(r)
    if not tg:
        return
    n = db.x("DELETE FROM gbans WHERE user_id=?", (tg.id,)).rowcount
    if not n:
        return r.reply(f"{tg.mention} isn't globally banned.")
    for row in db.all("SELECT chat_id FROM chats WHERE type!='private'"):
        try:
            C.bot.unban_chat_member(chat_id=row["chat_id"], user_id=tg.id, only_if_banned=True)
        except TgError:
            pass
        time.sleep(0.05)
    r.reply(f"✅ {tg.mention} is no longer globally banned.")


@command("gbanlist", module="gbans", sudo=True, scope="any", h="(Staff) export the global ban list")
def gbanlist(r):
    rows = db.all("SELECT user_id,reason,ts FROM gbans ORDER BY ts")
    if not rows:
        return r.reply("Nobody is globally banned.")
    data = json.dumps([{"user_id": x["user_id"], "reason": x["reason"], "ts": int(x["ts"])} for x in rows], indent=1)
    C.send_file(r.chat.id, "gbans.json", data.encode(), f"{len(rows)} global bans", "application/json")


@command("gbanstat", module="gbans", admin=True, h="Enforce global bans in this chat: on/off (default on)")
def gbanstat(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Global ban enforcement: {C.flag(db.get(r.cid, 'gbanstat', True))}")
    db.set(r.cid, "gbanstat", v)
    r.reply(f"Global ban enforcement {'enabled' if v else 'disabled'}.")


@command("addsudo", module="gbans", owner=True, scope="any", h="(Owner) add a bot staff member")
def addsudo(r):
    tg = C.get_target(r)
    if tg:
        db.x("INSERT OR IGNORE INTO sudo VALUES(?)", (tg.id,))
        r.reply(f"⭐ {tg.mention} is now bot staff.")


@command("rmsudo", module="gbans", owner=True, scope="any", h="(Owner) remove a bot staff member")
def rmsudo(r):
    tg = C.get_target(r)
    if tg:
        db.x("DELETE FROM sudo WHERE user_id=?", (tg.id,))
        r.reply(f"{tg.mention} is no longer bot staff.")


@command("sudolist", "staff", module="gbans", scope="any", h="List the bot's staff")
def sudolist(r):
    rows = db.all("SELECT user_id FROM sudo")
    lines = ["<b>Bot staff</b>"]
    if config.OWNER_ID:
        lines.append(f"👑 {mention(config.OWNER_ID, C.user_name(config.OWNER_ID))}")
    lines += [f"⭐ {mention(x['user_id'], C.user_name(x['user_id']))}" for x in rows]
    r.reply("\n".join(lines))


@command("leave", module="gbans", owner=True, scope="any", h="(Owner) make me leave a chat: /leave [chat id]")
def leave(r):
    cid = int(r.args[0]) if r.args and r.args[0].lstrip("-").isdigit() else r.chat.id
    C.bot.leave_chat(chat_id=cid)
    db.x("DELETE FROM chats WHERE chat_id=?", (cid,))


@command("stats", module="gbans", owner=True, scope="any", h="(Owner) bot statistics")
def stats(r):
    r.reply("<b>Stats</b>\n"
            f"Chats: {db.count('SELECT COUNT(*) FROM chats')}\nUsers seen: {db.count('SELECT COUNT(*) FROM users')}\n"
            f"Notes: {db.count('SELECT COUNT(*) FROM notes')} · Filters: {db.count('SELECT COUNT(*) FROM filters')}\n"
            f"Warns: {db.count('SELECT COUNT(*) FROM warns')} · Global bans: {db.count('SELECT COUNT(*) FROM gbans')}\n"
            f"Federations: {db.count('SELECT COUNT(*) FROM feds')} · Fed bans: {db.count('SELECT COUNT(*) FROM fed_bans')}\n"
            f"Commands: {len({id(c) for c in C.REGISTRY.values()})}")


# ==========================================================================
# Group tools
# ==========================================================================
@command("chatinfo", module="groupmgmt", admin=True, h="Show information about this chat")
def chatinfo(r):
    ch = C.bot.get_chat(chat_id=r.cid)
    n = C.bot.get_chat_member_count(chat_id=r.cid)
    r.reply(f"<b>{esc(ch.title)}</b>\nID: <code>{ch.id}</code>\nType: {ch.type}\nMembers: {n}\n"
            f"Admins: {len(C.admins(r.cid, fresh=True))}\nUsername: {('@' + ch.username) if ch.username else '-'}\n"
            f"Forum: {'yes' if ch.is_forum else 'no'}\nDescription: {esc((ch.description or '-')[:300])}")


@command("setgtitle", module="groupmgmt", rights=("can_change_info",), h="Change the chat title")
def setgtitle(r):
    if not r.raw:
        return r.error("Usage: <code>/setgtitle New title</code>")
    C.bot.set_chat_title(chat_id=r.cid, title=r.raw[:128])
    r.reply("✅ Title changed.")


@command("setdesc", module="groupmgmt", rights=("can_change_info",), h="Change the chat description")
def setdesc(r):
    C.bot.set_chat_description(chat_id=r.cid, description=r.raw[:255])
    r.reply("✅ Description updated.")


@command("setgpic", module="groupmgmt", rights=("can_change_info",), h="Set the chat photo (reply to a photo)")
def setgpic(r):
    rep = r.msg.reply_to_message
    if not rep or not rep.photo:
        return r.error("Reply to a photo with <code>/setgpic</code>.")
    data = C.download_file(rep.photo[-1].file_id)
    C.bot.call("setChatPhoto", _files={"photo": ("photo.jpg", data, "image/jpeg")}, chat_id=r.cid)
    r.reply("✅ Chat photo updated.")


@command("delgpic", module="groupmgmt", rights=("can_change_info",), h="Remove the chat photo")
def delgpic(r):
    C.bot.delete_chat_photo(chat_id=r.cid)
    r.reply("✅ Chat photo removed.")


@command("invitelink", module="groupmgmt", rights=("can_invite_users",), h="Get the chat's invite link")
def invitelink(r):
    link = C.bot.export_chat_invite_link(chat_id=r.cid)
    r.reply(f"🔗 {esc(link)}")


@command("tagall", "mentionall", module="groupmgmt", admin=True, h="Mention people who have chatted here (admins only)")
def tagall(r):
    rows = db.all("SELECT user_id FROM msgcount WHERE chat_id=? ORDER BY n DESC LIMIT 100", (r.cid,))
    ids = [x["user_id"] for x in rows if x["user_id"] != C.ME.id]
    if not ids:
        return r.error("I haven't seen anyone talk here yet.")
    head = esc(r.raw) + "\n" if r.raw else ""
    for i in range(0, len(ids), 5):
        C.send(r.cid, head + " ".join(mention(u, "​" + (C.user_name(u).split()[0] if C.user_name(u) else "user"))
                                    for u in ids[i:i + 5]), thread=r.thread)
        time.sleep(0.4)


@command("kickme", module="groupmgmt", scope="group", h="Kick yourself out of the chat")
def kickme(r):
    if C.is_admin(r.cid, r.user.id):
        return r.error("I can't kick admins, sorry!")
    C.punish(r.cid, r.user.id, "kick")
    r.reply("👋 Bye! You can rejoin any time.")


# --- night mode -----------------------------------------------------------
def _in_window(now_min, start, end):
    return (start <= now_min < end) if start < end else (now_min >= start or now_min < end)


def _hm(s):
    h, m = s.split(":")
    return int(h) * 60 + int(m)


@command("nightmode", module="groupmgmt", rights=("can_restrict_members",),
         h="Auto-lock the chat at night: /nightmode on 23:00 06:00 | off | tz Asia/Kolkata")
def nightmode(r):
    cur = db.get(r.cid, "night", {"on": False, "start": "23:00", "end": "06:00", "tz": config.DEFAULT_TZ, "active": False})
    if not r.args:
        return r.reply(f"🌙 Night mode: {C.flag(cur['on'])} · {cur['start']}–{cur['end']} ({cur['tz']})\n"
                       "Usage: <code>/nightmode on 23:00 06:00</code> · <code>/nightmode off</code> · "
                       "<code>/nightmode tz Asia/Kolkata</code>")
    a = r.args[0].lower()
    try:
        if a == "tz":
            ZoneInfo(r.args[1])
            cur["tz"] = r.args[1]
        elif a == "on":
            if len(r.args) >= 3:
                _hm(r.args[1]), _hm(r.args[2])
                cur["start"], cur["end"] = r.args[1], r.args[2]
            cur["on"] = True
        elif a == "off":
            cur["on"] = False
            if cur.get("active"):
                _night_set(r.cid, False)
                cur["active"] = False
        else:
            raise ValueError
    except (ValueError, IndexError, KeyError, Exception):  # noqa: BLE001
        return r.error("Invalid input. Example: <code>/nightmode on 23:00 06:00</code>")
    db.set(r.cid, "night", cur)
    r.reply(f"🌙 Night mode {'enabled' if cur['on'] else 'disabled'}: {cur['start']}–{cur['end']} ({cur['tz']})")


def _night_set(cid, locked):
    try:
        if locked:
            C.bot.set_chat_permissions(chat_id=cid, permissions=C.NO_PERMS)
            C.send(cid, "🌙 Night mode started — the chat is locked until morning.")
        else:
            C.bot.set_chat_permissions(chat_id=cid, permissions={**C.ALL_PERMS, "can_change_info": False,
                                                                 "can_pin_messages": False,
                                                                 "can_manage_topics": False})
            C.send(cid, "☀️ Good morning! The chat is open again.")
    except TgError as e:
        C.log.warning("night mode failed in %s: %s", cid, e)


def night_tick():
    for row in db.all("SELECT chat_id FROM kv WHERE k='night'"):
        cid = row["chat_id"]
        cfg = db.get(cid, "night")
        if not cfg or not cfg.get("on"):
            continue
        now = datetime.now(ZoneInfo(cfg["tz"]))
        inside = _in_window(now.hour * 60 + now.minute, _hm(cfg["start"]), _hm(cfg["end"]))
        if inside != bool(cfg.get("active")):
            cfg["active"] = inside
            db.set(cid, "night", cfg)
            _night_set(cid, inside)


# ==========================================================================
# AFK, bio, message counts
# ==========================================================================
@command("afk", module="utils", scope="any", h="Mark yourself away: /afk [reason]")
def afk(r):
    db.x("INSERT INTO afk VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET reason=excluded.reason,ts=excluded.ts",
         (r.user.id, r.raw[:200], time.time()))
    r.reply(f"😴 {mention(r.user.id, full_name(r.user))} is now AFK" + (f": {esc(r.raw[:200])}" if r.raw else "."))


def afk_check(msg):
    """Called for group messages: wake up returning users, notify when someone pings an AFK user."""
    uid = msg.from_user.id if msg.from_user else 0
    if (msg.text or "").lower().startswith(("brb", "/afk")) and not (msg.text or "").startswith("/afk"):
        db.x("INSERT INTO afk VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET reason=excluded.reason,ts=excluded.ts",
             (uid, (msg.text or "")[3:].strip()[:200], time.time()))
        return C.send(msg.chat.id, f"😴 {mention(uid, full_name(msg.from_user))} is now AFK.", reply_to=msg.message_id)
    row = db.one("SELECT ts FROM afk WHERE user_id=?", (uid,))
    if row and not (msg.text or "").startswith("/afk"):
        db.x("DELETE FROM afk WHERE user_id=?", (uid,))
        C.send(msg.chat.id, f"👋 {mention(uid, full_name(msg.from_user))} is back after "
                            f"<b>{C.fmt_dur(time.time() - row['ts'])}</b>!", reply_to=msg.message_id)
    targets = set()
    if msg.reply_to_message and msg.reply_to_message.from_user:
        targets.add(msg.reply_to_message.from_user.id)
    for e in (msg.entities or []):
        if e.type == "text_mention" and e.user:
            targets.add(e.user.id)
        elif e.type == "mention":
            u = db.one("SELECT user_id FROM users WHERE username=?", ((msg.text[e.offset + 1:e.offset + e.length]).lower(),))
            if u:
                targets.add(u["user_id"])
    for t in targets - {uid}:
        a = db.one("SELECT reason,ts FROM afk WHERE user_id=?", (t,))
        if a:
            C.send(msg.chat.id, f"😴 {mention(t, C.user_name(t))} is AFK since <b>{C.fmt_dur(time.time() - a['ts'])}</b>"
                                + (f"\nReason: {esc(a['reason'])}" if a["reason"] else ""), reply_to=msg.message_id)


@command("setbio", module="utils", scope="any", h="Set your own bio (reply to set someone else's, admins only)")
def setbio(r):
    rep = r.msg.reply_to_message
    uid = r.user.id
    if rep and rep.from_user and rep.from_user.id != uid:
        if r.chat.type == "private" or not C.is_admin(r.chat.id, uid):
            return r.error("Only admins can set someone else's bio.")
        uid = rep.from_user.id
    if not r.raw:
        return r.error("Usage: <code>/setbio I love Telegram bots</code>")
    db.set(uid, "bio", r.raw[:300])
    r.reply("✅ Bio saved.")


@command("bio", module="utils", scope="any", h="Show a user's bio")
def bio(r):
    tg = C.get_target(r, err=False) or C.Target(r.user.id, full_name(r.user))
    b = db.get(tg.id, "bio")
    r.reply(f"<b>{tg.mention}</b>\n{esc(b)}" if b else f"{tg.mention} has no bio. Set one with /setbio.")


_counts = defaultdict(int)
_clock = threading.Lock()


def count_message(cid, uid):
    with _clock:
        _counts[(cid, uid)] += 1


def flush_counts():
    with _clock:
        items, _counts_copy = list(_counts.items()), None
        _counts.clear()
    for (cid, uid), n in items:
        db.x("INSERT INTO msgcount VALUES(?,?,?) ON CONFLICT(chat_id,user_id) DO UPDATE SET n=n+excluded.n",
             (cid, uid, n))


@command("top", module="utils", scope="group", h="Most active members of this chat")
def top(r):
    flush_counts()
    rows = db.all("SELECT user_id,n FROM msgcount WHERE chat_id=? ORDER BY n DESC LIMIT 10", (r.cid,))
    if not rows:
        return r.reply("No activity recorded yet.")
    r.reply("<b>🏆 Top members</b>\n" + "\n".join(f"{i}. {mention(x['user_id'], C.user_name(x['user_id']))} — {x['n']}"
                                                 for i, x in enumerate(rows, 1)))


# ==========================================================================
# Utilities
# ==========================================================================
@command("ping", module="utils", scope="any", h="Check my response time")
def ping(r):
    t0 = time.time()
    m = r.reply("🏓 Pong!")
    if m:
        try:
            C.bot.edit_message_text(chat_id=m.chat.id, message_id=m.message_id,
                                    text=f"🏓 Pong! <code>{(time.time() - t0) * 1000:.0f} ms</code>", parse_mode="HTML")
        except TgError:
            pass


@command("uptime", module="utils", scope="any", h="How long I've been running")
def uptime(r):
    r.reply(f"⏱ Up for <b>{C.fmt_dur(time.time() - C.START)}</b>")


_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv, ast.USub: operator.neg,
        ast.UAdd: operator.pos}


def _eval(n):
    if isinstance(n, ast.Expression):
        return _eval(n.body)
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
        return n.value
    if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
        a, b = _eval(n.left), _eval(n.right)
        if isinstance(n.op, ast.Pow) and (abs(b) > 100 or abs(a) > 1e6):
            raise ValueError("too big")
        return _OPS[type(n.op)](a, b)
    if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
        return _OPS[type(n.op)](_eval(n.operand))
    raise ValueError("unsupported")


@command("calc", module="utils", scope="any", h="Calculator: /calc 2*(3+4)")
def calc(r):
    try:
        res = _eval(ast.parse(r.raw.replace("^", "**"), mode="eval"))
    except (ValueError, SyntaxError, ZeroDivisionError, OverflowError, RecursionError):
        return r.error("I can only do numbers with + - * / % ** ( ).")
    r.reply(f"🧮 <code>{esc(r.raw)}</code> = <b>{res:,.10g}</b>")


@command("time", module="utils", scope="any", h="Current time: /time [Area/City]")
def time_cmd(r):
    zone = r.args[0] if r.args else config.DEFAULT_TZ
    try:
        now = datetime.now(ZoneInfo(zone))
    except Exception:  # noqa: BLE001
        return r.error("Unknown time zone. Example: <code>/time Asia/Kolkata</code>")
    r.reply(f"🕐 <b>{esc(zone)}</b>: {now.strftime('%A, %d %B %Y — %H:%M:%S')}")


@command("wiki", module="utils", scope="any", h="Wikipedia summary: /wiki <topic>")
def wiki(r):
    if not r.raw:
        return r.error("Usage: <code>/wiki Albert Einstein</code>")
    url = "https://en.wikipedia.org/api/rest_v1/page/summary/" + urllib.parse.quote(r.raw.replace(" ", "_"))
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "anyabot/1.0"}), timeout=15) as resp:
            d = json.load(resp)
    except Exception:  # noqa: BLE001
        return r.error("I couldn't find that on Wikipedia.")
    link = d.get("content_urls", {}).get("desktop", {}).get("page")
    r.reply(f"<b>{esc(d.get('title', r.raw))}</b>\n{esc((d.get('extract') or 'No summary.')[:900])}",
            kb([[("Read more", link)]]) if link else None)


@command("markdownhelp", "formatting", module="utils", scope="any", h="How to format notes, welcome texts and filters")
def markdownhelp(r):
    r.reply("<b>Formatting</b>\n"
            "<code>*bold*</code> · <code>_italic_</code> · <code>~strike~</code> · <code>`code`</code> · "
            "<code>||spoiler||</code>\n<code>[text](https://link)</code> for links\n\n"
            "<b>Buttons</b>: <code>[Label](buttonurl://example.com)</code>; add <code>:same</code> to keep it on the "
            "previous row.\n\n<b>Fillings</b>: <code>{first} {last} {fullname} {username} {mention} {id} {count} {chatname}</code>\n"
            "<b>Flags</b>: <code>{preview} {protect} {nonotif} {mediaspoiler}</code>\n"
            "<b>Random</b>: separate variants with <code>%%%</code>.\n"
            "Telegram's own bold/italic formatting also works.")


# ==========================================================================
# Fun
# ==========================================================================
@command("dice", "roll", module="fun", scope="any", h="Roll a dice (or 🎯 🏀 ⚽ 🎳 🎰)")
def dice(r):
    emoji = r.args[0] if r.args and r.args[0] in "🎲🎯🏀⚽🎳🎰" else "🎲"
    C.bot.send_dice(chat_id=r.chat.id, emoji=emoji, message_thread_id=r.thread)


@command("flip", module="fun", scope="any", h="Flip a coin")
def flip(r):
    r.reply(random.choice(["🪙 Heads!", "🪙 Tails!"]))


@command("decide", "choose", module="fun", scope="any", h="Pick one: /decide pizza | burger | pasta")
def decide(r):
    opts = [o.strip() for o in (r.raw.split("|") if "|" in r.raw else r.raw.split(",")) if o.strip()]
    if len(opts) < 2:
        return r.error("Give me at least two options: <code>/decide tea | coffee</code>")
    r.reply(f"🤔 I choose: <b>{esc(random.choice(opts))}</b>")


@command("8ball", module="fun", scope="any", h="Ask the magic 8-ball")
def eightball(r):
    r.reply("🎱 " + random.choice(["It is certain.", "Without a doubt.", "Yes, definitely.", "Most likely.",
                                    "Ask again later.", "Cannot predict now.", "Don't count on it.",
                                    "My sources say no.", "Very doubtful.", "Outlook good."]))


def _social(name, lines):
    def f(r):
        tg = C.get_target(r, err=False)
        who = mention(r.user.id, full_name(r.user))
        r.reply(random.choice(lines).format(a=who, b=tg.mention if tg else "everyone"))
    command(name, module="fun", scope="any", h=f"/{name} someone")(f)


_social("slap", ["{a} slaps {b} with a large trout 🐟", "{a} slaps {b} around with a wet noodle 🍜",
                 "{a} throws a pillow at {b} 🛏"])
_social("pat", ["{a} pats {b} on the head 🥰", "{a} gives {b} a gentle pat ✨"])
_social("hug", ["{a} hugs {b} tightly 🤗", "{a} gives {b} a warm hug 💞"])
_social("runs", ["{a} runs away from {b} 🏃", "{a} sprints off, chased by {b} 💨"])


def start_jobs():
    every(60, night_tick)
    every(30, flush_counts)
