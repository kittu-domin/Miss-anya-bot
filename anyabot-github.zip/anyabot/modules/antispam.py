"""Anti-spam: locks, CAPTCHA, blocklists, antiflood, antiraid."""
import random
import re
import string
import time
from fnmatch import fnmatch

import core as C
from core import callback, command, esc, full_name, kb, mention
from db import db
from modules.moderation import warn_user
from tg import TgError, ent_text

# ==========================================================================
# Locks
# ==========================================================================
LOCKTYPES = {
    "all": "everything", "album": "media albums", "anonchannel": "messages sent as a channel", "audio": "audio files",
    "bot": "adding bots", "button": "messages with inline buttons", "command": "bot commands",
    "comment": "comments on linked channel posts", "contact": "shared contacts", "document": "files",
    "email": "email addresses", "emojigame": "dice / dart / basketball emoji games", "forward": "any forward",
    "forwardbot": "forwards from bots", "forwardchannel": "forwards from channels",
    "forwarduser": "forwards from users", "game": "games", "gif": "GIFs", "inline": "inline bot results",
    "invitelink": "Telegram invite links", "location": "locations / venues", "phone": "phone numbers",
    "photo": "photos", "poll": "polls", "rtl": "right-to-left text", "sticker": "stickers", "text": "plain text",
    "url": "links", "video": "videos", "videonote": "round video notes", "voice": "voice messages",
}
INVITE_RE = re.compile(r"(?:t\.me|telegram\.me|telegram\.dog)/(?:\+|joinchat/)[\w-]+", re.I)
RTL_RE = re.compile("[֐-׿؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]")


def msg_urls(msg):
    out = []
    for text, ents in ((msg.text, msg.entities), (msg.caption, msg.caption_entities)):
        for e in ents or []:
            if e.type == "url" and text:
                out.append(ent_text(text, e))
            elif e.type == "text_link":
                out.append(e.url)
    return out


def msg_ent_types(msg):
    return {e.type for e in (msg.entities or []) + (msg.caption_entities or [])}


def url_allowed(cid, url):
    u = url.lower().split("://", 1)[-1].rstrip("/")
    dom = u.split("/")[0]
    for pat in db.get(cid, "allowlist", []):
        p = pat.lower().strip().rstrip("/")
        if fnmatch(u, p) or fnmatch(u, p + "/*") or fnmatch(dom, p):
            return True
    return False


def lock_hit(msg):
    cid = msg.chat.id
    locks = set(db.get(cid, "locks", []))
    if not locks:
        return None
    if "all" in locks:
        return "all"
    hit = set()
    if msg.text:
        hit.add("text")
    for k, attr in (("photo", "photo"), ("video", "video"), ("audio", "audio"), ("voice", "voice"),
                    ("sticker", "sticker"), ("videonote", "video_note"), ("contact", "contact"),
                    ("poll", "poll"), ("game", "game")):
        if msg.get(attr):
            hit.add(k)
    if msg.animation:
        hit.add("gif")
    elif msg.document:
        hit.add("document")
    if msg.location or msg.venue:
        hit.add("location")
    if msg.dice:
        hit.add("emojigame")
    if msg.media_group_id:
        hit.add("album")
    if msg.via_bot:
        hit.add("inline")
    if msg.reply_markup and msg.reply_markup.get("inline_keyboard"):
        hit.add("button")
    fo = msg.forward_origin
    if fo:
        hit.add("forward")
        if fo.type == "channel":
            hit.add("forwardchannel")
        elif fo.type in ("user", "hidden_user"):
            hit.add("forwarduser")
            if fo.sender_user and fo.sender_user.is_bot:
                hit.add("forwardbot")
    if msg.sender_chat and msg.sender_chat.id != cid and not msg.is_automatic_forward:
        hit.add("anonchannel")
    if msg.reply_to_message and msg.reply_to_message.is_automatic_forward:
        hit.add("comment")
    types = msg_ent_types(msg)
    if "bot_command" in types:
        hit.add("command")
    if "email" in types:
        hit.add("email")
    if "phone_number" in types:
        hit.add("phone")
    body = (msg.text or msg.caption or "")
    if INVITE_RE.search(body) and not all(url_allowed(cid, u) for u in INVITE_RE.findall(body)):
        hit.add("invitelink")
    urls = msg_urls(msg)
    if urls and any(not url_allowed(cid, u) for u in urls):
        hit.add("url")
    if RTL_RE.search(body):
        hit.add("rtl")
    if "forwardchannel" in hit and fo and fo.chat:
        ident = [str(fo.chat.id), fo.chat.username or "", fo.chat.title or ""]
        if any(url_allowed(cid, i) for i in ident if i):
            hit.discard("forwardchannel")
    both = hit & locks
    return sorted(both)[0] if both else None


def apply_lock(msg, kind):
    cid, user = msg.chat.id, msg.from_user
    C.delete_msg(cid, msg.message_id)
    if db.get(cid, "lockwarns", False) and user and not msg.sender_chat:
        text, markup = warn_user(cid, user.id, f"Locked content: {kind}")
        C.send(cid, text, markup, kind="action")


def _check_locks(msg):
    kind = lock_hit(msg)
    if kind:
        apply_lock(msg, kind)
        return True
    return False


@command("locktypes", module="locks", scope="group", h="List everything that can be locked")
def locktypes(r):
    r.reply("<b>Lock types:</b>\n" + "\n".join(f"• <code>{k}</code> — {v}" for k, v in LOCKTYPES.items()))


@command("locks", module="locks", admin=True, h="Show the current locks")
def locks(r):
    cur = set(db.get(r.cid, "locks", []))
    r.reply("<b>Locks in this chat:</b>\n" + "\n".join(f"{'🔒' if k in cur else '🔓'} <code>{k}</code>"
                                                      for k in LOCKTYPES))


def _lock(r, enable):
    want = [a.lower() for a in r.args]
    bad = [w for w in want if w not in LOCKTYPES]
    if not want or bad:
        return r.error("Tell me what to " + ("lock" if enable else "unlock") + ": see /locktypes."
                       + (f"\nUnknown: <code>{' '.join(bad)}</code>" if bad else ""))
    cur = set(db.get(r.cid, "locks", []))
    cur = cur | set(want) if enable else cur - set(want)
    db.set(r.cid, "locks", sorted(cur))
    r.reply(f"{'🔒 Locked' if enable else '🔓 Unlocked'}: <code>{' '.join(want)}</code>")
    C.log_event(r.cid, "settings", f"{mention(r.user.id, full_name(r.user))} {'locked' if enable else 'unlocked'} "
                                   f"<code>{' '.join(want)}</code>")


@command("lock", module="locks", rights=("can_delete_messages",), h="Lock message types: /lock <types>")
def lock(r):
    _lock(r, True)


@command("unlock", module="locks", rights=("can_delete_messages",), h="Unlock message types")
def unlock(r):
    _lock(r, False)


@command("lockwarns", module="locks", admin=True, h="Warn users who break locks: on/off")
def lockwarns(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Lock warns: {C.flag(db.get(r.cid, 'lockwarns', False))}")
    db.set(r.cid, "lockwarns", v)
    r.reply(f"Lock warns {'enabled' if v else 'disabled'}.")


@command("allowlist", module="locks", admin=True,
         h="Allow links/domains/channels despite locks: /allowlist example.com t.me/mychannel")
def allowlist(r):
    if not r.args:
        cur = db.get(r.cid, "allowlist", [])
        return r.reply("<b>Allowlist:</b>\n" + "\n".join(f"• <code>{esc(c)}</code>" for c in cur)
                       if cur else "The allowlist is empty. Usage: <code>/allowlist example.com</code>")
    cur = db.get(r.cid, "allowlist", [])
    db.set(r.cid, "allowlist", sorted(set(cur) | {a.lower() for a in r.args}))
    r.reply(f"✅ Added to the allowlist: <code>{esc(' '.join(r.args))}</code>")


@command("rmallowlist", module="locks", admin=True, h="Remove entries from the allowlist")
def rmallowlist(r):
    cur = db.get(r.cid, "allowlist", [])
    gone = {a.lower() for a in r.args}
    db.set(r.cid, "allowlist", [c for c in cur if c not in gone])
    r.reply(f"Removed: <code>{esc(' '.join(r.args)) or '-'}</code>")


@command("rmallowlistall", module="locks", admin=True, h="Clear the allowlist")
def rmallowlistall(r):
    db.set(r.cid, "allowlist", [])
    r.reply("Allowlist cleared.")


# ==========================================================================
# Blocklist
# ==========================================================================
def _bl_re(trigger):
    t = trigger.strip()
    if t.lower().startswith("regex:"):
        try:
            return re.compile(t[6:], re.I)
        except re.error:
            pass
    pat = re.escape(t).replace(r"\*", r"\S*")
    return re.compile(r"(?<!\w)" + pat + r"(?!\w)", re.I)


def blocklist_hit(msg):
    rows = db.all("SELECT trigger,reason FROM blocklist WHERE chat_id=?", (msg.chat.id,))
    if not rows:
        return None
    text = " ".join(x for x in (msg.text, msg.caption, msg.sticker.set_name if msg.sticker else None,
                                msg.document.file_name if msg.document else None) if x)
    for row in rows:
        if _bl_re(row["trigger"]).search(text):
            return row
    return None


def _check_blocklist(msg):
    row = blocklist_hit(msg)
    if not row:
        return False
    cid, user = msg.chat.id, msg.from_user
    if db.get(cid, "blocklistdelete", True):
        C.delete_msg(cid, msg.message_id)
    mode, secs = db.get(cid, "blocklistmode", "nothing"), db.get(cid, "blocklistmodetime")
    reason = row["reason"] or db.get(cid, "blreason") or f"Blocklisted word: {row['trigger']}"
    if mode == "nothing" or not user:
        return True
    try:
        if mode == "warn":
            text, markup = warn_user(cid, user.id, reason)
            C.send(cid, text, markup, kind="action")
        else:
            C.punish(cid, user.id, mode, secs)
            C.send(cid, f"{mention(user.id, full_name(user))} was <b>{C.VERB[mode]}</b>.\nReason: {esc(reason)}",
                   kind="action")
    except TgError as e:
        C.log.warning("blocklist action failed: %s", e)
    return True


def _triggers(raw):
    raw = raw.strip()
    if "\n" in raw and not raw.startswith(("(", '"')):
        return [ln.strip() for ln in raw.splitlines() if ln.strip()], ""
    return C.parse_keys(raw)


@command("addblocklist", module="blocklist", rights=("can_delete_messages",),
         h='Block words: /addblocklist word [reason] · ("a, b") · * wildcards · regex:...')
def addblocklist(r):
    keys, reason = _triggers(r.raw)
    if not keys:
        return r.error("Usage: <code>/addblocklist spam</code> · <code>/addblocklist (spam, scam) reason</code>")
    for k in keys:
        db.x("INSERT INTO blocklist VALUES(?,?,?) ON CONFLICT(chat_id,trigger) DO UPDATE SET reason=excluded.reason",
             (r.cid, k.lower(), reason.strip() or None))
    r.reply("✅ Added to the blocklist: " + ", ".join(f"<code>{esc(k)}</code>" for k in keys))


@command("rmblocklist", module="blocklist", rights=("can_delete_messages",), h="Remove words from the blocklist")
def rmblocklist(r):
    keys, _ = _triggers(r.raw)
    n = 0
    for k in keys:
        n += db.x("DELETE FROM blocklist WHERE chat_id=? AND trigger=?", (r.cid, k.lower())).rowcount
    r.reply(f"Removed {n} blocklist trigger(s).")


@command("rmblocklistall", module="blocklist", rights=("can_delete_messages",), h="Clear the whole blocklist")
def rmblocklistall(r):
    n = db.x("DELETE FROM blocklist WHERE chat_id=?", (r.cid,)).rowcount
    r.reply(f"Blocklist cleared ({n} triggers).")


@command("blocklist", module="blocklist", admin=True, h="Show the blocklist and its settings")
def blocklist(r):
    rows = db.all("SELECT trigger,reason FROM blocklist WHERE chat_id=? ORDER BY trigger", (r.cid,))
    mode, secs = db.get(r.cid, "blocklistmode", "nothing"), db.get(r.cid, "blocklistmodetime")
    head = (f"Mode: <b>{C.mode_text(mode, secs)}</b> · Delete: <b>{'yes' if db.get(r.cid, 'blocklistdelete', True) else 'no'}</b>\n")
    if not rows:
        return r.reply(head + "The blocklist is empty.")
    r.reply(head + "<b>Blocked:</b>\n" + "\n".join(
        f"• <code>{esc(x['trigger'])}</code>" + (f" — {esc(x['reason'])}" if x["reason"] else "") for x in rows))


@command("blocklistmode", module="blocklist", admin=True,
         h="Action on blocklisted words: nothing/ban/mute/kick/warn/tban <t>/tmute <t>")
def blocklistmode(r):
    if not r.args:
        return r.reply(f"Blocklist mode: <b>{C.mode_text(db.get(r.cid, 'blocklistmode', 'nothing'), db.get(r.cid, 'blocklistmodetime'))}</b>")
    mode, secs, err = C.parse_mode_args(r.args, ("nothing", "ban", "mute", "kick", "warn", "tban", "tmute"))
    if err:
        return r.error(err)
    db.set(r.cid, "blocklistmode", mode)
    db.set(r.cid, "blocklistmodetime", secs)
    r.reply(f"✅ Blocklist mode set to <b>{C.mode_text(mode, secs)}</b>.")


@command("blocklistdelete", module="blocklist", admin=True, h="Delete blocklisted messages: yes/no")
def blocklistdelete(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Delete blocklisted messages: {C.flag(db.get(r.cid, 'blocklistdelete', True))}")
    db.set(r.cid, "blocklistdelete", v)
    r.reply(f"Blocklisted messages will {'' if v else 'not '}be deleted.")


@command("setblocklistreason", module="blocklist", admin=True, h="Default reason for blocklist actions")
def setblocklistreason(r):
    if not r.raw:
        return r.error("Usage: <code>/setblocklistreason Spam is not allowed</code>")
    db.set(r.cid, "blreason", r.raw[:200])
    r.reply("✅ Default blocklist reason updated.")


@command("resetblocklistreason", module="blocklist", admin=True, h="Reset the default blocklist reason")
def resetblocklistreason(r):
    db.rm(r.cid, "blreason")
    r.reply("Blocklist reason reset.")


# ==========================================================================
# Antiflood
# ==========================================================================
_flood = {}     # cid -> [uid, count, [ids], album]
_floodt = {}    # (cid, uid) -> [(ts, mid)]


def _check_flood(msg):
    cid, uid, mid = msg.chat.id, msg.from_user.id, msg.message_id
    limit, timer = db.get(cid, "flood", 0), db.get(cid, "floodtimer")
    if not limit and not timer:
        return False
    ids, hit = [], False
    if timer:
        cnt, secs = timer
        now = time.time()
        lst = [x for x in _floodt.get((cid, uid), []) if x[0] > now - secs] + [(now, mid)]
        _floodt[(cid, uid)] = lst
        if len(lst) >= cnt:
            hit, ids = True, [x[1] for x in lst]
            _floodt.pop((cid, uid), None)
    else:
        cur = _flood.get(cid)
        album = msg.media_group_id
        if cur and cur[0] == uid:
            if album and cur[3] == album:           # same album counts once
                cur[2].append(mid)
                return False
            cur[1] += 1
            cur[2].append(mid)
            cur[3] = album
        else:
            cur = _flood[cid] = [uid, 1, [mid], album]
        if cur[1] >= limit:
            hit, ids = True, cur[2]
            _flood.pop(cid, None)
    if not hit:
        return False
    mode, secs = db.get(cid, "floodmode", "mute"), db.get(cid, "floodmodetime")
    if db.get(cid, "clearflood", False):
        for i in range(0, len(ids), 100):
            try:
                C.bot.delete_messages(chat_id=cid, message_ids=ids[i:i + 100])
            except TgError:
                pass
    try:
        C.punish(cid, uid, mode, secs)
        C.send(cid, f"{mention(uid, full_name(msg.from_user))} was <b>{C.VERB[mode]}</b> for flooding.",
               kind="action")
    except TgError as e:
        C.log.warning("flood action failed: %s", e)
    return True


@command("flood", module="antiflood", admin=True, h="Show the antiflood settings")
def flood(r):
    lim, tm = db.get(r.cid, "flood", 0), db.get(r.cid, "floodtimer")
    mode, secs = db.get(r.cid, "floodmode", "mute"), db.get(r.cid, "floodmodetime")
    r.reply("<b>Antiflood</b>\n"
            f"• Consecutive-message limit: <b>{lim or 'off'}</b>\n"
            f"• Timed limit: <b>{f'{tm[0]} msgs / {tm[1]}s' if tm else 'off'}</b>\n"
            f"• Action: <b>{C.mode_text(mode, secs)}</b>\n"
            f"• Delete flood messages: <b>{'yes' if db.get(r.cid, 'clearflood', False) else 'no'}</b>")


@command("setflood", module="antiflood", admin=True, h="Max consecutive messages: /setflood 10 | off")
def setflood(r):
    if not r.args:
        return r.error("Usage: <code>/setflood 10</code> or <code>/setflood off</code>")
    a = r.args[0].lower()
    if a in ("off", "no", "0"):
        db.set(r.cid, "flood", 0)
        return r.reply("Antiflood disabled.")
    if not a.isdigit() or not 2 <= int(a) <= 200:
        return r.error("Give me a number between 2 and 200.")
    db.set(r.cid, "flood", int(a))
    r.reply(f"✅ Antiflood: <b>{int(a)}</b> consecutive messages from one user.")


@command("setfloodtimer", module="antiflood", admin=True, h="Timed flood: /setfloodtimer <count> <time> | off")
def setfloodtimer(r):
    if r.args and r.args[0].lower() in ("off", "no", "0"):
        db.rm(r.cid, "floodtimer")
        return r.reply("Timed antiflood disabled.")
    secs = C.parse_time(r.args[1]) if len(r.args) > 1 else None
    if len(r.args) < 2 or not r.args[0].isdigit() or int(r.args[0]) < 2 or not secs:
        return r.error("Usage: <code>/setfloodtimer 10 30s</code> (10 messages within 30 seconds)")
    db.set(r.cid, "floodtimer", [int(r.args[0]), secs])
    r.reply(f"✅ Timed antiflood: <b>{int(r.args[0])}</b> messages within <b>{C.fmt_dur(secs)}</b>.")


@command("setfloodmode", module="antiflood", admin=True, h="Flood action: ban/mute/kick/tban <t>/tmute <t>")
def setfloodmode(r):
    mode, secs, err = C.parse_mode_args(r.args)
    if err:
        return r.error(err)
    db.set(r.cid, "floodmode", mode)
    db.set(r.cid, "floodmodetime", secs)
    r.reply(f"✅ Flood action set to <b>{C.mode_text(mode, secs)}</b>.")


@command("clearflood", module="antiflood", admin=True, h="Also delete the flood messages: on/off")
def clearflood(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"Delete flood messages: {C.flag(db.get(r.cid, 'clearflood', False))}")
    db.set(r.cid, "clearflood", v)
    r.reply(f"Flood messages will {'' if v else 'not '}be deleted.")


# ==========================================================================
# Antiraid
# ==========================================================================
_joins = {}


def raid_active(cid):
    return db.get(cid, "raid_until", 0) > time.time()


def raid_on_join(cid, uid):
    """Record a join. Returns True when the joiner was punished by raid mode."""
    now = time.time()
    lst = [t for t in _joins.get(cid, []) if t > now - 60] + [now]
    _joins[cid] = lst
    auto = db.get(cid, "autoraid", 0)
    if auto and len(lst) >= auto and not raid_active(cid):
        db.set(cid, "raid_until", now + db.get(cid, "raidtime", 21600))
        C.send(cid, f"🚨 <b>Raid detected</b> ({len(lst)} joins in a minute). "
                    f"Antiraid enabled for {C.fmt_dur(db.get(cid, 'raidtime', 21600))}.")
    if raid_active(cid):
        try:
            C.punish(cid, uid, "tban", db.get(cid, "raidactiontime", 3600))
        except TgError:
            return False
        return True
    return False


@command("antiraid", module="antiraid", rights=("can_restrict_members",),
         h="Enable raid mode: /antiraid [time|off] (new joiners get temp-banned)")
def antiraid(r):
    arg = r.args[0].lower() if r.args else ""
    if arg in ("off", "no", "stop") or (not arg and raid_active(r.cid)):
        db.set(r.cid, "raid_until", 0)
        return r.reply("🛡 Antiraid disabled.")
    secs = C.parse_time(arg) if arg else db.get(r.cid, "raidtime", 21600)
    if not secs:
        return r.error("Usage: <code>/antiraid 2h</code> or <code>/antiraid off</code>")
    db.set(r.cid, "raid_until", time.time() + secs)
    r.reply(f"🛡 Antiraid enabled for <b>{C.fmt_dur(secs)}</b>. New members will be banned for "
            f"<b>{C.fmt_dur(db.get(r.cid, 'raidactiontime', 3600))}</b>.")


@command("raidtime", module="antiraid", admin=True, h="How long antiraid stays on (default 6h)")
def raidtime(r):
    secs = C.parse_time(r.args[0]) if r.args else None
    if not r.args:
        return r.reply(f"Raid mode lasts <b>{C.fmt_dur(db.get(r.cid, 'raidtime', 21600))}</b>.")
    if not secs:
        return r.error("Usage: <code>/raidtime 6h</code>")
    db.set(r.cid, "raidtime", secs)
    r.reply(f"✅ Raid mode will last <b>{C.fmt_dur(secs)}</b>.")


@command("raidactiontime", module="antiraid", admin=True, h="How long raiders are banned (default 1h)")
def raidactiontime(r):
    secs = C.parse_time(r.args[0]) if r.args else None
    if not r.args:
        return r.reply(f"Raiders are banned for <b>{C.fmt_dur(db.get(r.cid, 'raidactiontime', 3600))}</b>.")
    if not secs:
        return r.error("Usage: <code>/raidactiontime 1h</code>")
    db.set(r.cid, "raidactiontime", secs)
    r.reply(f"✅ Raiders will be banned for <b>{C.fmt_dur(secs)}</b>.")


@command("autoantiraid", module="antiraid", admin=True, h="Auto-enable raid mode at N joins/minute | off")
def autoantiraid(r):
    if not r.args:
        n = db.get(r.cid, "autoraid", 0)
        return r.reply(f"Auto-antiraid: <b>{f'{n} joins per minute' if n else 'off'}</b>")
    a = r.args[0].lower()
    if a in ("off", "no", "0"):
        db.set(r.cid, "autoraid", 0)
        return r.reply("Auto-antiraid disabled.")
    if not a.isdigit() or int(a) < 2:
        return r.error("Usage: <code>/autoantiraid 15</code> (joins per minute) or <code>off</code>")
    db.set(r.cid, "autoraid", int(a))
    r.reply(f"✅ Raid mode will start automatically at <b>{int(a)}</b> joins per minute.")


# ==========================================================================
# CAPTCHA
# ==========================================================================
PENDING = {}    # (cid, uid) -> dict(mode, answer, mid, tries)


@command("captcha", module="captcha", rights=("can_restrict_members",), h="Enable/disable CAPTCHA for new members")
def captcha(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"CAPTCHA: {C.flag(db.get(r.cid, 'captcha', False))} · mode "
                       f"<b>{db.get(r.cid, 'captchamode', 'button')}</b>")
    db.set(r.cid, "captcha", v)
    r.reply(f"CAPTCHA {'enabled' if v else 'disabled'}.")


@command("captchamode", module="captcha", admin=True, h="CAPTCHA type: button, math or text")
def captchamode(r):
    m = r.args[0].lower() if r.args else ""
    if m not in ("button", "math", "text"):
        return r.error("Choose one: <code>button</code>, <code>math</code>, <code>text</code>.")
    db.set(r.cid, "captchamode", m)
    r.reply(f"✅ CAPTCHA mode is now <b>{m}</b>.")


@command("setcaptchatext", module="captcha", admin=True, h="Custom text shown with the CAPTCHA")
def setcaptchatext(r):
    if not r.raw:
        return r.error("Usage: <code>/setcaptchatext Hey {first}, prove you're human!</code>")
    db.set(r.cid, "captchatext", r.raw[:300])
    r.reply("✅ CAPTCHA text updated.")


@command("resetcaptchatext", module="captcha", admin=True, h="Reset the CAPTCHA text")
def resetcaptchatext(r):
    db.rm(r.cid, "captchatext")
    r.reply("CAPTCHA text reset.")


@command("captchakick", module="captcha", admin=True, h="Kick users who fail/ignore the CAPTCHA: on/off")
def captchakick(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"CAPTCHA kick: {C.flag(db.get(r.cid, 'captchakick', False))}")
    db.set(r.cid, "captchakick", v)
    r.reply(f"CAPTCHA kick {'enabled' if v else 'disabled'}.")


@command("captchakicktime", module="captcha", admin=True, h="Time users get to solve the CAPTCHA (default 5m)")
def captchakicktime(r):
    if not r.args:
        return r.reply(f"Users have <b>{C.fmt_dur(db.get(r.cid, 'captchakicktime', 300))}</b> to solve the CAPTCHA.")
    secs = C.parse_time(r.args[0])
    if not secs or secs < 30:
        return r.error("Usage: <code>/captchakicktime 5m</code> (minimum 30s)")
    db.set(r.cid, "captchakicktime", secs)
    r.reply(f"✅ Users now have <b>{C.fmt_dur(secs)}</b> to solve the CAPTCHA.")


@command("captchamutetime", module="captcha", admin=True, h="How long failed users stay muted (or 'off' = forever)")
def captchamutetime(r):
    if not r.args:
        v = db.get(r.cid, "captchamutetime")
        return r.reply(f"Failed users stay muted for <b>{C.fmt_dur(v) if v else 'ever'}</b>.")
    if r.args[0].lower() in ("off", "no", "0"):
        db.rm(r.cid, "captchamutetime")
        return r.reply("Failed users now stay muted until an admin unmutes them.")
    secs = C.parse_time(r.args[0])
    if not secs:
        return r.error("Usage: <code>/captchamutetime 1d</code>")
    db.set(r.cid, "captchamutetime", secs)
    r.reply(f"✅ Failed users will be muted for <b>{C.fmt_dur(secs)}</b>.")


@command("captcharules", module="captcha", admin=True, h="Make the CAPTCHA show a rules button: on/off")
def captcharules(r):
    v = C.on_off(r.args[0]) if r.args else None
    if v is None:
        return r.reply(f"CAPTCHA rules button: {C.flag(db.get(r.cid, 'captcharules', False))}")
    db.set(r.cid, "captcharules", v)
    r.reply(f"CAPTCHA rules button {'enabled' if v else 'disabled'}.")


def start_captcha(cid, user, chat):
    """Challenge a new member. Returns True if a challenge was started."""
    mode = db.get(cid, "captchamode", "button")
    uid = user.id
    answer, extra, rows = None, "", []
    if mode == "button":
        rows.append([("✅ I'm human", f"cb:cap:{cid}:{uid}:ok")])
    elif mode == "math":
        a, b = random.randint(2, 20), random.randint(2, 20)
        answer = a + b
        opts = {answer}
        while len(opts) < 4:
            opts.add(max(1, answer + random.choice([-4, -3, -2, -1, 1, 2, 3, 4])))
        rows.append([(str(o), f"cb:cap:{cid}:{uid}:{o}") for o in random.sample(sorted(opts), 4)])
        extra = f"\n\nWhat is <b>{a} + {b}</b>?"
    else:
        answer = "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
        extra = f"\n\nType this code in the chat: <code>{answer}</code>"
    if mode != "text":
        try:
            C.bot.restrict_chat_member(chat_id=cid, user_id=uid, permissions=C.NO_PERMS)
        except TgError:
            return False
    if db.get(cid, "captcharules", False) and db.get(cid, "rules"):
        rows.append([("📜 Rules", f"https://t.me/{C.ME.username}?start=rules_{cid}")])
        extra += "\nBy solving this CAPTCHA you accept the group rules."
    base = db.get(cid, "captchatext") or "Hey {first}, please prove you're human to talk in {chatname}."
    body, _, _ = C.render(base, "md", user, chat)
    m = C.send(cid, body + extra, kb(rows) if rows else None, kind="join")
    PENDING[(cid, uid)] = {"mode": mode, "answer": answer, "mid": m.message_id, "tries": 3}
    from tg import after
    after(db.get(cid, "captchakicktime", 300), captcha_timeout, cid, uid)
    return True


def _captcha_fail(cid, uid, st, why):
    PENDING.pop((cid, uid), None)
    C.delete_msg(cid, st["mid"])
    try:
        if db.get(cid, "captchakick", False):
            C.punish(cid, uid, "kick")
            note = "kicked"
        else:
            mt = db.get(cid, "captchamutetime")
            C.punish(cid, uid, "tmute" if mt else "mute", mt)
            note = "muted"
        m = C.send(cid, f"{mention(uid, C.user_name(uid))} {why} and was <b>{note}</b>.", kind="join")
        C.delete_later(cid, m.message_id, 30)
    except TgError as e:
        C.log.warning("captcha fail action: %s", e)


def captcha_timeout(cid, uid):
    st = PENDING.get((cid, uid))
    if st:
        _captcha_fail(cid, uid, st, "did not solve the CAPTCHA in time")


def captcha_pass(cid, user, chat):
    st = PENDING.pop((cid, user.id), None)
    if not st:
        return
    C.delete_msg(cid, st["mid"])
    if st["mode"] != "text":
        try:
            C.unrestrict(cid, user.id)
        except TgError:
            pass
    from modules import greetings
    greetings.send_welcome(cid, user, chat)


@callback("cap:")
def cb_captcha(cq, data):
    cid, uid, ans = data.split(":", 2)
    cid, uid = int(cid), int(uid)
    if cq["from"]["id"] != uid:
        return C.answer(cq, "This button is not for you.", True)
    st = PENDING.get((cid, uid))
    if not st:
        return C.answer(cq, "This CAPTCHA has expired.", True)
    if st["mode"] == "button" or str(st["answer"]) == ans:
        C.answer(cq, "✅ Verified!")
        return captcha_pass(cid, C.D(cq["from"]), C.D(id=cid, title=cq.message.chat.title, type="supergroup"))
    st["tries"] -= 1
    if st["tries"] <= 0:
        C.answer(cq, "Too many wrong answers.", True)
        return _captcha_fail(cid, uid, st, "failed the CAPTCHA")
    C.answer(cq, f"❌ Wrong answer! {st['tries']} tries left.", True)


def _check_captcha_text(msg):
    st = PENDING.get((msg.chat.id, msg.from_user.id))
    if not st or st["mode"] != "text":
        return False
    if (msg.text or "").strip().upper() == st["answer"]:
        C.delete_msg(msg.chat.id, msg.message_id)
        captcha_pass(msg.chat.id, msg.from_user, msg.chat)
    else:
        C.delete_msg(msg.chat.id, msg.message_id)
    return True


# ==========================================================================
# Entry point used by the event router
# ==========================================================================
def check_message(msg):
    """Run all automatic protections on a message from a non-exempt sender. True = message was handled."""
    if msg.from_user and _check_captcha_text(msg):
        return True
    if msg.from_user and _check_flood(msg):
        return True
    if _check_locks(msg):
        return True
    return _check_blocklist(msg)
